/* =========================================================================
   LUMINOUS NEU — demo.js
   Mode demo/preview: ESP32 Luminous v4.2 disimulasikan di browser, tanpa
   broker MQTT. Aktif bila URL berisi ?demo atau window.LUMINOUS_DEMO = true.
   Protokol yang disimulasikan sama dengan main.ino (topik <prefix>/..., perintah teks).
   ========================================================================= */
(function () {
  'use strict';
  const active = window.LUMINOUS_DEMO === true || /[?&]demo\b/.test(location.search);
  if (!active) return;
  window.LUMINOUS_DEMO = true;

  // Prefix topik diambil dari konfigurasi dashboard (default esp32)
  function prefix() {
    try { const c = JSON.parse(localStorage.getItem('lneu_cfg') || '{}'); return c.prefix || 'esp32'; }
    catch (e) { return 'esp32'; }
  }

  function FakeESP32(emit) {
    const P = prefix() + '/';
    const pub = (t, m) => setTimeout(() => emit(P + t, typeof m === 'string' ? m : JSON.stringify(m)), 30 + Math.random() * 60);
    const now = () => Date.now();
    const wib = () => Math.floor(now() / 1000) + 7 * 3600;
    const pad = n => String(n).padStart(2, '0');
    const fmtHM = m => pad(Math.floor(m / 60)) + ':' + pad(m % 60);

    let relay = [true, false, false, false];
    let temp = 28.6, hum = 66.4;
    const start = now() - 3 * 3600e3 - 1234e3;
    const stats = [
      { on_ms: 5.2 * 3600e3, cycles: 6, lastOn: now() - 40 * 60e3 },
      { on_ms: 3.1 * 3600e3, cycles: 11, lastOn: 0 },
      { on_ms: 0.4 * 3600e3, cycles: 3, lastOn: 0 },
      { on_ms: 1.9 * 3600e3, cycles: 2, lastOn: 0 }
    ];
    const sun = { sunrise: 5 * 60 + 26, sunset: 17 * 60 + 47 };
    let loc = { lat: -6.2088, lon: 106.8456 };
    const sched = [
      { id: 1, active: true, relay: 1, action: 'on', hour: 0, minute: 0, repeat: 'daily', days: 127, mode: 'sunset', offset: -15 },
      { id: 2, active: true, relay: 1, action: 'off', hour: 5, minute: 30, repeat: 'daily', days: 127, mode: 'fixed', offset: 0 },
      { id: 3, active: true, relay: 3, action: 'on', hour: 6, minute: 0, repeat: 'weekly', days: 0x2A, mode: 'fixed', offset: 0 },
      { id: 4, active: false, relay: 1, action: 'off', hour: 0, minute: 0, repeat: 'none', days: 127, mode: 'fixed', offset: 0 }
    ];
    const blankRule = id => ({ id, active: false, sensor: 'temp', cond: 'above', val: 0, has2: false, sensor2: 'temp', cond2: 'above', val2: 0, relay: 1, action: 'off' });
    const rules = [
      { id: 1, active: true, sensor: 'temp', cond: 'above', val: 30, has2: true, sensor2: 'hum', cond2: 'above', val2: 70, relay: 2, action: 'on' },
      blankRule(2), blankRule(3), blankRule(4)
    ];
    const sw = { n: 4, pins: [32, 33, 25, 26], type: ['toggle', 'toggle', 'toggle', 'push'], locked: [false, false, false, false], pos: [true, false, false, false] };
    const timers = [];
    const hist = Array.from({ length: 288 }, (_, i) => ({
      t: +(27.2 + 2.6 * Math.sin((i - 60) / 46) + (Math.random() - .5) * .3).toFixed(1),
      h: +(67 - 9 * Math.sin((i - 60) / 46) + (Math.random() - .5) * .8).toFixed(1),
      ts: wib() - (288 - i) * 300
    }));
    const tMin = 24.8, tMax = 30.9, hMin = 55.2, hMax = 78.4;

    function schedPayload() {
      return { n: 4, slots: sched.map(x => {
        const o = Object.assign({}, x);
        if (x.mode !== 'fixed') { const t = (sun[x.mode] + x.offset + 1440) % 1440; o.hour = Math.floor(t / 60); o.minute = t % 60; }
        return o;
      }) };
    }
    function setRelay(i, on, src) {
      if (relay[i] !== on) {
        if (on) { stats[i].lastOn = now(); stats[i].cycles++; } else stats[i].on_ms += now() - stats[i].lastOn;
      }
      relay[i] = on;
      pub('relayStatus', `relay${i + 1} ${on}`);
      if (src) pub('relay_event', { relay: i + 1, state: on, src });
    }
    function relayStat(i) {
      const s = stats[i]; let ms = s.on_ms; if (relay[i]) ms += now() - s.lastOn;
      pub('relay_stats', { relay: i + 1, on_ms: Math.round(ms), cycles: s.cycles, is_on: relay[i] });
    }
    function health() {
      pub('health', { uptime: Math.floor((now() - start) / 1000), heap: 181000 + Math.round(Math.random() * 3000), heap_min: 151200, rssi: -58 - Math.round(Math.random() * 6),
        timers: timers.filter(t => t.active).length, rules: rules.filter(r => r.active).length, hist_cnt: hist.length,
        wifi: true, mqtt: true, temp, hum, stat_n: 2316, t_min: tMin, t_max: tMax, t_avg: 27.6, h_min: hMin, h_max: hMax, h_avg: 66.9 });
    }
    function pubTime() {
      const e = wib(), d = new Date(e * 1000);
      pub('time', { time: `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`,
        date: `${pad(d.getUTCDate())}/${pad(d.getUTCMonth() + 1)}/${d.getUTCFullYear()}`, epoch: e, dow: d.getUTCDay(), valid: true, tz: 'WIB' });
    }
    const pubSun = () => pub('sun', { sunrise: fmtHM(sun.sunrise), sunset: fmtHM(sun.sunset), lat: loc.lat, lon: loc.lon });
    const pubSw = () => pub('switches', sw);

    // sensor berjalan pelan & alami
    setInterval(() => {
      temp = +(Math.min(33, Math.max(24, temp + (Math.random() - .48) * .25))).toFixed(1);
      hum = +(Math.min(85, Math.max(45, hum + (Math.random() - .5) * .5))).toFixed(1);
      pub('humidity679', hum.toFixed(1));
      pub('temperature679', temp.toFixed(1));
    }, 3000);
    setInterval(health, 8000);
    setInterval(pubTime, 30000);
    // isi grafik live dengan riwayat singkat agar preview langsung terlihat
    try {
      if (!localStorage.getItem('lneu_history')) {
        const pts = Array.from({ length: 60 }, (_, i) => ({
          ts: now() - (60 - i) * 5000,
          t: +(28.2 + .5 * Math.sin(i / 9) + (Math.random() - .5) * .15).toFixed(1),
          h: +(66.8 - 1.4 * Math.sin(i / 9) + (Math.random() - .5) * .3).toFixed(1)
        }));
        localStorage.setItem('lneu_history', JSON.stringify(pts));
      }
    } catch (e) {}

    // simulasi saklar fisik (dipanggil tombol di banner demo)
    this.pressSwitch = function (n) {
      const i = n - 1;
      if (sw.type[i] === 'toggle') sw.pos[i] = !sw.pos[i];
      pubSw();
      if (sw.locked[i]) { pub('alert', { type: 'switch_locked', relay: n, val: n, ts: 1 }); return; }
      setRelay(i, !relay[i], 'switch');
    };

    this.handle = function (cmd) {
      let x;
      if (cmd === 'sync') {
        relay.forEach((on, i) => pub('relayStatus', `relay${i + 1} ${on}`));
        health(); pub('rules', rules); pub('schedules', schedPayload()); pubTime(); pubSun(); pubSw();
        pub('sync_ack', { type: 'sync_ok', ts: 1 });
      }
      else if (cmd === 'get_schedules') pub('schedules', schedPayload());
      else if (cmd === 'stats') [0, 1, 2, 3].forEach(relayStat);
      else if (cmd === 'health') health();
      else if (cmd === 'ping') setTimeout(() => emit(P + 'pong', JSON.stringify({ uptime: 1, heap: 1, rssi: -60 })), 35 + Math.random() * 30);
      else if (cmd === 'ota_info') pub('ota_status', { ip: '192.168.1.77', port: 80, path: '/ota', version: '4.2', busy: false });
      else if (cmd === 'get_time') pubTime();
      else if (cmd === 'get_sun') pubSun();
      else if (cmd === 'get_switches') pubSw();
      else if ((x = /^relay(\d) (true|false)$/.exec(cmd))) setTimeout(() => setRelay(+x[1] - 1, x[2] === 'true', 'remote'), 150);
      else if ((x = /^switch_lock:(\d|all):(on|off)$/.exec(cmd))) {
        const v = x[2] === 'on';
        if (x[1] === 'all') sw.locked = sw.locked.map(() => v); else sw.locked[+x[1] - 1] = v;
        pubSw();
      }
      else if ((x = /^set_location:(-?[\d.]+):(-?[\d.]+)$/.exec(cmd))) {
        loc = { lat: +x[1], lon: +x[2] };
        pub('config_ack', { type: 'location_set', lat: loc.lat, lon: loc.lon }); pubSun(); pub('schedules', schedPayload());
      }
      else if ((x = /^save_schedule:(\d):(\d):(on|off):(\d\d):(\d\d):(\w+)(?::(\d+):(\w+):(-?\d+))?$/.exec(cmd))) {
        sched[+x[1] - 1] = { id: +x[1], active: true, relay: +x[2], action: x[3], hour: +x[4], minute: +x[5], repeat: x[6],
          days: x[7] ? +x[7] : 127, mode: x[8] || 'fixed', offset: x[9] ? +x[9] : 0 };
        pub('schedules', schedPayload()); pub('config_ack', { type: 'schedule_set', slot: +x[1] });
      }
      else if ((x = /^del_schedule:(\d)$/.exec(cmd))) { sched[+x[1] - 1].active = false; pub('schedules', schedPayload()); }
      else if (cmd.startsWith('set_rule:')) {
        const a = cmd.slice(9).split(':'), id = +a[0];
        rules[id - 1] = { id, active: true, sensor: a[1], cond: a[2], val: +a[3], relay: +a[4], action: a[5],
          has2: a.length > 6, sensor2: a[6] || 'temp', cond2: a[7] || 'above', val2: +(a[8] || 0) };
        pub('rules', rules); pub('config_ack', { type: 'rule_set', id, has2: a.length > 6 });
      }
      else if ((x = /^del_rule:(\d)$/.exec(cmd))) { rules[+x[1] - 1] = blankRule(+x[1]); pub('rules', rules); }
      else if ((x = /^set_threshold:(\w+):(-?[\d.]+)$/.exec(cmd))) pub('config_ack', { type: 'threshold_set', key: x[1], val: +x[2] });
      else if (cmd.startsWith('set_time:')) setTimeout(pubTime, 200);
      else if ((x = /^timer_(on|off) relay(\d) (\d+)$/.exec(cmd))) {
        const i = +x[2] - 1, total = +x[3], on = x[1] === 'on';
        if (timers.filter(t => t.active).length >= 4) { pub('alert', { type: 'timer_limit', val: 0, ts: 1 }); return; }
        const tm = { relay: i + 1, action: x[1], remaining: total, total, active: true };
        timers.push(tm); pub('timer_status', tm);
        const iv = setInterval(() => {
          tm.remaining--;
          if (tm.remaining % 5 === 0 || tm.remaining <= 0) pub('timer_status', tm);
          if (tm.remaining <= 0) { tm.active = false; pub('timer_status', tm); setRelay(i, on, 'timer'); clearInterval(iv); }
        }, 1000);
      }
      else if ((x = /^get_history:(\d+)$/.exec(cmd))) {
        const n = Math.min(+x[1], hist.length), pts = hist.slice(-n);
        for (let o = 0; o < n; o += 24) pub('history', { n: Math.min(24, n - o), total: n, offset: o, data: pts.slice(o, o + 24) });
      }
    };
  }

  // Pengganti library mqtt.js — antarmuka minimal yang dipakai app.js
  function FakeClient() {
    const handlers = {};
    const on = (ev, fn) => { (handlers[ev] = handlers[ev] || []).push(fn); return client; };
    const emit = (ev, ...args) => (handlers[ev] || []).forEach(fn => { try { fn(...args); } catch (e) { console.error(e); } });
    const device = new FakeESP32((t, m) => emit('message', t, { toString: () => m }));
    window.LUMINOUS_DEMO_DEVICE = device;
    const client = {
      connected: false,
      on,
      subscribe() { return client; },
      publish(t, m) { if (/\/command$/.test(t)) device.handle(String(m).trim()); return client; },
      end() { client.connected = false; return client; }
    };
    setTimeout(() => { client.connected = true; emit('connect'); }, 450);
    return client;
  }
  const fakeMqtt = { connect: () => new FakeClient() };
  // non-writable: library mqtt asli yang termuat belakangan (fallback CDN) tidak menimpa versi demo
  try { Object.defineProperty(window, 'mqtt', { value: fakeMqtt, writable: false, configurable: false }); }
  catch (e) { window.mqtt = fakeMqtt; }

  // Banner kecil penanda mode demo + tombol simulasi saklar
  function banner() {
    const bar = document.createElement('div');
    bar.className = 'demo-bar';
    bar.innerHTML = '<span class="demo-bar__tag">Demo</span><span class="demo-bar__text">Data simulasi, tidak terhubung ke ESP32</span>' +
      '<button class="demo-bar__btn" type="button">Balik saklar 1</button>';
    bar.querySelector('button').addEventListener('click', () => window.LUMINOUS_DEMO_DEVICE && window.LUMINOUS_DEMO_DEVICE.pressSwitch(1));
    document.body.insertBefore(bar, document.body.firstChild);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', banner); else banner();
})();

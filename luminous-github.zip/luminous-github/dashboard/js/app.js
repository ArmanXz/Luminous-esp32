/* =========================================================================
   LUMINOUS NEU — app.js
   Dashboard neumorphism untuk firmware Luminous v4.0 (main.ino).
   Protokol MQTT tetap sama dengan firmware: semua perintah berupa teks
   ke <prefix>/command, status dibaca dari <prefix>/relayStatus, /health, dst.
   ========================================================================= */
'use strict';

// -------------------------------------------------------------------------
// 1. KONSTANTA, KONFIGURASI & STATE
// -------------------------------------------------------------------------
const IS_HTTPS = location.protocol === 'https:';
const LS = 'lneu_';                      // prefix kunci localStorage
const N_RELAY = 4, N_SCHED = 4, N_RULE = 4, MAX_TIMERS = 4;
const TZ = 'Asia/Jakarta', TZ_OFFSET_H = 7;
const HISTORY_MAX = 240;                 // titik live yang disimpan di browser
const DEVICE_TIMEOUT_MS = 20000;         // ESP32 dianggap diam bila tak ada pesan selama ini
const SENSOR_STALE_MS = 20000;
const RELAY_ACK_TIMEOUT_MS = 5000;

const DEFAULT_CFG = {
  host: 'broker.emqx.io',
  port: IS_HTTPS ? 8084 : 8083,
  protocol: IS_HTTPS ? 'wss' : 'ws',
  path: '/mqtt',
  username: '',
  password: '',
  prefix: 'esp32'
};

const RELAY_PRESETS = [
  { key: 'bulb',    label: 'Lampu' },
  { key: 'fan',     label: 'Kipas' },
  { key: 'pump',    label: 'Pompa Air' },
  { key: 'plug',    label: 'Stop Kontak' },
  { key: 'ac',      label: 'AC' },
  { key: 'cctv',    label: 'CCTV' },
  { key: 'gate',    label: 'Gerbang / Garasi' },
  { key: 'heater',  label: 'Pemanas' },
  { key: 'router',  label: 'Router' },
  { key: 'monitor', label: 'Monitor / TV' },
  { key: 'switch',  label: 'Lainnya' }
];
const PRESET_KEYS = RELAY_PRESETS.map(p => p.key);

const DEFAULT_RELAY_META = [
  { name: 'Lampu Teras',  icon: 'bulb', watt: 10 },
  { name: 'Kipas Angin',  icon: 'fan',  watt: 45 },
  { name: 'Pompa Air',    icon: 'pump', watt: 125 },
  { name: 'Stop Kontak',  icon: 'plug', watt: 100 }
];
const DEFAULT_THRESH = { temp_hi: 37, temp_lo: 15, hum_hi: 85, hum_lo: 20 };   // = default firmware
const DEFAULT_BG = { type: 'none', url: '', overlay: 55, blur: true };
const DEFAULT_LOC = { lat: -6.2088, lon: 106.8456 };

let cfg        = Object.assign({}, DEFAULT_CFG, loadJSON('cfg', {}));
let relayMeta  = sanitizeRelayMeta(loadJSON('relayMeta', null));
let thresholds = Object.assign({}, DEFAULT_THRESH, loadJSON('thresholds', {}));
let bgSettings = Object.assign({}, DEFAULT_BG, loadJSON('bg', {}));
let location_  = Object.assign({}, DEFAULT_LOC, loadJSON('location', {}));
let alertLog   = loadJSON('alertLog', []);
let history    = loadJSON('history', []);          // [{ts(ms), t, h}]
let relayChangedAt = loadJSON('relayChangedAt', [0, 0, 0, 0]);
let relaySrc = loadJSON('relaySrc', [null, null, null, null]);   // [{src, at}] sumber perubahan terakhir (fw v4.2)

const state = {
  relay: [false, false, false, false],
  relayKnown: false,
  relaySeen: [false, false, false, false],   // per relay: sudah pernah terima status dari ESP32
  pending: [null, null, null, null],
  timer: Array.from({ length: N_RELAY }, () => ({ active: false, remaining: 0, total: 0, action: 'off' })),
  temp: null, hum: null,
  lastSensorAt: 0,
  lastDeviceMsgAt: 0,
  health: null,
  relayStats: Array.from({ length: N_RELAY }, () => null),
  schedules: Array.from({ length: N_SCHED }, (_, i) => ({ id: i + 1, active: false })),
  schedulesKnown: false,
  rules: Array.from({ length: N_RULE }, (_, i) => ({ id: i + 1, active: false })),
  rulesKnown: false,
  otaIp: null,
  sun: { sunrise: null, sunset: null },
  deviceSun: null,            // {sunrise:{h,m}, sunset:{h,m}, lat, lon} dari ESP32 (fw v4.1)
  deviceTime: null,           // {offsetMs, valid, at} — jam DS3231 relatif terhadap jam browser
  fw41: false,                // firmware mendukung topik time/sun + jadwal matahari/hari
  switches: null              // {pins, type, locked, pos} dari ESP32 (fw v4.2)
};

let client = null;
let brokerConnected = false;
let chartMode = 30;              // 30 | 60 | 120 | 'nvs'
let nvsHistory = [];             // [{ts(s, jam dinding WIB), t, h}]
let nvsBuffer = [];
let pingSentAt = 0;
let otaBusy = false;
let editingSlot = null, editingRule = null, timerRelay = null;
let pairTimer = null;

function loadJSON(key, fallback) {
  try { const raw = localStorage.getItem(LS + key); return raw ? JSON.parse(raw) : fallback; }
  catch (e) { return fallback; }
}
function saveJSON(key, val) {
  try { localStorage.setItem(LS + key, JSON.stringify(val)); return true; }
  catch (e) { return false; }
}
function sanitizeRelayMeta(meta) {
  const out = [];
  for (let i = 0; i < N_RELAY; i++) {
    const d = DEFAULT_RELAY_META[i], m = (meta && meta[i]) || {};
    out.push({
      name: (typeof m.name === 'string' && m.name.trim()) ? m.name.trim().slice(0, 32) : d.name,
      icon: PRESET_KEYS.includes(m.icon) ? m.icon : d.icon,
      watt: (typeof m.watt === 'number' && m.watt >= 0) ? m.watt : d.watt
    });
  }
  return out;
}
const $ = id => document.getElementById(id);
// Elemen 'kosong' dilepas dari DOM saat list terisi, jadi referensinya disimpan sekali
const emptyEls = {};
function emptyEl(id) { return emptyEls[id] || (emptyEls[id] = $(id)); }
['scheduleEmpty', 'ruleEmpty', 'alertLogEmpty', 'switchEmpty'].forEach(emptyEl);

// -------------------------------------------------------------------------
// 2. ICON (SVG lokal, varian light/dark)
//    icons/ui/<nama>-<light|dark>.svg  ·  icons/relay/<preset>-<on|off>-<light|dark>.svg
// -------------------------------------------------------------------------
function themeMode() { return document.body.dataset.theme === 'dark' ? 'dark' : 'light'; }
function uiIcon(name, mode) { return `icons/ui/${name}-${mode || themeMode()}.svg`; }
function relayIcon(preset, on, mode) { return `icons/relay/${preset}-${on ? 'on' : 'off'}-${mode || themeMode()}.svg`; }
function ic(name, alt) { return `<img data-icon="${name}" src="${uiIcon(name)}" alt="${alt || ''}">`; }
function refreshThemeIcons(root) {
  (root || document).querySelectorAll('img[data-icon]').forEach(el => {
    const src = uiIcon(el.dataset.icon, el.dataset.iconMode);
    if (el.getAttribute('src') !== src) el.setAttribute('src', src);
  });
}

// -------------------------------------------------------------------------
// 3. MQTT
// -------------------------------------------------------------------------
const SUB_TOPICS = ['temperature679', 'humidity679', 'relayStatus', 'health', 'relay_stats',
  'timer_status', 'rules', 'schedules', 'history', 'alert', 'pong', 'sync_ack',
  'config_ack', 'ota_status', 'ota_progress', 'status', 'time', 'sun',
  'relay_event', 'switches'];
const topic = t => `${cfg.prefix}/${t}`;

function connectMQTT() {
  if (typeof mqtt === 'undefined') {
    setConnState('offline', 'Library MQTT gagal dimuat');
    window.addEventListener('mqtt-lib-ready', connectMQTT, { once: true });
    return;
  }
  if (client) { try { client.end(true); } catch (e) {} client = null; }
  brokerConnected = false;

  let proto = cfg.protocol, port = cfg.port;
  if (IS_HTTPS && proto === 'ws') {
    // Halaman HTTPS tidak boleh membuka ws:// (mixed content) — naikkan otomatis ke wss
    proto = 'wss';
    if (port === 8083) port = 8084;
    showToast('Halaman HTTPS: koneksi otomatis memakai wss://', 'warn');
  }
  const path = cfg.path ? (cfg.path.startsWith('/') ? cfg.path : '/' + cfg.path) : '';
  const url = `${proto}://${cfg.host}:${port}${path}`;
  setConnState('connecting', 'Menghubungkan…');

  try {
    client = mqtt.connect(url, {
      clientId: 'luminous-neu-' + Math.random().toString(16).slice(2, 10),
      username: cfg.username || undefined,
      password: cfg.password || undefined,
      reconnectPeriod: 4000,
      connectTimeout: 8000,
      clean: true
    });
  } catch (e) {
    setConnState('offline', 'Konfigurasi salah');
    return;
  }
  client.on('connect', onConnect);
  client.on('reconnect', () => setConnState('connecting', 'Menyambung ulang…'));
  client.on('close', () => { brokerConnected = false; setConnState('offline', 'Terputus'); });
  client.on('offline', () => { brokerConnected = false; setConnState('offline', 'Offline'); });
  client.on('error', () => setConnState('offline', 'Gagal terhubung'));
  client.on('message', onMessage);
}

function onConnect() {
  brokerConnected = true;
  client.subscribe(SUB_TOPICS.map(topic), { qos: 0 });
  updateConnPill();
  // Minta seluruh state terbaru dari ESP32 (relay, health, rules), lalu jadwal/statistik
  sendRaw('sync');
  setTimeout(() => sendRaw('get_schedules'), 400);
  setTimeout(() => sendRaw('stats'), 800);
  setTimeout(() => sendRaw('ota_info'), 1200);
  setTimeout(() => { sendRaw('get_time'); sendRaw('get_sun'); }, 1600);   // fw v4.1 (diabaikan fw lama)
  setTimeout(() => sendRaw('get_switches'), 2000);                          // fw v4.2
  setTimeout(() => { if (brokerConnected && !state.relayKnown) sendRaw('sync'); }, 3500);
}

function setConnState(key, text) {
  const pill = $('connPill');
  pill.dataset.state = key;
  $('connText').textContent = text;
}
function deviceOnline() { return Date.now() - state.lastDeviceMsgAt < DEVICE_TIMEOUT_MS; }
function updateConnPill() {
  if (!brokerConnected) return;
  if (deviceOnline()) setConnState('online', 'ESP32 online');
  else setConnState('broker', state.lastDeviceMsgAt ? 'ESP32 diam' : 'Menunggu ESP32');
  const h = state.health;
  let sub = 'ESP32 · ' + (deviceOnline() ? 'Online' : (state.lastDeviceMsgAt ? 'Tidak merespons' : 'Menunggu data…'));
  if (deviceOnline() && h && h.rssi > -999) sub += ` · ${h.rssi} dBm`;
  $('deviceSubtitle').textContent = sub;
}

function sendRaw(cmd) {
  if (!client || !brokerConnected) return false;
  try { client.publish(topic('command'), cmd); return true; } catch (e) { return false; }
}
function sendCommand(cmd) {
  if (!sendRaw(cmd)) { showToast('Belum terhubung ke broker MQTT', 'error'); return false; }
  return true;
}

function onMessage(t, payload) {
  const key = t.slice(cfg.prefix.length + 1);
  const msg = payload.toString().trim();
  const wasOnline = deviceOnline();
  state.lastDeviceMsgAt = Date.now();
  if (!wasOnline) updateConnPill();
  try {
    switch (key) {
      case 'temperature679': onSensor('t', parseFloat(msg)); break;
      case 'humidity679':    onSensor('h', parseFloat(msg)); break;
      case 'relayStatus':    onRelayStatus(msg); break;
      case 'health':         onHealth(JSON.parse(msg)); break;
      case 'relay_stats':    onRelayStats(JSON.parse(msg)); break;
      case 'timer_status':   onTimerStatus(JSON.parse(msg)); break;
      case 'rules':          onRules(JSON.parse(msg)); break;
      case 'schedules':      onSchedules(JSON.parse(msg)); break;
      case 'history':        onHistoryBatch(JSON.parse(msg)); break;
      case 'alert':          onAlert(msg); break;
      case 'pong':           onPong(); break;
      case 'config_ack':     onConfigAck(JSON.parse(msg)); break;
      case 'ota_status':     onOtaStatus(JSON.parse(msg)); break;
      case 'ota_progress':   onOtaProgress(JSON.parse(msg)); break;
      case 'time':           onDeviceTime(JSON.parse(msg)); break;
      case 'sun':            onDeviceSun(JSON.parse(msg)); break;
      case 'relay_event':    onRelayEvent(JSON.parse(msg)); break;
      case 'switches':       onSwitches(JSON.parse(msg)); break;
      case 'status':
        if (msg === 'online' && wasOnline === false && state.relayKnown) {
          showToast('ESP32 kembali online');
          logAlert('device_online', 'ESP32 kembali online', 'info');
        }
        break;
    }
  } catch (e) {
    console.error('[mqtt] gagal memproses', t, e);
  }
}

// -------------------------------------------------------------------------
// 4. SENSOR, JAM, MATAHARI
// -------------------------------------------------------------------------
const GAUGE_CIRC = 326.7;
function onSensor(kind, val) {
  if (isNaN(val)) return;
  if (kind === 't') state.temp = val; else state.hum = val;
  state.lastSensorAt = Date.now();
  renderSensor();
  // Firmware mengirim humidity lalu temperature hampir bersamaan → gabung jadi 1 titik
  clearTimeout(pairTimer);
  pairTimer = setTimeout(pushHistory, 400);
}

function sensorLevel(v, lo, hi, margin) {
  if (v == null) return { cls: '', text: ' ' };
  if (v > hi) return { cls: 'is-alert', text: `Di atas ambang ${hi}` };
  if (v < lo) return { cls: 'is-alert', text: `Di bawah ambang ${lo}` };
  if (v > hi - margin || v < lo + margin) return { cls: 'is-warn', text: 'Mendekati ambang' };
  return { cls: '', text: 'Normal' };
}
function renderSensor() {
  const t = state.temp, h = state.hum;
  $('valSuhu').textContent = t != null ? t.toFixed(1) : '--';
  $('valLembab').textContent = h != null ? h.toFixed(1) : '--';
  $('gaugeSuhu').style.strokeDashoffset = GAUGE_CIRC * (1 - (t != null ? clamp(t / 50, 0, 1) : 0));
  $('gaugeLembab').style.strokeDashoffset = GAUGE_CIRC * (1 - (h != null ? clamp(h / 100, 0, 1) : 0));
  const ts = sensorLevel(t, thresholds.temp_lo, thresholds.temp_hi, 1.5);
  const hs = sensorLevel(h, thresholds.hum_lo, thresholds.hum_hi, 5);
  $('cardSuhu').classList.remove('is-warn', 'is-alert');
  $('cardLembab').classList.remove('is-warn', 'is-alert');
  if (ts.cls) $('cardSuhu').classList.add(ts.cls);
  if (hs.cls) $('cardLembab').classList.add(hs.cls);
  $('stateSuhu').textContent = ts.text + (ts.cls === 'is-alert' ? '°' : '');
  $('stateLembab').textContent = hs.text + (hs.cls === 'is-alert' ? '%' : '');
}

function onDeviceTime(d) {
  if (!d || typeof d.epoch !== 'number') return;
  markFw41();
  // epoch firmware = jam dinding WIB disimpan sebagai unixtime → offset terhadap jam dinding WIB browser
  const browserWall = Date.now() + TZ_OFFSET_H * 3600e3;
  state.deviceTime = { offsetMs: d.epoch * 1000 - browserWall, valid: d.valid !== false, at: Date.now() };
  tickClock();
  renderRtcInfo();
}
function deviceWallNow() {        // Date (baca dengan getter UTC) = jam dinding ESP32 saat ini
  const dt = state.deviceTime;
  return new Date(Date.now() + TZ_OFFSET_H * 3600e3 + (dt ? dt.offsetMs : 0));
}
function renderRtcInfo() {
  const el = $('rtcInfo'), dt = state.deviceTime;
  if (!dt) { el.innerHTML = 'Jam ESP32: <b>belum diketahui</b>' + (state.fw41 ? '' : ' (butuh firmware v4.1)'); el.classList.remove('is-warn'); return; }
  const w = deviceWallNow();
  const drift = Math.round(dt.offsetMs / 1000);
  let note;
  if (!dt.valid) note = 'RTC belum diset — klik Set RTC dari Browser';
  else if (Math.abs(drift) >= 60) note = `selisih ${fmtDuration(Math.abs(drift), true)} dari jam browser`;
  else note = 'sinkron dengan jam browser';
  el.innerHTML = `Jam ESP32: <b>${pad(w.getUTCHours())}:${pad(w.getUTCMinutes())}:${pad(w.getUTCSeconds())}</b> \u00b7 ${note}`;
  el.classList.toggle('is-warn', !dt.valid || Math.abs(drift) >= 60);
}
function tickClock() {
  const dt = state.deviceTime;
  const w = deviceWallNow();
  $('clockTime').textContent = `${pad(w.getUTCHours())}:${pad(w.getUTCMinutes())}:${pad(w.getUTCSeconds())}`;
  $('clockDate').textContent = `${pad(w.getUTCDate())}/${pad(w.getUTCMonth() + 1)}/${w.getUTCFullYear()}`;

  const age = state.lastSensorAt ? Date.now() - state.lastSensorAt : null;
  const label = $('sensorAge');
  const stale = age != null && age > SENSOR_STALE_MS;
  const src = dt ? (dt.valid ? 'DS3231' : 'RTC belum diset') : 'Jam browser';
  label.textContent = `${src} \u00b7 ` + (age == null ? 'menunggu sensor\u2026' : `sensor ${fmtAgo(age)}`);
  label.classList.toggle('is-stale', stale || (dt && !dt.valid));
  $('stickySummary').classList.toggle('is-stale', stale);
  if (dt && !document.querySelector('#tab-setting[hidden]')) renderRtcInfo();
  updateConnPill();
}

// Jam terbit/terbenam — algoritma NOAA, dihitung di browser dari lat/lon (WIB)
function sunTimes(lat, lon, date) {
  const rad = Math.PI / 180;
  const y = date.getUTCFullYear(), m = date.getUTCMonth() + 1, d = date.getUTCDate();
  const N1 = Math.floor(275 * m / 9), N2 = Math.floor((m + 9) / 12), N3 = (1 + Math.floor((y - 4 * Math.floor(y / 4) + 2) / 3));
  const N = N1 - (N2 * N3) + d - 30;
  const lngHour = lon / 15;
  function calc(rising) {
    const t = N + (((rising ? 6 : 18) - lngHour) / 24);
    const M = (0.9856 * t) - 3.289;
    let L = M + (1.916 * Math.sin(M * rad)) + (0.020 * Math.sin(2 * M * rad)) + 282.634;
    L = (L + 360) % 360;
    let RA = Math.atan(0.91764 * Math.tan(L * rad)) / rad;
    RA = (RA + 360) % 360;
    RA = (RA + (Math.floor(L / 90) * 90 - Math.floor(RA / 90) * 90)) / 15;
    const sinDec = 0.39782 * Math.sin(L * rad), cosDec = Math.cos(Math.asin(sinDec));
    const cosH = (Math.cos(90.833 * rad) - (sinDec * Math.sin(lat * rad))) / (cosDec * Math.cos(lat * rad));
    if (cosH > 1 || cosH < -1) return null;
    let H = rising ? 360 - Math.acos(cosH) / rad : Math.acos(cosH) / rad;
    H /= 15;
    const T = H + RA - (0.06571 * t) - 6.622;
    let UT = (T - lngHour) % 24; if (UT < 0) UT += 24;
    let local = (UT + TZ_OFFSET_H) % 24;
    const hh = Math.floor(local), mm = Math.round((local - hh) * 60);
    return mm === 60 ? { h: (hh + 1) % 24, m: 0 } : { h: hh, m: mm };
  }
  return { sunrise: calc(true), sunset: calc(false) };
}
function parseHM(str) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(str || '');
  return m ? { h: +m[1], m: +m[2] } : null;
}
function onDeviceSun(d) {
  if (!d) return;
  markFw41();
  state.deviceSun = { sunrise: parseHM(d.sunrise), sunset: parseHM(d.sunset), lat: d.lat, lon: d.lon };
  // Lokasi di ESP32 adalah sumber kebenaran untuk jadwal matahari → samakan form
  if (typeof d.lat === 'number' && typeof d.lon === 'number') {
    location_ = { lat: d.lat, lon: d.lon };
    saveJSON('location', location_);
    fillLocationForm();
  }
  updateSun();
  renderScheduleList();
}
function updateSun() {
  const wibNow = new Date(Date.now() + TZ_OFFSET_H * 3600e3);
  const s = state.deviceSun || sunTimes(location_.lat, location_.lon, wibNow);
  state.sun = s;
  $('locSunSrc').textContent = state.deviceSun ? '(dihitung di ESP32)' : '(dihitung di browser)';
  const fmt = x => x ? `${pad(x.h)}:${pad(x.m)}` : '--:--';
  $('sunriseVal').textContent = $('locSunrise').textContent = fmt(s.sunrise);
  $('sunsetVal').textContent = $('locSunset').textContent = fmt(s.sunset);
  document.querySelectorAll('.js-sunrise').forEach(e => e.textContent = fmt(s.sunrise));
  document.querySelectorAll('.js-sunset').forEach(e => e.textContent = fmt(s.sunset));
}

// -------------------------------------------------------------------------
// 5. RELAY
// -------------------------------------------------------------------------
function onRelayStatus(msg) {
  const parts = msg.split(/\s+/);
  if (parts.length < 2) return;
  const n = parseInt(parts[0].replace('relay', ''), 10);
  if (!(n >= 1 && n <= N_RELAY)) return;
  const on = parts[1].toLowerCase() === 'true' || parts[1] === '1';
  const i = n - 1;
  const p = state.pending[i];
  const before = p ? p.prev : state.relay[i];          // bandingkan dengan state sebelum UI optimistis
  if (p) { clearTimeout(p.timer); state.pending[i] = null; }
  if (state.relaySeen[i] && before !== on) { relayChangedAt[i] = Date.now(); saveJSON('relayChangedAt', relayChangedAt); }
  state.relay[i] = on;
  state.relaySeen[i] = true;
  state.relayKnown = true;
  renderRelayGrid();
  renderUsage();
}

function toggleRelay(i) {
  if (!brokerConnected) { showToast('Belum terhubung ke broker MQTT', 'error'); return; }
  const target = !state.relay[i];
  const prev = state.relay[i];
  if (state.pending[i]) clearTimeout(state.pending[i].timer);
  state.pending[i] = {
    target, prev,
    timer: setTimeout(() => {
      state.pending[i] = null;
      state.relay[i] = prev;
      renderRelayGrid();
      showToast(`${relayMeta[i].name} tidak merespons`, 'error');
    }, RELAY_ACK_TIMEOUT_MS)
  };
  state.relay[i] = target;                          // optimistic UI
  renderRelayGrid();
  sendRaw(`relay${i + 1} ${target}`);
  if (navigator.vibrate) navigator.vibrate(target ? 40 : 25);
}

function allOff() {
  const onIdx = state.relay.map((on, i) => on ? i : -1).filter(i => i >= 0);
  if (!onIdx.length) { showToast('Semua relay sudah mati'); return; }
  if (!brokerConnected) { showToast('Belum terhubung ke broker MQTT', 'error'); return; }
  onIdx.forEach((i, k) => setTimeout(() => toggleRelay(i), k * 150));
  showToast(`Mematikan ${onIdx.length} relay`);
}

function renderRelayGrid() {
  const grid = $('relayGrid');
  grid.innerHTML = relayMeta.map((meta, i) => {
    const on = !!state.relay[i];
    const tm = state.timer[i];
    const pending = !!state.pending[i];
    const src = relaySrc[i] && relayChangedAt[i] && Math.abs(relaySrc[i].at - relayChangedAt[i]) < 10000 ? SRC_LABEL[relaySrc[i].src] : '';
    const changed = relayChangedAt[i]
      ? ` <span class="relay-card__sub">${src ? `· <span class="relay-card__src">${src}</span>` : ''}<span class="relay-card__ago"> · ${fmtAgo(Date.now() - relayChangedAt[i])}</span></span>`
      : '';
    const locked = state.switches && state.switches.locked && state.switches.locked[i];
    return `
    <div class="relay-card ${on ? 'is-on' : ''} ${pending ? 'is-pending' : ''}">
      <div class="relay-card__top">
        <div class="relay-card__icon"><img src="${relayIcon(meta.icon, on)}" alt=""></div>
        <button class="toggle" data-toggle="${i}" role="switch" aria-checked="${on}" aria-label="${escapeHtml(meta.name)}"><span class="toggle__knob"></span></button>
      </div>
      <div class="relay-card__name" title="${escapeHtml(meta.name)}">${escapeHtml(meta.name)}${locked ? `<img class="relay-card__lock" data-icon="lock" src="${uiIcon('lock')}" alt="Saklar terkunci" title="Saklar fisik terkunci">` : ''}</div>
      <div class="relay-card__meta">
        <span class="relay-card__status">${pending ? 'Mengirim…' : (on ? 'Menyala' : 'Mati')}${pending ? '' : changed}</span>
        <button class="relay-card__timerbtn" data-timerbtn="${i}" aria-label="Timer ${escapeHtml(meta.name)}">${ic('stopwatch')}</button>
      </div>
      <div class="relay-card__timer" data-timerlabel="${i}" ${tm.active ? '' : 'hidden'}>${ic('hourglass')}<span>${timerText(tm)}</span></div>
      <span class="relay-card__bar" data-timerbar="${i}" style="width:${tm.active && tm.total ? (tm.remaining / tm.total * 100) : 0}%"></span>
    </div>`;
  }).join('');
  const onCount = state.relay.filter(Boolean).length;
  $('relayOnCount').textContent = `${onCount} ON`;
}

// -------------------------------------------------------------------------
// 6. TIMER
// -------------------------------------------------------------------------
function timerText(tm) { return `${tm.action === 'on' ? 'ON' : 'OFF'} dalam ${fmtDuration(tm.remaining)}`; }
function onTimerStatus(d) {
  const i = (d.relay | 0) - 1;
  if (i < 0 || i >= N_RELAY) return;
  state.timer[i] = { active: !!d.active && d.remaining > 0, remaining: d.remaining | 0, total: d.total | 0, action: d.action === 'on' ? 'on' : 'off' };
  updateTimerUI(i);
}
function updateTimerUI(i) {
  const tm = state.timer[i];
  const label = document.querySelector(`[data-timerlabel="${i}"]`);
  const bar = document.querySelector(`[data-timerbar="${i}"]`);
  if (label) { label.hidden = !tm.active; label.querySelector('span').textContent = timerText(tm); }
  if (bar) bar.style.width = (tm.active && tm.total ? tm.remaining / tm.total * 100 : 0) + '%';
}
setInterval(() => {
  state.timer.forEach((t, i) => {
    if (t.active) {
      t.remaining = Math.max(0, t.remaining - 1);
      if (t.remaining === 0) t.active = false;
      updateTimerUI(i);
    }
  });
}, 1000);

function openTimerModal(i) {
  timerRelay = i;
  $('timerModalRelayName').textContent = '— ' + relayMeta[i].name;
  $('timerAction').value = state.relay[i] ? 'off_after' : 'on_then_off';
  openModal('timerModal');
}
function startTimer() {
  const i = timerRelay;
  const sec = Math.round((+$('timerDuration').value || 0) * (+$('timerUnit').value));
  if (sec <= 0) { showToast('Durasi harus lebih dari 0', 'error'); return; }
  if (sec > 86400) { showToast('Durasi maksimal 24 jam', 'error'); return; }
  const active = state.timer.filter(t => t.active).length;
  if (active >= MAX_TIMERS) { showToast('Sudah ada 4 timer aktif', 'error'); return; }
  const act = $('timerAction').value;
  const r = `relay${i + 1}`;
  if (!brokerConnected) { showToast('Belum terhubung ke broker MQTT', 'error'); return; }
  if (act === 'on_then_off') {
    if (!state.relay[i]) toggleRelay(i);
    setTimeout(() => sendRaw(`timer_off ${r} ${sec}`), 250);
  } else if (act === 'off_after') {
    sendRaw(`timer_off ${r} ${sec}`);
  } else {
    sendRaw(`timer_on ${r} ${sec}`);
  }
  closeModal('timerModal');
  showToast(`Timer ${relayMeta[i].name}: ${fmtDuration(sec)}`);
}

// -------------------------------------------------------------------------
// 7. JADWAL NVS (4 slot)
// -------------------------------------------------------------------------
const REPEAT_LABEL = { daily: 'Setiap hari', none: 'Sekali', weekly: 'Mingguan' };
const DAY_SHORT = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];   // indeks = bit (0 = Minggu)
const ALL_DAYS = 0x7F;
let schMode = 'fixed';
function markFw41() {
  if (state.fw41) return;
  state.fw41 = true;
  const h = $('schFwHint'); if (h) h.hidden = true;
  renderRtcInfo();
}
function daysLabel(mask) {
  mask = mask & ALL_DAYS;
  if (mask === ALL_DAYS) return 'Setiap hari';
  if (mask === 0x3E) return 'Senin\u2013Jumat';
  if (mask === 0x41) return 'Akhir pekan';
  const order = [1, 2, 3, 4, 5, 6, 0];
  return order.filter(d => mask & (1 << d)).map(d => DAY_SHORT[d]).join(', ');
}
function repeatText(s) {
  if (s.repeat === 'weekly') return state.fw41 ? daysLabel(s.days == null ? ALL_DAYS : s.days) : 'Mingguan (fw lama: tiap hari)';
  return REPEAT_LABEL[s.repeat] || s.repeat;
}
function sunOffsetText(mode, off) {
  const base = mode === 'sunrise' ? 'Terbit' : 'Terbenam';
  if (!off) return base;
  return `${base} ${off > 0 ? '+' : '\u2212'}${Math.abs(off)} mnt`;
}
// Menit sampai jadwal berikutnya jalan (memperhitungkan hari untuk weekly)
function minutesUntilSched(s) {
  const now = new Date(Date.now() + TZ_OFFSET_H * 3600e3);
  const cur = now.getUTCHours() * 60 + now.getUTCMinutes();
  const dow = now.getUTCDay();
  const tgt = s.hour * 60 + s.minute;
  const mask = s.repeat === 'weekly' && state.fw41 ? (s.days == null ? ALL_DAYS : s.days) : ALL_DAYS;
  for (let k = 0; k <= 7; k++) {
    const day = (dow + k) % 7;
    if (!(mask & (1 << day))) continue;
    const diff = k * 1440 + tgt - cur;
    if (diff > 0) return diff;
  }
  return 7 * 1440;
}
function onSchedules(d) {
  const slots = (d && d.slots) || [];
  if (slots.length && 'mode' in slots[0]) markFw41();
  slots.forEach(s => {
    const i = (s.id | 0) - 1;
    if (i >= 0 && i < N_SCHED) state.schedules[i] = s;
  });
  state.schedulesKnown = true;
  renderScheduleList();
}
function renderScheduleList() {
  const list = $('scheduleList'), empty = emptyEl('scheduleEmpty');
  const active = state.schedules.filter(s => s.active);
  $('schedCount').textContent = `${active.length}/${N_SCHED}`;
  if (!active.length) { list.innerHTML = ''; list.appendChild(empty); empty.hidden = false; return; }
  empty.hidden = true;
  const sorted = active.slice().sort((a, b) => minutesUntilSched(a) - minutesUntilSched(b));
  const nextId = sorted[0].id;
  list.innerHTML = sorted.map(s => {
    const meta = relayMeta[s.relay - 1] || { name: 'Relay ' + s.relay, icon: 'switch' };
    const on = s.action === 'on';
    const inMin = minutesUntilSched(s);
    const isSun = s.mode === 'sunrise' || s.mode === 'sunset';
    const when = isSun ? `${sunOffsetText(s.mode, s.offset)} (${pad(s.hour)}:${pad(s.minute)})` : `${pad(s.hour)}:${pad(s.minute)}`;
    return `
    <div class="item-card ${s.id === nextId ? 'is-next' : ''}">
      <div class="item-card__icon item-card__icon--relay"><img src="${relayIcon(meta.icon, on)}" alt=""></div>
      <div class="item-card__body">
        <div class="item-card__title">${when} \u00b7 ${escapeHtml(meta.name)} <span class="${on ? 'pill-on' : 'pill-off'}">${on ? 'ON' : 'OFF'}</span>${s.id === nextId ? '<span class="tag-next">Berikutnya</span>' : ''}</div>
        <div class="item-card__sub">${escapeHtml(repeatText(s))} \u00b7 slot ${s.id} \u00b7 ${fmtDuration(inMin * 60, true)} lagi</div>
      </div>
      <div class="item-card__actions">
        <button class="chip-btn" data-sch-edit="${s.id}" aria-label="Ubah jadwal">${ic('edit')}</button>
        <button class="chip-btn chip-btn--danger" data-sch-del="${s.id}" aria-label="Hapus jadwal">${ic('trash')}</button>
      </div>
    </div>`;
  }).join('');
}
function setSchMode(mode) {
  schMode = mode;
  document.querySelectorAll('#schModePicker .segmented__btn').forEach(b => {
    b.classList.toggle('is-active', b.dataset.mode === mode);
    b.setAttribute('aria-checked', b.dataset.mode === mode);
  });
  $('schTimeWrap').hidden = mode !== 'fixed';
  $('schSunWrap').hidden = mode === 'fixed';
  updateSchPreview();
}
function readDays() {
  let mask = 0;
  document.querySelectorAll('#schDays button.is-active').forEach(b => { mask |= 1 << +b.dataset.day; });
  return mask;
}
function setDays(mask) {
  document.querySelectorAll('#schDays button').forEach(b => b.classList.toggle('is-active', !!(mask & (1 << +b.dataset.day))));
}
function updateSchPreview() {
  const rep = $('schRepeat').value;
  $('schDays').hidden = rep !== 'weekly';
  const relayName = (relayMeta[+$('schRelay').value - 1] || {}).name || 'Relay';
  const act = $('schAction').value === 'on' ? 'ON' : 'OFF';
  let when;
  if (schMode === 'fixed') when = `jam <b>${escapeHtml($('schTime').value || '--:--')}</b>`;
  else {
    const off = parseInt($('schOffset').value, 10) || 0;
    const base = state.sun[schMode];
    const t = base ? ((base.h * 60 + base.m + off) % 1440 + 1440) % 1440 : null;
    when = `<b>${escapeHtml(sunOffsetText(schMode, off))}</b>` + (t != null ? ` (hari ini ${pad(Math.floor(t / 60))}:${pad(t % 60)}, ikut bergeser tiap hari)` : '');
  }
  const days = rep === 'weekly' ? (readDays() ? daysLabel(readDays()) : '<b>pilih minimal 1 hari</b>') : rep === 'none' ? 'sekali saja' : 'setiap hari';
  $('schPreview').innerHTML = `${escapeHtml(relayName)} <b>${act}</b> ${when}, ${days}.`;
}
function openScheduleModal(id) {
  let slot = id;
  if (slot == null) {
    const free = state.schedules.find(s => !s.active);
    if (!free) { showToast('4 slot jadwal sudah terpakai \u2014 hapus salah satu dulu', 'error'); return; }
    slot = free.id;
  }
  editingSlot = slot;
  const s = state.schedules[slot - 1];
  const ex = s && s.active;
  const mode = ex && (s.mode === 'sunrise' || s.mode === 'sunset') ? s.mode : 'fixed';
  $('schSlotLabel').textContent = `\u2014 slot ${slot}`;
  $('schRelay').value = ex ? s.relay : 1;
  $('schAction').value = ex ? s.action : 'on';
  $('schTime').value = ex && mode === 'fixed' ? `${pad(s.hour)}:${pad(s.minute)}` : '18:00';
  $('schOffset').value = ex && mode !== 'fixed' ? (s.offset || 0) : 0;
  $('schRepeat').value = ex ? (['daily', 'weekly', 'none'].includes(s.repeat) ? s.repeat : 'daily') : 'daily';
  const today = new Date(Date.now() + TZ_OFFSET_H * 3600e3).getUTCDay();
  setDays(ex && s.repeat === 'weekly' && s.days != null ? s.days : (1 << today));
  $('schFwHint').hidden = state.fw41;
  // Firmware lama tidak mengenal mode matahari → nonaktifkan pilihannya
  document.querySelectorAll('#schModePicker [data-mode]').forEach(b => { b.disabled = !state.fw41 && b.dataset.mode !== 'fixed'; });
  updateSun();
  setSchMode(mode);
  openModal('scheduleModal');
}
function saveSchedule() {
  const relay = +$('schRelay').value, action = $('schAction').value, rep = $('schRepeat').value;
  let hh = 0, mm = 0, off = 0, days = ALL_DAYS;
  if (schMode === 'fixed') {
    const tv = $('schTime').value;
    if (!tv) { showToast('Pilih jam dulu', 'error'); return; }
    [hh, mm] = tv.split(':').map(Number);
  } else {
    if (!state.fw41) { showToast('Jadwal matahari butuh firmware v4.1 di ESP32', 'error'); return; }
    off = parseInt($('schOffset').value, 10) || 0;
    if (Math.abs(off) > 720) { showToast('Selisih maksimal \u00b1720 menit', 'error'); return; }
    const base = state.sun[schMode];
    if (base) { const t = ((base.h * 60 + base.m + off) % 1440 + 1440) % 1440; hh = Math.floor(t / 60); mm = t % 60; }
  }
  if (rep === 'weekly') {
    days = readDays();
    if (!days) { showToast('Pilih minimal satu hari', 'error'); return; }
  }
  // Format v4.1; firmware v4.0 cukup membaca 6 token pertama (kompatibel mundur)
  const cmd = `save_schedule:${editingSlot}:${relay}:${action}:${pad(hh)}:${pad(mm)}:${rep}:${days}:${schMode}:${off}`;
  if (!sendCommand(cmd)) return;
  state.schedules[editingSlot - 1] = { id: editingSlot, active: true, relay, action, hour: hh, minute: mm, repeat: rep, days, mode: schMode, offset: off };
  renderScheduleList();
  closeModal('scheduleModal');
  showToast('Jadwal dikirim ke ESP32');
  setTimeout(() => sendRaw('get_schedules'), 2500);
}
async function deleteSchedule(id) {
  if (!(await confirmDialog(`Hapus jadwal slot ${id}?`))) return;
  if (!sendCommand(`del_schedule:${id}`)) return;
  state.schedules[id - 1] = { id, active: false };
  renderScheduleList();
  showToast('Jadwal dihapus');
}

// -------------------------------------------------------------------------
// 8. AUTOMATION RULES (4 slot, dukung kondisi AND)
// -------------------------------------------------------------------------
const SENSOR_LBL = { temp: 'Suhu', hum: 'Kelembaban' };
const UNIT = { temp: '°C', hum: '%' };
const COND_SYM = { above: '>', below: '<' };
function onRules(arr) {
  if (!Array.isArray(arr)) return;
  arr.forEach(r => { const i = (r.id | 0) - 1; if (i >= 0 && i < N_RULE) state.rules[i] = r; });
  state.rulesKnown = true;
  renderRuleList();
}
function ruleText(r, html) {
  const b = s => html ? `<b>${s}</b>` : s;
  const meta = relayMeta[r.relay - 1] || { name: 'Relay ' + r.relay };
  let s = `Jika ${SENSOR_LBL[r.sensor]} ${b(COND_SYM[r.cond] + ' ' + num(r.val) + UNIT[r.sensor])}`;
  if (r.has2) s += ` dan ${SENSOR_LBL[r.sensor2]} ${b(COND_SYM[r.cond2] + ' ' + num(r.val2) + UNIT[r.sensor2])}`;
  s += ` → ${html ? escapeHtml(meta.name) : meta.name} ${b(r.action === 'on' ? 'ON' : 'OFF')}`;
  return s;
}
function renderRuleList() {
  const list = $('ruleList'), empty = emptyEl('ruleEmpty');
  const active = state.rules.filter(r => r.active);
  $('ruleCount').textContent = `${active.length}/${N_RULE}`;
  if (!active.length) { list.innerHTML = ''; list.appendChild(empty); empty.hidden = false; return; }
  empty.hidden = true;
  list.innerHTML = active.map(r => {
    const meta = relayMeta[r.relay - 1] || { name: 'Relay ' + r.relay };
    const on = r.action === 'on';
    const s1 = `${SENSOR_LBL[r.sensor]} ${COND_SYM[r.cond]} ${num(r.val)}${UNIT[r.sensor]}`;
    const s2 = r.has2 ? ` & ${SENSOR_LBL[r.sensor2]} ${COND_SYM[r.cond2]} ${num(r.val2)}${UNIT[r.sensor2]}` : '';
    return `
    <div class="item-card">
      <div class="item-card__icon">${ic(r.sensor === 'hum' ? 'droplet' : 'thermometer')}</div>
      <div class="item-card__body">
        <div class="item-card__title">${escapeHtml(s1 + s2)} → ${escapeHtml(meta.name)} <span class="${on ? 'pill-on' : 'pill-off'}">${on ? 'ON' : 'OFF'}</span></div>
        <div class="item-card__sub">Rule #${r.id}${r.has2 ? ' · kondisi DAN' : ''}</div>
      </div>
      <div class="item-card__actions">
        <button class="chip-btn" data-rule-edit="${r.id}" aria-label="Ubah rule">${ic('edit')}</button>
        <button class="chip-btn chip-btn--danger" data-rule-del="${r.id}" aria-label="Hapus rule">${ic('trash')}</button>
      </div>
    </div>`;
  }).join('');
}
function readRuleForm() {
  return {
    sensor: $('ruleSensor').value, cond: $('ruleCond').value, val: parseFloat($('ruleVal').value),
    has2: $('ruleHas2').checked,
    sensor2: $('ruleSensor2').value, cond2: $('ruleCond2').value, val2: parseFloat($('ruleVal2').value),
    relay: +$('ruleRelay').value, action: $('ruleAction').value
  };
}
function updateRulePreview() {
  $('ruleCond2Wrap').hidden = !$('ruleHas2').checked;
  const r = readRuleForm();
  if (isNaN(r.val) || (r.has2 && isNaN(r.val2))) { $('rulePreview').textContent = 'Isi nilai ambang.'; return; }
  $('rulePreview').innerHTML = ruleText(r, true);
}
function openRuleModal(id) {
  let slot = id;
  if (slot == null) {
    const free = state.rules.find(r => !r.active);
    if (!free) { showToast('4 slot rule sudah terpakai — hapus salah satu dulu', 'error'); return; }
    slot = free.id;
  }
  editingRule = slot;
  const r = state.rules[slot - 1];
  const ex = r && r.active;
  $('ruleSlotLabel').textContent = `#${slot}`;
  $('ruleSensor').value = ex ? r.sensor : 'temp';
  $('ruleCond').value = ex ? r.cond : 'above';
  $('ruleVal').value = ex ? r.val : 30;
  $('ruleHas2').checked = ex ? !!r.has2 : false;
  $('ruleSensor2').value = ex && r.has2 ? r.sensor2 : 'hum';
  $('ruleCond2').value = ex && r.has2 ? r.cond2 : 'above';
  $('ruleVal2').value = ex && r.has2 ? r.val2 : 70;
  $('ruleRelay').value = ex ? r.relay : 2;
  $('ruleAction').value = ex ? r.action : 'on';
  updateRulePreview();
  openModal('ruleModal');
}
function saveRule() {
  const r = readRuleForm();
  if (isNaN(r.val) || (r.has2 && isNaN(r.val2))) { showToast('Nilai ambang tidak valid', 'error'); return; }
  let cmd = `set_rule:${editingRule}:${r.sensor}:${r.cond}:${r.val}:${r.relay}:${r.action}`;
  if (r.has2) cmd += `:${r.sensor2}:${r.cond2}:${r.val2}`;
  if (!sendCommand(cmd)) return;
  state.rules[editingRule - 1] = Object.assign({ id: editingRule, active: true }, r);
  renderRuleList();
  closeModal('ruleModal');
  showToast('Rule dikirim ke ESP32');
}
async function deleteRule(id) {
  if (!(await confirmDialog(`Hapus rule #${id}?`))) return;
  if (!sendCommand(`del_rule:${id}`)) return;
  state.rules[id - 1] = { id, active: false };
  renderRuleList();
  showToast('Rule dihapus');
}

// -------------------------------------------------------------------------
// 9. ANALITIK: statistik, pemakaian relay, kesehatan perangkat
// -------------------------------------------------------------------------
function onHealth(d) {
  state.health = d;
  if (state.temp == null && d.temp) { state.temp = d.temp; state.hum = d.hum; renderSensor(); }
  renderHealth();
  renderStats();
  updateConnPill();
}
function renderStats() {
  const d = state.health;
  const has = d && d.stat_n > 0;
  $('statN').textContent = has ? `${d.stat_n} sampel sejak ESP32 menyala` : '';
  const set = (id, v, u) => { $(id).textContent = has ? num(v) + u : '--'; };
  set('tMin', has && d.t_min, '°'); set('tAvg', has && d.t_avg, '°'); set('tMax', has && d.t_max, '°');
  set('hMin', has && d.h_min, '%');      set('hAvg', has && d.h_avg, '%');      set('hMax', has && d.h_max, '%');
  const bar = (fill, dot, min, max, cur, scale) => {
    if (!has) { $(fill).style.width = '0'; $(dot).style.opacity = 0; return; }
    const a = clamp(min / scale, 0, 1) * 100, b = clamp(max / scale, 0, 1) * 100;
    $(fill).style.left = a + '%'; $(fill).style.width = Math.max(1, b - a) + '%';
    if (cur != null) { $(dot).style.left = clamp(cur / scale, 0, 1) * 100 + '%'; $(dot).style.opacity = 1; }
  };
  bar('tRange', 'tDot', has && d.t_min, has && d.t_max, state.temp, 50);
  bar('hRange', 'hDot', has && d.h_min, has && d.h_max, state.hum, 100);
}
function rssiQuality(r) {
  if (r == null || r <= -999) return { t: 'Tidak terhubung', c: 'q-bad' };
  if (r >= -55) return { t: 'Sangat kuat', c: 'q-strong' };
  if (r >= -67) return { t: 'Baik', c: 'q-good' };
  if (r >= -78) return { t: 'Lemah', c: 'q-weak' };
  return { t: 'Buruk', c: 'q-bad' };
}
function renderHealth() {
  const d = state.health;
  if (!d) return;
  $('hUptime').textContent = fmtDuration(d.uptime, true);
  const q = rssiQuality(d.rssi);
  $('hRssi').textContent = d.rssi > -999 ? `${d.rssi} dBm` : '--';
  $('hRssiQ').textContent = q.t; $('hRssiQ').className = 'health-tile__sub ' + q.c;
  $('hHeap').textContent = (d.heap / 1024).toFixed(0) + ' KB';
  $('hHeapMin').textContent = `terendah ${(d.heap_min / 1024).toFixed(0)} KB`;
  $('hTimers').textContent = d.timers;
  $('hHist').textContent = d.hist_cnt;
}
function onPong() {
  if (!pingSentAt) return;
  $('hPing').textContent = (Date.now() - pingSentAt) + ' ms';
  pingSentAt = 0;
}
function onRelayStats(d) {
  const i = (d.relay | 0) - 1;
  if (i < 0 || i >= N_RELAY) return;
  state.relayStats[i] = { on_ms: d.on_ms, cycles: d.cycles, is_on: !!d.is_on, at: Date.now() };
  renderUsage();
}
function renderUsage() {
  const rows = relayMeta.map((m, i) => {
    const s = state.relayStats[i];
    let ms = s ? s.on_ms : 0;
    if (s && s.is_on && state.relay[i]) ms += Date.now() - s.at;    // tambah waktu berjalan sejak data terakhir
    return { m, i, ms, cycles: s ? s.cycles : null, kwh: m.watt * ms / 3.6e9 };
  });
  const maxMs = Math.max(1, ...rows.map(r => r.ms));
  $('usageList').innerHTML = rows.map(r => `
    <div class="usage-row">
      <div class="usage-row__icon"><img src="${relayIcon(r.m.icon, state.relay[r.i])}" alt=""></div>
      <div>
        <div class="usage-row__name">${escapeHtml(r.m.name)}</div>
        <div class="usage-row__sub">${r.cycles == null ? 'belum ada data' : r.ms < 1000 ? `belum pernah ON · ${r.m.watt} W` : `ON ${fmtDuration(Math.round(r.ms / 1000), true)} · ${r.cycles} siklus · ${r.m.watt} W`}</div>
        <div class="usage-row__bar"><span style="width:${r.ms / maxMs * 100}%"></span></div>
      </div>
      <div class="usage-row__kwh">${r.kwh.toFixed(3)}<small>kWh</small></div>
    </div>`).join('');
  $('usageTotal').textContent = rows.reduce((a, r) => a + r.kwh, 0).toFixed(3) + ' kWh';
}

// -------------------------------------------------------------------------
// 10. ALERT & NOTIFIKASI
// -------------------------------------------------------------------------
function onAlert(msg) {
  let type = msg, val = null, text, level = 'warn', icon = 'alert';
  try {
    const d = JSON.parse(msg);
    type = d.type; val = d.val;
    if (type === 'rule_fired') {
      const meta = relayMeta[d.relay - 1] || { name: 'Relay ' + d.relay };
      text = `Rule #${d.rule}: ${meta.name} ${String(d.action).toUpperCase()} (nilai ${d.val})`;
      level = 'rule'; icon = 'robot';
    }
  } catch (e) { /* payload teks biasa */ }
  if (!text) {
    const map = {
      temp_hi: [`Suhu tinggi: ${num(val)}°C`, 'thermometer'],
      temp_lo: [`Suhu rendah: ${num(val)}°C`, 'thermometer'],
      hum_hi:  [`Kelembaban tinggi: ${num(val)}%`, 'droplet'],
      hum_lo:  [`Kelembaban rendah: ${num(val)}%`, 'droplet'],
      dht_fail: ['Sensor DHT gagal dibaca', 'alert'],
      timer_limit: ['Timer ditolak: maksimal 4 timer aktif', 'stopwatch'],
      switch_locked: [`Saklar ${(relayMeta[(val | 0) - 1] || { name: 'relay ' + val }).name} sedang dikunci dari dashboard`, 'lock']
    };
    const m = map[type];
    text = m ? m[0] : `Alert: ${type}${val != null ? ' (' + val + ')' : ''}`;
    icon = m ? m[1] : 'alert';
    if (type === 'dht_fail') level = 'error';
  }
  logAlert(type, text, level, icon);
  showToast(text, level === 'error' ? 'error' : 'warn');
  if (navigator.vibrate && level !== 'rule') navigator.vibrate([80, 40, 80]);
  if (loadJSON('notifBrowser', false) && typeof Notification !== 'undefined' && Notification.permission === 'granted') {
    try { new Notification('Luminous — Alert', { body: text, tag: type, icon: uiIcon('logo', 'light') }); } catch (e) {}
  }
}
function logAlert(type, msg, level, icon) {
  alertLog.unshift({ type, msg, level, icon: icon || 'bell', at: Date.now() });
  if (alertLog.length > 30) alertLog.length = 30;
  saveJSON('alertLog', alertLog);
  renderAlertLog();
}
function renderAlertLog() {
  const list = $('alertLogList'), empty = emptyEl('alertLogEmpty');
  if (!alertLog.length) { list.innerHTML = ''; list.appendChild(empty); empty.hidden = false; return; }
  empty.hidden = true;
  list.innerHTML = alertLog.map(a => `
    <div class="item-card alert-item ${a.level === 'error' ? 'is-error' : a.level === 'rule' ? 'is-rule' : ''}">
      <div class="item-card__icon">${ic(a.icon || 'bell')}</div>
      <div class="item-card__body">
        <div class="item-card__title">${escapeHtml(a.msg)}</div>
        <div class="item-card__sub">${fmtDateTime(a.at)} · ${fmtAgo(Date.now() - a.at)}</div>
      </div>
    </div>`).join('');
}
function onConfigAck(d) {
  if (d.type === 'schedule_set') showToast(`Jadwal slot ${d.slot} tersimpan di ESP32`);
  else if (d.type === 'location_set') showToast('Lokasi tersimpan di ESP32, jam matahari dihitung ulang');
  else if (d.type === 'rule_set') showToast(`Rule #${d.id} tersimpan di ESP32`);
  else if (d.type === 'threshold_set') {
    thresholds[d.key] = d.val; saveJSON('thresholds', thresholds); renderSensor();
  }
}

// -------------------------------------------------------------------------
// 11. GRAFIK (Chart.js) — dua grafik kecil (suhu & kelembaban), tanpa sumbu ganda
// -------------------------------------------------------------------------
let chartT = null, chartH = null;
function pushHistory() {
  if (state.temp == null || state.hum == null) return;
  history.push({ ts: Date.now(), t: state.temp, h: state.hum });
  if (history.length > HISTORY_MAX) history = history.slice(-HISTORY_MAX);
  saveJSON('history', history);
  if (chartMode !== 'nvs') updateChart();
  if (document.querySelector('#tab-analitik:not([hidden])')) renderStats();
}
function cssVar(name) { return getComputedStyle(document.body).getPropertyValue(name).trim(); }
function hexA(hex, a) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
function makeChart(canvas, color, unit) {
  return new Chart(canvas.getContext('2d'), {
    type: 'line',
    data: { labels: [], datasets: [{
      data: [], borderColor: color, backgroundColor: hexA(color, .10), fill: true,
      tension: .35, pointRadius: 0, pointHoverRadius: 4, pointHoverBorderWidth: 2,
      pointHoverBackgroundColor: color, pointHoverBorderColor: cssVar('--surface'), borderWidth: 2
    }] },
    options: {
      responsive: true, maintainAspectRatio: false, animation: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          displayColors: false, backgroundColor: cssVar('--surface'), titleColor: cssVar('--text-soft'),
          bodyColor: cssVar('--text'), borderColor: cssVar('--shadow-dark'), borderWidth: 1, padding: 10,
          titleFont: { family: "'JetBrains Mono', ui-monospace, monospace", size: 11 }, bodyFont: { family: "'JetBrains Mono', ui-monospace, monospace", size: 13, weight: '700' },
          callbacks: { label: c => `${num(c.parsed.y)} ${unit}` }
        }
      },
      scales: {
        y: { grace: '8%', border: { display: false }, grid: { color: hexA(cssVar('--text-soft'), .12) },
             ticks: { color: cssVar('--text-soft'), font: { family: "'JetBrains Mono', ui-monospace, monospace", size: 10 }, maxTicksLimit: 4 } },
        x: { border: { display: false }, grid: { display: false },
             ticks: { color: cssVar('--text-soft'), font: { family: "'JetBrains Mono', ui-monospace, monospace", size: 9 }, maxRotation: 0, autoSkip: true, maxTicksLimit: 6 } }
      }
    },
    plugins: [{   // garis bantu vertikal saat hover (crosshair)
      id: 'crosshair',
      afterDraw(chart) {
        const a = chart.tooltip && chart.tooltip.getActiveElements();
        if (!a || !a.length) return;
        const x = a[0].element.x, { top, bottom } = chart.chartArea, ctx = chart.ctx;
        ctx.save(); ctx.strokeStyle = hexA(cssVar('--text-soft'), .35); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x, bottom); ctx.stroke(); ctx.restore();
      }
    }]
  });
}
function initChart() {
  if (typeof Chart === 'undefined') {
    console.warn('[chart] Chart.js belum termuat — grafik dilewati, fitur lain tetap jalan.');
    window.addEventListener('chart-lib-ready', initChart, { once: true });
    return;
  }
  chartT = makeChart($('chartTemp'), cssVar('--series-temp'), '°C');
  chartH = makeChart($('chartHum'), cssVar('--series-hum'), '%');
  updateChart();
}
function restyleCharts() {
  [[chartT, '--series-temp'], [chartH, '--series-hum']].forEach(([c, v]) => {
    if (!c) return;
    const col = cssVar(v), ds = c.data.datasets[0];
    ds.borderColor = col; ds.backgroundColor = hexA(col, .10);
    ds.pointHoverBackgroundColor = col; ds.pointHoverBorderColor = cssVar('--surface');
    const tt = c.options.plugins.tooltip;
    tt.backgroundColor = cssVar('--surface'); tt.titleColor = cssVar('--text-soft'); tt.bodyColor = cssVar('--text'); tt.borderColor = cssVar('--shadow-dark');
    c.options.scales.y.grid.color = hexA(cssVar('--text-soft'), .12);
    c.options.scales.y.ticks.color = c.options.scales.x.ticks.color = cssVar('--text-soft');
    c.update('none');
  });
}
function updateChart() {
  let pts;
  if (chartMode === 'nvs') pts = nvsHistory.map(p => ({ label: fmtWallClock(p.ts * 1000, nvsHistory), t: p.t, h: p.h }));
  else pts = history.slice(-chartMode).map(p => ({ label: fmtTimeWIB(p.ts), t: p.t, h: p.h }));
  const card = document.querySelector('.chart-card');
  card.classList.toggle('is-empty', !pts.length);
  const last = pts[pts.length - 1];
  $('chartLastTemp').textContent = last ? `${num(last.t)}°C` : '';
  $('chartLastHum').textContent = last ? `${num(last.h)}%` : '';
  if (!chartT || !chartH) return;
  [chartT, chartH].forEach((c, k) => {
    c.data.labels = pts.map(p => p.label);
    c.data.datasets[0].data = pts.map(p => k === 0 ? p.t : p.h);
    c.update('none');
  });
}
function setChartRange(range) {
  chartMode = range === 'nvs' ? 'nvs' : +range;
  if (chartMode === 'nvs') {
    $('chartNote').textContent = 'Memuat riwayat 24 jam dari NVS ESP32…';
    nvsBuffer = [];
    if (!sendCommand('get_history:288')) $('chartNote').textContent = 'Butuh koneksi ke ESP32 untuk memuat riwayat NVS.';
  } else {
    $('chartNote').textContent = `Data live dari MQTT, ${chartMode} sampel terakhir (±5 detik per sampel).`;
  }
  updateChart();
}
function onHistoryBatch(d) {
  if (!d || d.n === 0 && !d.total) {
    nvsHistory = [];
    if (chartMode === 'nvs') { $('chartNote').textContent = 'Belum ada riwayat di NVS (ESP32 menyimpan 1 titik tiap 5 menit).'; updateChart(); }
    return;
  }
  if (d.offset === 0) nvsBuffer = [];
  nvsBuffer.push(...(d.data || []).filter(p => p.ts > 0));
  if (d.offset + d.n >= d.total) {
    nvsHistory = nvsBuffer.slice().sort((a, b) => a.ts - b.ts);
    if (chartMode === 'nvs') {
      $('chartNote').textContent = `Riwayat NVS: ${nvsHistory.length} titik (tiap 5 menit, maks 24 jam).`;
      updateChart();
    }
  }
}

// -------------------------------------------------------------------------
// 12. TAB & DOCK
// -------------------------------------------------------------------------
function initTabs() {
  const buttons = document.querySelectorAll('.dock__btn');
  const indicator = $('dockIndicator');
  const move = btn => {
    if (!btn) return;
    const base = parseFloat(getComputedStyle(indicator).left) || 0;
    indicator.style.width = btn.offsetWidth + 'px';
    indicator.style.transform = `translateX(${btn.offsetLeft - base}px)`;
  };
  const activate = (btn, save) => {
    document.querySelectorAll('[data-panel]').forEach(p => { p.hidden = (p.id !== btn.dataset.tab); });
    buttons.forEach(b => { b.classList.toggle('is-active', b === btn); b.setAttribute('aria-current', b === btn ? 'page' : 'false'); });
    move(btn);
    if (save) saveJSON('tab', btn.dataset.tab);
    if (btn.dataset.tab === 'tab-analitik') { renderStats(); renderUsage(); }
    if (btn.dataset.tab === 'tab-kontrol' && chartT) { chartT.resize(); chartH.resize(); }
  };
  buttons.forEach(b => b.addEventListener('click', () => { activate(b, true); window.scrollTo({ top: 0, behavior: 'smooth' }); }));
  const saved = loadJSON('tab', 'tab-kontrol');
  activate(document.querySelector(`.dock__btn[data-tab="${saved}"]`) || buttons[0], false);
  const re = () => move(document.querySelector('.dock__btn.is-active'));
  window.addEventListener('resize', re);
  window.addEventListener('load', re);
  setTimeout(re, 80);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(re);
}
function initStickyObserver() {
  if (typeof IntersectionObserver === 'undefined') return;
  new IntersectionObserver(es => es.forEach(e => $('stickySummary').classList.toggle('is-stuck', !e.isIntersecting)))
    .observe($('stickySentinel'));
}

// -------------------------------------------------------------------------
// 13. TEMA & LATAR BELAKANG
// -------------------------------------------------------------------------
let themeAnimTimer = null;
function applyTheme(theme, animate) {
  if (animate) {                     // transisi warna & bayangan serempak saat ganti tema
    document.documentElement.classList.add('theme-anim');
    clearTimeout(themeAnimTimer);
    themeAnimTimer = setTimeout(() => document.documentElement.classList.remove('theme-anim'), 520);
  }
  document.body.dataset.theme = theme;
  saveJSON('theme', theme);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', theme === 'dark' ? '#272B33' : '#E6EAF0');
  const fav = document.querySelector('link[rel="icon"]');
  if (fav) fav.href = uiIcon('logo', theme);
  refreshThemeIcons();
  renderRelayGrid();
  renderScheduleList();
  renderUsage();
  renderRelayMetaForm(true);
  renderSwitchList();
  restyleCharts();
  applyBackground();
}
function applyBackground() {
  const img = $('bgLayerImage'), ov = $('bgLayerOverlay');
  let src = null;
  if (bgSettings.type === 'url' && bgSettings.url) src = bgSettings.url;
  else if (bgSettings.type === 'upload') { try { src = localStorage.getItem(LS + 'bgImage'); } catch (e) {} }
  if (src) {
    img.style.backgroundImage = `url("${src.replace(/"/g, '%22')}")`;
    img.style.filter = bgSettings.blur ? 'blur(14px)' : 'none';
    ov.style.opacity = (bgSettings.overlay || 55) / 100;
    document.body.classList.add('has-bg');
  } else {
    img.style.backgroundImage = 'none';
    ov.style.opacity = 1;
    document.body.classList.remove('has-bg');
  }
}
let pendingUpload = null;
function initBackgroundForm() {
  const pick = type => {
    document.querySelectorAll('#bgTypePicker .segmented__btn').forEach(b => b.classList.toggle('is-active', b.dataset.bgtype === type));
    $('bgUrlWrap').hidden = type !== 'url';
    $('bgUploadWrap').hidden = type !== 'upload';
  };
  pick(bgSettings.type);
  $('bgUrlInput').value = bgSettings.url || '';
  $('bgOverlayRange').value = bgSettings.overlay;
  $('bgOverlayVal').textContent = bgSettings.overlay;
  $('bgBlurToggle').checked = !!bgSettings.blur;
  document.querySelectorAll('#bgTypePicker .segmented__btn').forEach(b => b.addEventListener('click', () => {
    bgSettings.type = b.dataset.bgtype; pick(b.dataset.bgtype);
  }));
  $('bgOverlayRange').addEventListener('input', e => { $('bgOverlayVal').textContent = e.target.value; });
  $('bgUploadInput').addEventListener('change', e => {
    const f = e.target.files[0]; if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      const im = new Image();
      im.onload = () => {
        const scale = Math.min(1, 1280 / im.width);
        const c = document.createElement('canvas');
        c.width = Math.round(im.width * scale); c.height = Math.round(im.height * scale);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        pendingUpload = c.toDataURL('image/jpeg', .72);
        showToast('Gambar siap — klik Terapkan');
      };
      im.src = reader.result;
    };
    reader.readAsDataURL(f);
  });
  $('btnApplyBg').addEventListener('click', () => {
    bgSettings.url = $('bgUrlInput').value.trim();
    bgSettings.overlay = +$('bgOverlayRange').value;
    bgSettings.blur = $('bgBlurToggle').checked;
    if (bgSettings.type === 'upload' && pendingUpload) {
      try { localStorage.setItem(LS + 'bgImage', pendingUpload); }
      catch (e) { showToast('Gambar terlalu besar untuk browser — pakai URL saja', 'error'); return; }
    }
    saveJSON('bg', bgSettings);
    applyBackground();
    showToast('Latar belakang diterapkan');
  });
  $('btnRemoveBg').addEventListener('click', () => {
    bgSettings = Object.assign({}, DEFAULT_BG);
    pendingUpload = null;
    try { localStorage.removeItem(LS + 'bgImage'); } catch (e) {}
    saveJSON('bg', bgSettings);
    pick('none'); $('bgUrlInput').value = ''; $('bgOverlayRange').value = 55; $('bgOverlayVal').textContent = 55;
    applyBackground();
    showToast('Latar belakang dihapus');
  });
}

// -------------------------------------------------------------------------
// 14. SETTING: koneksi, waktu, lokasi, ambang, relay, OTA
// -------------------------------------------------------------------------
function fillConfigForm() {
  $('cfgHost').value = cfg.host; $('cfgPort').value = cfg.port; $('cfgProtocol').value = cfg.protocol;
  $('cfgPath').value = cfg.path; $('cfgUser').value = cfg.username; $('cfgPass').value = cfg.password;
  $('cfgPrefix').value = cfg.prefix;
}
function saveConfig() {
  const host = $('cfgHost').value.trim();
  if (!host) { showToast('Host broker wajib diisi', 'error'); return; }
  cfg = {
    host, port: +$('cfgPort').value || 8083, protocol: $('cfgProtocol').value,
    path: $('cfgPath').value.trim() || '/mqtt', username: $('cfgUser').value, password: $('cfgPass').value,
    prefix: ($('cfgPrefix').value.trim() || 'esp32').replace(/\/+$/, '')
  };
  saveJSON('cfg', cfg);
  state.relayKnown = false; state.relaySeen = [false, false, false, false]; state.lastDeviceMsgAt = 0;
  connectMQTT();
  showToast('Konfigurasi disimpan, menghubungkan…');
}
function setTimeCmd(y, mo, d, h, mi, s) {
  return `set_time:${y}:${pad(mo)}:${pad(d)}:${pad(h)}:${pad(mi)}:${pad(s)}`;
}
function syncTimeFromBrowser() {
  const w = new Date(Date.now() + TZ_OFFSET_H * 3600e3);    // jam dinding WIB
  const cmd = setTimeCmd(w.getUTCFullYear(), w.getUTCMonth() + 1, w.getUTCDate(), w.getUTCHours(), w.getUTCMinutes(), w.getUTCSeconds());
  if (sendCommand(cmd)) {
    showToast(`RTC diset ke ${pad(w.getUTCHours())}:${pad(w.getUTCMinutes())}:${pad(w.getUTCSeconds())} WIB`);
    setTimeout(() => sendRaw('get_time'), 600);
  }
}
function setTimeManual() {
  const v = $('rtcManual').value;                 // "YYYY-MM-DDTHH:MM" — dianggap jam WIB
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(v);
  if (!m) { showToast('Pilih tanggal & jam dulu', 'error'); return; }
  if (sendCommand(setTimeCmd(+m[1], +m[2], +m[3], +m[4], +m[5], 0))) showToast(`RTC diset ke ${m[3]}/${m[2]}/${m[1]} ${m[4]}:${m[5]} WIB`);
}
function fillLocationForm() { $('locLat').value = location_.lat; $('locLon').value = location_.lon; }
function saveLocation() {
  const lat = parseFloat($('locLat').value), lon = parseFloat($('locLon').value);
  if (isNaN(lat) || isNaN(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) { showToast('Latitude/Longitude tidak valid', 'error'); return; }
  location_ = { lat, lon };
  saveJSON('location', location_);
  if (brokerConnected && state.fw41) {
    sendRaw(`set_location:${lat.toFixed(4)}:${lon.toFixed(4)}`);    // ESP32 hitung ulang & kirim balik <prefix>/sun
    showToast('Lokasi dikirim ke ESP32');
  } else {
    state.deviceSun = null;
    showToast(state.fw41 ? 'Lokasi disimpan di browser (ESP32 belum terhubung)' : 'Lokasi disimpan (jadwal matahari butuh firmware v4.1)');
  }
  updateSun();
}
function geoLocate() {
  if (!navigator.geolocation) { showToast('Browser tidak mendukung lokasi', 'error'); return; }
  navigator.geolocation.getCurrentPosition(p => {
    $('locLat').value = p.coords.latitude.toFixed(4);
    $('locLon').value = p.coords.longitude.toFixed(4);
    saveLocation();
  }, () => showToast('Izin lokasi ditolak / tidak tersedia', 'error'), { timeout: 10000 });
}
function fillThresholdForm() {
  $('thTempHi').value = thresholds.temp_hi; $('thTempLo').value = thresholds.temp_lo;
  $('thHumHi').value = thresholds.hum_hi;   $('thHumLo').value = thresholds.hum_lo;
}
function saveThresholds() {
  const t = { temp_hi: +$('thTempHi').value, temp_lo: +$('thTempLo').value, hum_hi: +$('thHumHi').value, hum_lo: +$('thHumLo').value };
  if (Object.values(t).some(isNaN)) { showToast('Ambang tidak valid', 'error'); return; }
  if (t.temp_lo >= t.temp_hi || t.hum_lo >= t.hum_hi) { showToast('Ambang rendah harus lebih kecil dari ambang tinggi', 'error'); return; }
  if (!brokerConnected) { showToast('Belum terhubung ke broker MQTT', 'error'); return; }
  thresholds = t; saveJSON('thresholds', t); renderSensor();
  Object.keys(t).forEach((k, i) => setTimeout(() => sendRaw(`set_threshold:${k}:${t[k]}`), i * 150));
  showToast('Ambang dikirim ke ESP32');
}
function initNotifToggle() {
  const ok = typeof Notification !== 'undefined';
  $('notifBrowserToggle').checked = ok && Notification.permission === 'granted' && loadJSON('notifBrowser', false);
  if (!ok) setHint('notifPermHint', 'alert', 'Browser ini tidak mendukung notifikasi.');
  else if (Notification.permission === 'denied') setHint('notifPermHint', 'alert', 'Izin notifikasi diblokir — aktifkan lewat pengaturan situs di browser.');
  $('notifBrowserToggle').addEventListener('change', async e => {
    if (!e.target.checked) { saveJSON('notifBrowser', false); return; }
    if (!ok) { e.target.checked = false; showToast('Browser ini tidak mendukung notifikasi', 'error'); return; }
    const perm = await Notification.requestPermission();
    const granted = perm === 'granted';
    e.target.checked = granted; saveJSON('notifBrowser', granted);
    showToast(granted ? 'Notifikasi browser aktif' : 'Izin notifikasi ditolak', granted ? 'ok' : 'error');
  });
}

function renderRelayOptions() {
  const opts = relayMeta.map((m, i) => `<option value="${i + 1}">${escapeHtml(m.name)}</option>`).join('');
  ['schRelay', 'ruleRelay'].forEach(id => { const s = $(id), v = s.value; s.innerHTML = opts; if (v) s.value = v; });
}
let metaDraft = null;
// -------------------------------------------------------------------------
// SAKLAR MANUAL (firmware v4.2)
// -------------------------------------------------------------------------
const SRC_LABEL = { switch: 'saklar', switch_all: 'saklar', remote: 'dashboard', schedule: 'jadwal', timer: 'timer', rule: 'rule' };
let switchAllToast = 0;
function onRelayEvent(d) {
  const i = (d.relay | 0) - 1;
  if (i < 0 || i >= N_RELAY) return;
  relaySrc[i] = { src: d.src, at: Date.now() };
  saveJSON('relaySrc', relaySrc);   // relayChangedAt sudah diisi oleh relayStatus (dikirim ESP32 lebih dulu)
  renderRelayGrid();
  if (d.src === 'switch') {
    showToast(`${relayMeta[i].name} ${d.state ? 'dinyalakan' : 'dimatikan'} dari saklar`);
  } else if (d.src === 'switch_all' && Date.now() - switchAllToast > 2000) {
    switchAllToast = Date.now();
    showToast('Semua relay dimatikan dari saklar (tahan 3 detik)');
  }
}
function onSwitches(d) {
  if (!d || !Array.isArray(d.locked)) return;
  state.switches = d;
  renderSwitchList();
  renderRelayGrid();
}
function renderSwitchList() {
  const list = $('switchList'), empty = emptyEl('switchEmpty'), sw = state.switches;
  $('btnLockAll').disabled = $('btnUnlockAll').disabled = !sw;
  if (!sw) { list.innerHTML = ''; list.appendChild(empty); return; }
  list.innerHTML = relayMeta.map((m, i) => {
    const locked = !!sw.locked[i], pos = sw.pos ? !!sw.pos[i] : null;
    const type = (sw.type && sw.type[i]) === 'push' ? 'Push button' : 'Saklar dinding';
    const posTxt = pos == null ? '' : (sw.type && sw.type[i] === 'push')
      ? ` · <span class="switch-item__pos ${pos ? 'is-on' : ''}">${pos ? 'DITEKAN' : 'lepas'}</span>`
      : ` · posisi <span class="switch-item__pos ${pos ? 'is-on' : ''}">${pos ? 'ON' : 'OFF'}</span>`;
    return `
    <div class="switch-item ${locked ? 'is-locked' : ''}">
      <div class="switch-item__icon"><img src="${relayIcon(m.icon, state.relay[i])}" alt=""></div>
      <div>
        <div class="switch-item__name">${escapeHtml(m.name)}</div>
        <div class="switch-item__sub">GPIO${sw.pins ? sw.pins[i] : '?'} · ${type}${posTxt}</div>
      </div>
      <label class="switch-row">Kunci
        <input type="checkbox" data-sw-lock="${i}" ${locked ? 'checked' : ''} aria-label="Kunci saklar ${escapeHtml(m.name)}">
        <span class="switch"></span>
      </label>
    </div>`;
  }).join('');
}
function setSwitchLock(target, lock) {
  if (!sendCommand(`switch_lock:${target}:${lock ? 'on' : 'off'}`)) { renderSwitchList(); return; }
  const sw = state.switches;
  if (sw) {                                    // UI optimistis, ESP32 mengirim balik <prefix>/switches
    if (target === 'all') sw.locked = sw.locked.map(() => lock); else sw.locked[target - 1] = lock;
    renderSwitchList(); renderRelayGrid();
  }
  const name = target === 'all' ? 'Semua saklar' : `Saklar ${relayMeta[target - 1].name}`;
  showToast(`${name} ${lock ? 'dikunci' : 'dibuka'}`);
}

function renderRelayMetaForm(keepDraft) {
  if (!keepDraft || !metaDraft) metaDraft = relayMeta.map(m => Object.assign({}, m));
  else {    // simpan isian yang belum disimpan sebelum render ulang (mis. saat ganti tema)
    document.querySelectorAll('[data-meta-name]').forEach(inp => { metaDraft[+inp.dataset.metaName].name = inp.value; });
    document.querySelectorAll('[data-meta-watt]').forEach(inp => { metaDraft[+inp.dataset.metaWatt].watt = +inp.value || 0; });
  }
  $('relayMetaForm').innerHTML = metaDraft.map((m, i) => `
    <div class="relay-meta">
      <div class="relay-meta__row">
        <label>Nama relay ${i + 1}<input type="text" maxlength="32" data-meta-name="${i}" value="${escapeHtml(m.name)}"></label>
        <label>Daya (W)<input type="number" min="0" step="1" data-meta-watt="${i}" value="${m.watt}"></label>
      </div>
      <div class="icon-pick" role="radiogroup" aria-label="Ikon relay ${i + 1}">
        ${RELAY_PRESETS.map(p => `<button type="button" class="${p.key === m.icon ? 'is-active' : ''}" data-meta-icon="${i}" data-key="${p.key}" title="${p.label}" aria-label="${p.label}" role="radio" aria-checked="${p.key === m.icon}"><img src="${relayIcon(p.key, p.key === m.icon)}" alt=""></button>`).join('')}
      </div>
    </div>`).join('');
}
function saveRelayMeta() {
  document.querySelectorAll('[data-meta-name]').forEach(inp => { metaDraft[+inp.dataset.metaName].name = inp.value; });
  document.querySelectorAll('[data-meta-watt]').forEach(inp => { metaDraft[+inp.dataset.metaWatt].watt = Math.max(0, +inp.value || 0); });
  relayMeta = sanitizeRelayMeta(metaDraft);
  saveJSON('relayMeta', relayMeta);
  renderRelayMetaForm(false);
  renderRelayGrid(); renderRelayOptions(); renderScheduleList(); renderRuleList(); renderUsage(); renderSwitchList();
  showToast('Nama, ikon & daya relay disimpan');
}

// OTA via HTTP ke ESP32 (endpoint /ota di firmware)
function onOtaStatus(d) {
  if (!d.ip) return;
  state.otaIp = d.ip;
  $('otaIp').textContent = `${d.ip} · fw ${d.version || '?'}${d.busy ? ' · sibuk' : ''}`;
}
function setOta(status, pct) {
  const bar = $('otaProgress');
  bar.hidden = status === 'idle';
  bar.classList.toggle('is-done', status === 'done');
  bar.classList.toggle('is-error', status === 'error');
  $('otaProgressFill').style.width = (pct || 0) + '%';
  const map = { idle: 'Siap', uploading: `Mengunggah… ${pct}%`, flashing: `Menulis flash… ${pct}%`, done: 'Selesai — ESP32 reboot', error: 'Gagal', lan_start: 'OTA via LAN dimulai…' };
  $('otaStatus').textContent = map[status] || status;
}
function onOtaProgress(d) {
  if (d.pct === -1) { setOta('error', 0); otaBusy = false; }
  else if (d.status === 'done') { setOta('done', 100); otaBusy = false; }
  else setOta(d.status || 'uploading', d.pct || 0);
}
function flashOta() {
  const f = $('otaFile').files[0];
  if (!f) { showToast('Pilih file .bin dulu', 'error'); return; }
  if (!/\.bin$/i.test(f.name)) { showToast('File harus .bin', 'error'); return; }
  if (!state.otaIp) { showToast('IP ESP32 belum diketahui — klik Cek', 'error'); return; }
  if (IS_HTTPS) { showToast('Browser memblokir upload HTTP dari halaman HTTPS — buka dashboard via http:// lokal', 'error'); return; }
  if (otaBusy) return;
  otaBusy = true; setOta('uploading', 0);
  const fd = new FormData(); fd.append('firmware', f);
  fetch(`http://${state.otaIp}/ota`, { method: 'POST', body: fd })
    .then(r => r.ok ? r : r.text().then(t => { throw new Error(t || r.status); }))
    .then(() => { otaBusy = false; setOta('done', 100); showToast('OTA berhasil, ESP32 reboot'); })
    .catch(err => { otaBusy = false; setOta('error', 0); showToast('OTA gagal: ' + err.message, 'error'); });
}

// -------------------------------------------------------------------------
// 15. MODAL, KONFIRMASI, TOAST
// -------------------------------------------------------------------------
let lastFocus = null;
function openModal(id) {
  lastFocus = document.activeElement;
  $(id).hidden = false;
  refreshThemeIcons($(id));
  const f = $(id).querySelector('select, input, button.btn');
  if (f) setTimeout(() => f.focus({ preventScroll: true }), 50);
}
function closeModal(id) {
  $(id).hidden = true;
  if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
}
let confirmResolve = null;
function confirmDialog(text, okLabel) {
  $('confirmText').textContent = text;
  $('confirmOk').textContent = okLabel || 'Hapus';
  openModal('confirmModal');
  return new Promise(res => { confirmResolve = res; });
}
function resolveConfirm(v) {
  if (confirmResolve) { confirmResolve(v); confirmResolve = null; }
  closeModal('confirmModal');
}
let toastTimer;
function showToast(msg, kind) {
  const el = $('toast');
  const icon = kind === 'error' || kind === 'warn' ? 'alert' : 'check';
  el.innerHTML = `${ic(icon)}<span>${escapeHtml(msg)}</span>`;
  el.className = 'toast is-visible' + (kind === 'error' ? ' is-error' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('is-visible'), kind === 'error' || kind === 'warn' ? 4500 : 3000);
}

// -------------------------------------------------------------------------
// 16. UTIL
// -------------------------------------------------------------------------
function setHint(id, icon, html) { $(id).innerHTML = ic(icon) + '<span>' + html + '</span>'; }
function pad(n) { return String(n).padStart(2, '0'); }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function num(v) { return v == null || isNaN(v) ? '--' : (Math.round(v * 10) / 10).toString(); }
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function fmtDuration(sec, long) {
  sec = Math.max(0, sec | 0);
  const d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  if (d > 0) return `${d} hr ${h}j`;
  if (h > 0) return `${h}j ${m}m`;
  if (m > 0) return long ? `${m}m` : `${m}m ${s}d`;
  return `${s}d`;
}
function fmtAgo(ms) {
  const s = Math.round(ms / 1000);
  if (s < 10) return 'baru saja';
  if (s < 60) return `${s} dtk lalu`;
  if (s < 3600) return `${Math.floor(s / 60)} mnt lalu`;
  if (s < 86400) return `${Math.floor(s / 3600)} jam lalu`;
  return `${Math.floor(s / 86400)} hari lalu`;
}
function fmtTimeWIB(ms) {
  const w = new Date(ms + TZ_OFFSET_H * 3600e3);
  return `${pad(w.getUTCHours())}:${pad(w.getUTCMinutes())}:${pad(w.getUTCSeconds())}`;
}
// Timestamp NVS firmware = jam dinding WIB yang disimpan sebagai unixtime → baca dengan getter UTC
function fmtWallClock(ms) { const w = new Date(ms); return `${pad(w.getUTCHours())}:${pad(w.getUTCMinutes())}`; }
function fmtDateTime(ms) {
  const w = new Date(ms + TZ_OFFSET_H * 3600e3);
  return `${pad(w.getUTCDate())}/${pad(w.getUTCMonth() + 1)} ${pad(w.getUTCHours())}:${pad(w.getUTCMinutes())}`;
}

// -------------------------------------------------------------------------
// 17. EVENT BINDING & INIT
// -------------------------------------------------------------------------
function bindEvents() {
  $('themeToggle').addEventListener('click', () => applyTheme(themeMode() === 'dark' ? 'light' : 'dark', true));
  document.querySelectorAll('[data-theme-pick]').forEach(b => b.addEventListener('click', () => applyTheme(b.dataset.themePick, true)));

  // relay grid (event delegation — grid di-render ulang)
  $('relayGrid').addEventListener('click', e => {
    const t = e.target.closest('[data-toggle]');
    if (t) { toggleRelay(+t.dataset.toggle); return; }
    const tb = e.target.closest('[data-timerbtn]');
    if (tb) openTimerModal(+tb.dataset.timerbtn);
  });
  $('btnAllOff').addEventListener('click', allOff);

  // timer
  $('timerStart').addEventListener('click', startTimer);
  $('timerQuick').addEventListener('click', e => {
    const b = e.target.closest('[data-sec]'); if (!b) return;
    const sec = +b.dataset.sec;
    if (sec % 3600 === 0) { $('timerDuration').value = sec / 3600; $('timerUnit').value = '3600'; }
    else { $('timerDuration').value = sec / 60; $('timerUnit').value = '60'; }
  });

  // jadwal
  $('btnAddSchedule').addEventListener('click', () => openScheduleModal(null));
  $('scheduleList').addEventListener('click', e => {
    const ed = e.target.closest('[data-sch-edit]'); if (ed) { openScheduleModal(+ed.dataset.schEdit); return; }
    const del = e.target.closest('[data-sch-del]'); if (del) deleteSchedule(+del.dataset.schDel);
  });
  $('schSave').addEventListener('click', saveSchedule);
  $('schModePicker').addEventListener('click', e => { const b = e.target.closest('[data-mode]'); if (b) setSchMode(b.dataset.mode); });
  $('schOffsetChips').addEventListener('click', e => { const b = e.target.closest('[data-off]'); if (b) { $('schOffset').value = b.dataset.off; updateSchPreview(); } });
  $('schDays').addEventListener('click', e => { const b = e.target.closest('[data-day]'); if (b) { b.classList.toggle('is-active'); updateSchPreview(); } });
  ['schRelay', 'schAction', 'schTime', 'schOffset', 'schRepeat'].forEach(id => {
    $(id).addEventListener('input', updateSchPreview); $(id).addEventListener('change', updateSchPreview);
  });

  // rule
  $('btnAddRule').addEventListener('click', () => openRuleModal(null));
  $('ruleList').addEventListener('click', e => {
    const ed = e.target.closest('[data-rule-edit]'); if (ed) { openRuleModal(+ed.dataset.ruleEdit); return; }
    const del = e.target.closest('[data-rule-del]'); if (del) deleteRule(+del.dataset.ruleDel);
  });
  ['ruleSensor', 'ruleCond', 'ruleVal', 'ruleHas2', 'ruleSensor2', 'ruleCond2', 'ruleVal2', 'ruleRelay', 'ruleAction']
    .forEach(id => { $(id).addEventListener('input', updateRulePreview); $(id).addEventListener('change', updateRulePreview); });
  $('ruleSave').addEventListener('click', saveRule);

  // grafik
  document.querySelectorAll('#chartRange .segmented__btn').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('#chartRange .segmented__btn').forEach(x => x.classList.toggle('is-active', x === b));
    setChartRange(b.dataset.range);
  }));

  // analitik
  $('btnRefreshStats').addEventListener('click', () => { if (sendCommand('stats')) setTimeout(() => sendRaw('health'), 300); });
  $('btnPing').addEventListener('click', () => { if (sendCommand('ping')) { pingSentAt = Date.now(); $('hPing').textContent = '…'; } });

  // setting
  $('btnSaveConfig').addEventListener('click', saveConfig);
  $('btnRequestStatus').addEventListener('click', () => {
    if (sendCommand('sync')) { setTimeout(() => sendRaw('get_schedules'), 400); setTimeout(() => sendRaw('stats'), 800); showToast('Meminta status terbaru'); }
  });
  $('cfgProtocol').addEventListener('change', e => {
    const p = $('cfgPort');
    if (e.target.value === 'wss' && +p.value === 8083) p.value = 8084;
    if (e.target.value === 'ws' && +p.value === 8084) p.value = 8083;
  });
  $('btnSyncTime').addEventListener('click', syncTimeFromBrowser);
  $('btnSetTimeManual').addEventListener('click', setTimeManual);
  $('btnSaveLocation').addEventListener('click', saveLocation);
  $('btnGeoLocate').addEventListener('click', geoLocate);
  $('btnSaveThresholds').addEventListener('click', saveThresholds);
  $('btnClearAlertLog').addEventListener('click', async () => {
    if (!alertLog.length || !(await confirmDialog('Hapus semua riwayat alert?'))) return;
    alertLog = []; saveJSON('alertLog', alertLog); renderAlertLog();
  });
  $('relayMetaForm').addEventListener('click', e => {
    const b = e.target.closest('[data-meta-icon]'); if (!b) return;
    const i = +b.dataset.metaIcon;
    renderRelayMetaForm(true);                // ambil isian teks dulu
    metaDraft[i].icon = b.dataset.key;
    renderRelayMetaForm(true);
  });
  $('btnSaveRelayMeta').addEventListener('click', saveRelayMeta);
  $('switchList').addEventListener('change', e => {
    const c = e.target.closest('[data-sw-lock]'); if (c) setSwitchLock(+c.dataset.swLock + 1, c.checked);
  });
  $('btnLockAll').addEventListener('click', () => setSwitchLock('all', true));
  $('btnUnlockAll').addEventListener('click', () => setSwitchLock('all', false));
  $('btnClearChart').addEventListener('click', async () => {
    if (!(await confirmDialog('Hapus riwayat grafik live yang tersimpan di browser ini?'))) return;
    history = []; saveJSON('history', history); updateChart(); showToast('Riwayat grafik dihapus');
  });
  $('btnOtaInfo').addEventListener('click', () => { if (sendCommand('ota_info')) $('otaIp').textContent = 'menanyakan…'; });
  $('otaFile').addEventListener('change', e => {
    const f = e.target.files[0];
    $('otaFileName').textContent = f ? `${f.name} (${(f.size / 1024).toFixed(0)} KB)` : 'Pilih file .bin';
  });
  $('btnOtaFlash').addEventListener('click', flashOta);
  if (IS_HTTPS) setHint('otaHint', 'alert', 'Dashboard ini dibuka lewat HTTPS, jadi browser memblokir upload ke <code>http://IP-ESP32</code>. Untuk OTA, buka dashboard dari file lokal atau http:// di jaringan WiFi yang sama.');

  // modal: tombol tutup, klik backdrop, Escape
  document.addEventListener('click', e => {
    const c = e.target.closest('[data-close]');
    if (c) { if (c.dataset.close === 'confirmModal') resolveConfirm(false); else closeModal(c.dataset.close); return; }
    if (e.target.classList && e.target.classList.contains('modal-backdrop')) {
      if (e.target.id === 'confirmModal') resolveConfirm(false); else closeModal(e.target.id);
    }
  });
  $('confirmOk').addEventListener('click', () => resolveConfirm(true));
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    const open = document.querySelector('.modal-backdrop:not([hidden])');
    if (open) { if (open.id === 'confirmModal') resolveConfirm(false); else closeModal(open.id); }
  });

  // tab kembali aktif → minta state terbaru (HP sering membekukan tab di background)
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && brokerConnected) { sendRaw('sync'); setTimeout(() => sendRaw('get_schedules'), 400); }
  });
}

function safeInit(fn) { try { fn(); } catch (e) { console.error('[init gagal]', fn.name, e); } }

document.addEventListener('DOMContentLoaded', () => {
  const sysDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const initialTheme = loadJSON('theme', sysDark ? 'dark' : 'light');
  safeInit(() => { document.body.dataset.theme = initialTheme; });
  safeInit(bindEvents);
  safeInit(initTabs);
  safeInit(initStickyObserver);
  safeInit(fillConfigForm);
  safeInit(fillLocationForm);
  safeInit(fillThresholdForm);
  safeInit(renderRelayOptions);
  safeInit(initNotifToggle);
  safeInit(initBackgroundForm);
  safeInit(renderAlertLog);
  safeInit(renderRuleList);
  safeInit(renderSwitchList);
  safeInit(renderSensor);
  safeInit(updateSun);
  safeInit(tickClock);
  safeInit(initChart);
  safeInit(() => applyTheme(initialTheme));   // juga render grid, jadwal, form relay
  setInterval(() => safeInit(tickClock), 1000);
  setInterval(() => safeInit(updateSun), 10 * 60 * 1000);
  setInterval(() => { safeInit(renderUsage); if (!document.querySelector('.modal-backdrop:not([hidden])')) safeInit(renderRelayGrid); }, 30000);
  // MQTT paling penting — dijalankan terakhir & terpisah agar tak ikut gagal
  safeInit(connectMQTT);
});

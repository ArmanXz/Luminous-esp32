/**
 * ============================================================
 * Luminous v4.2 — ESP32 Smart Relay Control System
 * ============================================================
 * FITUR BARU v4.2:
 *
 * [S1] KONTROL MANUAL DENGAN SAKLAR FISIK (1 saklar per relay)
 *      Wiring: GPIO saklar ──[saklar]── GND  (pull-up internal, tanpa resistor)
 *      Default pin: R1=GPIO32, R2=GPIO33, R3=GPIO25, R4=GPIO26 (SWITCH_PINS)
 *      Tipe per saklar (SWITCH_TYPE):
 *        SW_TOGGLE — saklar dinding biasa (on/off). SETIAP perubahan posisi
 *                    membalik relay, seperti saklar 2 arah: saklar & dashboard
 *                    sama-sama bisa dipakai tanpa saling "mengunci".
 *        SW_PUSH   — push button (momentary). Tekan = balik relay,
 *                    tahan 3 detik = matikan SEMUA relay.
 *      Debounce 50 ms, dibaca task FreeRTOS terpisah (Core 1, tiap 10 ms).
 *      Kunci saklar dari dashboard (mis. kunci anak), tersimpan di NVS:
 *        switch_lock:<1-4|all>:<on|off>     get_switches
 *      Publish:
 *        <prefix>/switches     {"pins":[..],"type":[..],"locked":[..],"pos":[..]}
 *        <prefix>/relay_event  {"relay":1,"state":true,"src":"switch"}
 *          src = switch | switch_all | remote | schedule | timer | rule
 *        <prefix>/alert        {"type":"switch_locked","relay":1,...} saat saklar terkunci ditekan
 *
 * FITUR v4.1:
 *
 * [T1] PREFIX TOPIK MQTT bisa diatur (#define TOPIC_PREFIX)
 *      Semua topik = TOPIC_PREFIX "/..." — samakan dengan dashboard.
 *
 * [T2] JAM DS3231 DIKIRIM KE DASHBOARD
 *      Topik <prefix>/time tiap 30 detik + saat sync / set_time:
 *      {"time":"HH:MM:SS","date":"DD/MM/YYYY","epoch":<WIB>,"dow":0-6,"valid":true}
 *      Command: get_time
 *
 * [T3] JADWAL MINGGUAN SUNGGUHAN + JADWAL SEKALI YANG BENAR
 *      Jadwal "weekly" kini menyimpan hari (bitmask, bit0=Minggu..bit6=Sabtu).
 *      Jadwal "none" (sekali) setelah jalan ikut dinonaktifkan di NVS,
 *      jadi tidak jalan lagi setelah ESP32 restart.
 *
 * [T4] JADWAL BERDASARKAN MATAHARI
 *      Jam terbit/terbenam dihitung di ESP32 (NOAA sunrise equation,
 *      tanpa internet) dari lokasi yang tersimpan di NVS.
 *      Mode: fixed (jam tetap) | sunrise | sunset, + selisih menit (-720..720)
 *      Command: save_schedule:<slot>:<relay>:<on|off>:<HH>:<MM>:<repeat>[:<days>[:<mode>[:<offset>]]]
 *                 repeat = daily | weekly | none, days = 0..127, mode = fixed|sunrise|sunset
 *               set_location:<lat>:<lon>   get_sun
 *      Publish: <prefix>/sun {"sunrise":"05:26","sunset":"17:47","lat":..,"lon":..}
 *
 * [T5] BUFFER MQTT 512 -> 1536 BYTE
 *      Payload rules (~600 B) & history (~950 B) sebelumnya melebihi buffer
 *      512 B sehingga gagal terkirim diam-diam.
 *
 * FITUR v4.0:
 *
 * [B4] SCHEDULE NVS PERSISTENCE — survive restart / power off
 *      4 schedule slot disimpan ke NVS via Preferences
 *      Key: sc_N_active, sc_N_relay, sc_N_action, sc_N_hour,
 *           sc_N_min, sc_N_repeat
 *      Command: save_schedule:<slot>:<relay>:<on|off>:<HH>:<MM>:<repeat>  (lihat [T3]/[T4])
 *               del_schedule:<slot>
 *               get_schedules → publish JSON ke <prefix>/schedules
 *      Publish: {"n":4,"slots":[{"id":1,"active":true,"relay":2,...},...]}
 *
 * [C2] MULTI-KONDISI RULE (AND LOGIC) — kondisi sensor ganda
 *      AutoRule upgrade: cond2(opsional), sensor2, trigVal2, hasSecond
 *      Evaluasi: kondisi1 AND kondisi2 harus terpenuhi bersamaan
 *      Hysteresis independen per kondisi
 *      Command: set_rule:<id>:<s>:<c>:<v>:<relay>:<act>[:<s2>:<c2>:<v2>]
 *               Tanpa suffix = single kondisi (backward-compatible)
 *               Dengan suffix = AND logic dual kondisi
 *      Publish: {...,"has2":true,"sensor2":"hum","cond2":"above","val2":70}
 *
 * [C3] MIN/MAX/AVG SENSOR STATS
 *      Dihitung di ESP32 dari sensorHistory (rolling window session)
 *      Field baru di esp32/health: temp_min, temp_max, temp_avg,
 *        hum_min, hum_max, hum_avg, stat_n (jumlah sample)
 *      Rolling window 288 sample (24 jam @ 5 menit) — sama dengan histCnt
 *      Reset saat clear_history
 *
 * [D5] OTA FIRMWARE UPDATE via Dashboard
 *      Mode 1: ArduinoOTA (WiFi LAN, port 3232) — tanpa password
 *      Mode 2: HTTP OTA endpoint /ota — dashboard upload .bin via fetch()
 *              WebServer port 80, multipart upload, apply Update.h
 *              Progress publish ke esp32/ota_progress
 *              JSON: {"pct":45,"status":"uploading","size":512000}
 *              Selesai: {"pct":100,"status":"done"} → reboot 2s
 *      Command: ota_info → publish info OTA ke esp32/ota_status
 *      Safety: WDT disable saat flash, enable kembali setelah
 *
 * DARI v3.0 (dipertahankan semua):
 * [A1] Automation Rules single-cond (upgrade ke C2)
 * [A2] Timer Countdown real-time progress
 * [A5] NVS Sensor Data Logging 288 titik 24 jam
 * [N1-N6] Health report, threshold, stats, pong, relay-broadcast, alert
 *
 * RELIABILITY:
 * [P1] 9 FreeRTOS mutex (+ otaMutex)
 * [P2] WDT v2.x/v3.x compat, unique client ID dari MAC
 * [P3] Core balance (Core0: net, Core1: logic), strtok parser
 * ============================================================
 */

#include <WiFi.h>
#include <MQTT.h>
#include <DHT.h>
#include <WebSocketsServer.h>
#include <Wire.h>
#include <RTClib.h>
#include <esp_task_wdt.h>
#include <esp_system.h>
#include <Preferences.h>          // [A5] NVS
#include <WebServer.h>            // [D5] OTA HTTP endpoint
#include <Update.h>               // [D5] OTA flash
#include <ArduinoOTA.h>           // [D5] OTA WiFi LAN

// ===== CONFIG =====
const char* WIFI_SSID   = "NAMA_WIFI_ANDA";      // ← ganti dengan nama WiFi (2.4 GHz)
const char* WIFI_PASS   = "PASSWORD_WIFI_ANDA";  // ← ganti dengan password WiFi
const char* MQTT_SERVER = "broker.emqx.io";
const int   MQTT_PORT   = 1883;
const int   GMT_OFFSET_HOURS = 7;
const char* TIMEZONE_NAME    = "WIB";

// [T1] Prefix topik MQTT — WAJIB sama dengan "Prefix Topic" di tab Setting dashboard.
//      Di broker publik, ganti ke nama unik (mis. "luminous-arceus-7f3a") supaya
//      orang lain tidak bisa mengirim perintah ke relay Anda.
#define TOPIC_PREFIX "esp32"
#define TOPIC(s)     TOPIC_PREFIX "/" s

#define FW_VERSION   "4.2"

// [T4] Lokasi default untuk jadwal matahari (bisa diubah dari dashboard → disimpan di NVS)
const float DEFAULT_LAT = -6.2088f;    // Jakarta
const float DEFAULT_LON = 106.8456f;

#define DHTPIN   4
#define DHTTYPE  DHT11
const uint8_t RELAY_PINS[4] = {16, 17, 18, 19};

// [S1] Saklar manual — satu per relay, sambungkan GPIO → saklar → GND
//      Pin bebas yang punya pull-up internal: 13, 14, 25, 26, 27, 32, 33
//      (JANGAN pakai GPIO 34–39: tidak ada pull-up internal)
const uint8_t SWITCH_PINS[4] = {32, 33, 25, 26};
enum SwitchType : uint8_t { SW_TOGGLE = 0, SW_PUSH = 1 };
const SwitchType SWITCH_TYPE[4] = {SW_TOGGLE, SW_TOGGLE, SW_TOGGLE, SW_TOGGLE};
const uint32_t SWITCH_DEBOUNCE_MS  = 50;
const uint32_t SWITCH_LONGPRESS_MS = 3000;   // SW_PUSH: tahan = semua relay OFF
const uint32_t SWITCH_POLL_MS      = 10;
const uint8_t RELAY_ON      = LOW;
const uint8_t RELAY_OFF     = HIGH;

const uint32_t SENSOR_INTERVAL   =   5000;   // ms
const uint32_t SCHEDULE_INTERVAL =    500;
const uint32_t DISPLAY_INTERVAL  =   1000;
const uint32_t HEALTH_INTERVAL   =  10000;   // [N1]
const uint32_t HISTORY_INTERVAL  = 300000;   // [A5] 5 menit
const uint32_t TIME_PUBLISH_INTERVAL = 30000; // [T2] publish jam RTC

const uint8_t  MAX_TIMERS       = 4;
const uint8_t  DHT_MAX_ERRORS   = 5;
const uint8_t  WDT_TIMEOUT_SEC  = 30;
const uint8_t  MAX_RULES        = 4;         // [A1/C2]
const uint16_t HISTORY_POINTS   = 288;       // [A5] 24 jam @ 5 menit
const uint8_t  MAX_SCHEDULES_NVS = 4;        // [B4] NVS schedule slots
const uint16_t STAT_WINDOW      = 288;       // [C3] rolling window sample

// ===== [N2] SENSOR THRESHOLDS =====
struct SensorThresholds {
  float temp_hi = 37.0f;
  float temp_lo = 15.0f;
  float hum_hi  = 85.0f;
  float hum_lo  = 20.0f;
};
SensorThresholds thresholds;

// ===== [N3] RELAY USAGE STATS =====
struct RelayStats {
  uint32_t totalOnMs  = 0;
  uint32_t cycleCount = 0;
  uint32_t lastOnMs   = 0;
  bool     isOn       = false;
};
RelayStats relayStats[4];

// ===== [A1/C2] AUTOMATION RULES — upgrade ke dual-kondisi AND =====
enum class RuleSensor : uint8_t { TEMP = 0, HUM  = 1 };
enum class RuleCond   : uint8_t { ABOVE = 0, BELOW = 1 };

struct AutoRule {
  bool       active      = false;
  // Kondisi 1 (wajib)
  RuleSensor sensor      = RuleSensor::TEMP;
  RuleCond   cond        = RuleCond::ABOVE;
  float      trigVal     = 0.0f;
  // Kondisi 2 (opsional — AND logic) [C2]
  bool       hasSecond   = false;
  RuleSensor sensor2     = RuleSensor::HUM;
  RuleCond   cond2       = RuleCond::ABOVE;
  float      trigVal2    = 0.0f;
  // Aksi
  uint8_t    relay       = 0;      // 0-based
  bool       action      = true;   // true=ON false=OFF
  // Hysteresis state (satu flag mencakup kedua kondisi)
  bool       triggered   = false;
};
AutoRule rules[MAX_RULES];

// ===== [A2] TIMER COUNTDOWN TRACKING =====
struct TimerTrack {
  volatile bool     active    = false;
  volatile uint32_t remaining = 0;
  volatile uint32_t total     = 0;
  volatile uint8_t  relay     = 0;
  volatile bool     turnOn    = false;
};
TimerTrack timerTracks[MAX_TIMERS];

// ===== ENUMS & STRUCTS =====
enum class RepeatType : uint8_t { NONE = 0, DAILY, WEEKLY };

// [T4] Mode jadwal: jam tetap, atau relatif terhadap matahari terbit/terbenam
enum SchedMode : uint8_t { SM_FIXED = 0, SM_SUNRISE = 1, SM_SUNSET = 2 };
const uint8_t ALL_DAYS = 0x7F;   // bit0=Minggu ... bit6=Sabtu

struct ScheduleEntry {
  bool       active    = false;
  uint8_t    relay     = 0;
  bool       action    = false;
  uint8_t    hour      = 0;
  uint8_t    minute    = 0;
  bool       triggered = false;
  RepeatType repeat    = RepeatType::NONE;
  uint8_t    days      = ALL_DAYS;   // [T3] dipakai bila repeat == WEEKLY
  uint8_t    mode      = SM_FIXED;   // [T4]
  int16_t    offset    = 0;          // [T4] menit relatif matahari
};

// [B4] NVS schedule slot — superset of ScheduleEntry, persist ke NVS
struct NvsScheduleSlot {
  bool       active  = false;
  uint8_t    relay   = 0;
  bool       action  = false;
  uint8_t    hour    = 0;
  uint8_t    minute  = 0;
  RepeatType repeat  = RepeatType::NONE;
  uint8_t    days    = ALL_DAYS;     // [T3]
  uint8_t    mode    = SM_FIXED;     // [T4]
  int16_t    offset  = 0;            // [T4]
};
NvsScheduleSlot nvsSchedules[MAX_SCHEDULES_NVS];

// [C3] Rolling sensor stats
struct SensorStats {
  float   tempMin  = 999.0f;
  float   tempMax  = -999.0f;
  double  tempSum  = 0.0;
  float   humMin   = 999.0f;
  float   humMax   = -999.0f;
  double  humSum   = 0.0;
  uint32_t  n      = 0;
};
SensorStats sensorStat;

struct TimerParams {
  uint8_t  relayIndex;
  uint32_t duration;
  bool     turnOn;
  uint8_t  trackSlot;   // [A2]
};

// ===== GLOBAL OBJECTS =====
Preferences      prefs;
DHT              dht(DHTPIN, DHTTYPE);
WiFiClient       wifiClient;
MQTTClient       mqttClient(1536);       // [T5] cukup untuk payload rules & history
WebSocketsServer webSocket(81);
WebServer        httpServer(80);           // [D5] OTA HTTP
RTC_DS3231       rtc;

// ===== GLOBAL STATE =====
ScheduleEntry    schedules[4];
char             mqttClientId[24];
volatile bool    wifiConnected = false;
volatile uint8_t activeTimers  = 0;
int              dhtErrorCount = 0;
volatile float   lastTemp      = NAN;
volatile float   lastHum       = NAN;
uint16_t         histIdx       = 0;   // [A5] write pointer
uint16_t         histCnt       = 0;   // [A5] total entries saved
volatile bool    otaBusy       = false;  // [D5] OTA in progress flag
float            locLat        = DEFAULT_LAT;   // [T4]
float            locLon        = DEFAULT_LON;   // [T4]
volatile int     sunriseMin    = -1;     // [T4] menit sejak 00:00 WIB, -1 = tidak ada
volatile int     sunsetMin     = -1;
volatile int     sunDay        = -1;
volatile bool    sunDirty      = true;   // hitung ulang di taskSchedule
volatile bool    switchLocked[4] = {false, false, false, false};   // [S1]

// [S1] State debounce per saklar (dipakai taskSwitch / switchPoll)
struct SwitchState {
  bool     stable    = false;   // posisi setelah debounce (true = tersambung ke GND)
  bool     lastRaw   = false;
  uint32_t changedAt = 0;
  uint32_t pressedAt = 0;
  bool     longFired = false;
};
SwitchState swState[4];

// ===== MUTEXES =====
SemaphoreHandle_t scheduleMutex = nullptr;
SemaphoreHandle_t i2cMutex      = nullptr;
SemaphoreHandle_t mqttMutex     = nullptr;
SemaphoreHandle_t timerMutex    = nullptr;
SemaphoreHandle_t statsMutex    = nullptr;
SemaphoreHandle_t rulesMutex    = nullptr;   // [A1/C2]
SemaphoreHandle_t trackMutex    = nullptr;   // [A2]
SemaphoreHandle_t nvsMutex      = nullptr;   // [A5/B4]
SemaphoreHandle_t sstatMutex    = nullptr;   // [C3] sensor stats

// ===== FORWARD DECLARATIONS =====
void      controlRelay(int idx, bool state);
void      publishRelayStatus(int idx, bool state);
void      publishAllRelayStates();
void      publishAlert(const char* type, float val);
void      publishAlertSimple(const char* msg);
void      publishDeviceHealth();
void      publishRelayStats(int idx);
void      publishTimerStatus(uint8_t slot);
void      publishRules();
void      publishHistory(uint16_t nPoints);
void      publishSchedules();                      // [B4]
void      publishOtaProgress(int pct, const char* status, size_t size); // [D5]
void      updateRelayStats(int idx, bool newState);
void      checkSensorThresholds(float t, float h);
void      evaluateRules(float t, float h);
void      updateSensorStats(float t, float h);    // [C3]
void      saveHistoryPoint(float t, float h);
void      saveRulesToNVS();
void      loadRulesFromNVS();
void      saveNvsSchedule(int slot);              // [B4]
void      loadNvsSchedules();                     // [B4]
void      deleteNvsSchedule(int slot);            // [B4]
void      setupOtaEndpoints();                    // [D5]
void      storeSchedule(int slot, uint8_t relay, bool action, uint8_t h, uint8_t m,
                        RepeatType r, uint8_t days, uint8_t mode, int16_t offset);  // [T3/T4]
int       scheduleTargetMin(const ScheduleEntry &s);   // [T4]
int       calcSunMin(int y, int m, int d, float lat, float lon, bool rising);
void      recomputeSun(const DateTime &wib);
void      publishSun();                               // [T4]
void      publishTime();                              // [T2]
void      loadLocation();                             // [T4]
void      controlRelaySrc(int idx, bool state, const char* src);   // [S1]
void      publishRelayEvent(int idx, bool state, const char* src);
void      publishSwitches();
void      loadSwitchLocks();
void      initSwitches();
void      switchPoll(uint32_t now);
void      taskSwitch(void* p);
const char* schedModeStr(uint8_t m);
uint8_t     parseSchedMode(const char* s);
bool      startTimer(bool turnOn, uint8_t relayIndex, uint32_t dur);
int       findFreeTimerSlot();
bool      safeRTCRead(DateTime &out);
DateTime  getIndonesiaTime();
void      displayCurrentTime();
void      setRTCTime(int yr, int mo, int dy, int hh, int mm, int ss);
void      processCommand(const char* raw);
void      reconnectMQTT();
void      onWiFiEvent(WiFiEvent_t event, WiFiEventInfo_t info);
void      mqttMessageReceived(String &topic, String &payload);
const char* getDayOfWeek(int d);
const char* getMonthName(int m);
RepeatType  parseRepeatType(const char* s);
const char* repeatTypeStr(RepeatType r);

// ============================================================
// FREERTOS TASKS
// ============================================================

void taskMQTT(void* p) {
  esp_task_wdt_add(NULL);
  for (;;) {
    esp_task_wdt_reset();
    if (wifiConnected && !mqttClient.connected()) reconnectMQTT();
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(5)) == pdTRUE) {
      mqttClient.loop();
      xSemaphoreGive(mqttMutex);
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void taskSensor(void* p) {
  esp_task_wdt_add(NULL);
  uint32_t lastHistSave = 0;
  for (;;) {
    esp_task_wdt_reset();
    if (otaBusy) { vTaskDelay(pdMS_TO_TICKS(1000)); continue; }  // [D5] pause saat OTA
    float h = dht.readHumidity();
    float t = dht.readTemperature();
    if (!isnan(h) && !isnan(t)) {
      dhtErrorCount = 0;
      lastTemp = t; lastHum = h;
      char bufH[8], bufT[8];
      snprintf(bufH, sizeof(bufH), "%.1f", h);
      snprintf(bufT, sizeof(bufT), "%.1f", t);
      if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        mqttClient.publish(TOPIC("humidity679"),    bufH);
        mqttClient.publish(TOPIC("temperature679"), bufT);
        xSemaphoreGive(mqttMutex);
      }
      checkSensorThresholds(t, h);   // [N2]
      evaluateRules(t, h);           // [A1/C2]
      updateSensorStats(t, h);       // [C3]
      // [A5] simpan ke NVS tiap HISTORY_INTERVAL
      if (millis() - lastHistSave >= HISTORY_INTERVAL) {
        lastHistSave = millis();
        saveHistoryPoint(t, h);
      }
      Serial.printf("[Sensor] %.1f%%RH  %.1f°C\n", h, t);
    } else {
      dhtErrorCount++;
      if (dhtErrorCount >= DHT_MAX_ERRORS) publishAlertSimple("dht_fail");
      vTaskDelay(pdMS_TO_TICKS(2000));
      continue;
    }
    vTaskDelay(pdMS_TO_TICKS(SENSOR_INTERVAL));
  }
}

void taskSchedule(void* p) {
  esp_task_wdt_add(NULL);
  for (;;) {
    esp_task_wdt_reset();
    DateTime utcNow;
    if (!safeRTCRead(utcNow)) { vTaskDelay(pdMS_TO_TICKS(SCHEDULE_INTERVAL)); continue; }
    DateTime wib(utcNow.unixtime() + (uint32_t)(GMT_OFFSET_HOURS * 3600UL));

    // [T4] Hitung ulang jam matahari saat ganti hari / lokasi atau jam RTC berubah
    if (sunDirty || wib.day() != sunDay) {
      recomputeSun(wib);
      publishSun();
      publishSchedules();      // jam efektif jadwal matahari ikut berubah
    }

    int     curMin = wib.hour() * 60 + wib.minute();
    uint8_t curS   = wib.second();
    uint8_t dow    = wib.dayOfTheWeek();      // 0 = Minggu
    int trigRelay = -1; bool trigAct = false; int onceSlot = -1;
    if (xSemaphoreTake(scheduleMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
      for (int i = 0; i < MAX_SCHEDULES_NVS; i++) {
        if (!schedules[i].active) continue;
        int  target = scheduleTargetMin(schedules[i]);
        bool dayOk  = schedules[i].repeat != RepeatType::WEEKLY || (schedules[i].days & (1 << dow));  // [T3]
        bool match  = target >= 0 && dayOk && curMin == target;
        if (match && curS < 3 && !schedules[i].triggered) {
          schedules[i].triggered = true;
          trigRelay = schedules[i].relay; trigAct = schedules[i].action;
          if (schedules[i].repeat == RepeatType::NONE) { schedules[i].active = false; onceSlot = i; }
          break;
        } else if (!match) schedules[i].triggered = false;
      }
      xSemaphoreGive(scheduleMutex);
    }
    if (trigRelay >= 0) controlRelaySrc(trigRelay, trigAct, "schedule");
    // [T3] Jadwal sekali: nonaktifkan juga di NVS agar tidak jalan lagi setelah restart
    if (onceSlot >= 0) {
      nvsSchedules[onceSlot].active = false;
      saveNvsSchedule(onceSlot);
      publishSchedules();
    }
    vTaskDelay(pdMS_TO_TICKS(SCHEDULE_INTERVAL));
  }
}

void taskWebSocket(void* p) {
  esp_task_wdt_add(NULL);
  for (;;) { esp_task_wdt_reset(); webSocket.loop(); vTaskDelay(pdMS_TO_TICKS(20)); }
}

// [D5] ArduinoOTA loop task
void taskOTA(void* p) {
  esp_task_wdt_add(NULL);
  for (;;) { esp_task_wdt_reset(); ArduinoOTA.handle(); vTaskDelay(pdMS_TO_TICKS(100)); }
}

// [D5] HTTP WebServer loop (untuk endpoint /ota upload)
void taskHTTP(void* p) {
  esp_task_wdt_add(NULL);
  for (;;) { esp_task_wdt_reset(); httpServer.handleClient(); vTaskDelay(pdMS_TO_TICKS(10)); }
}

void taskRTCDisplay(void* p) {
  esp_task_wdt_add(NULL);
  uint32_t lastTimePub = 0;
  for (;;) {
    esp_task_wdt_reset();
    displayCurrentTime();
    if (millis() - lastTimePub >= TIME_PUBLISH_INTERVAL) {   // [T2]
      lastTimePub = millis();
      publishTime();
    }
    vTaskDelay(pdMS_TO_TICKS(DISPLAY_INTERVAL));
  }
}

void taskHealth(void* p) {
  esp_task_wdt_add(NULL);
  for (;;) {
    esp_task_wdt_reset();
    if (mqttClient.connected()) publishDeviceHealth();
    vTaskDelay(pdMS_TO_TICKS(HEALTH_INTERVAL));
  }
}

// [A2] Timer task dengan countdown publish tiap detik
void timerTask(void* parameter) {
  TimerParams tp = *((TimerParams*)parameter);
  free(parameter);
  uint8_t slot = tp.trackSlot;

  // Init track slot
  if (xSemaphoreTake(trackMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    timerTracks[slot].active    = true;
    timerTracks[slot].remaining = tp.duration;
    timerTracks[slot].total     = tp.duration;
    timerTracks[slot].relay     = tp.relayIndex;
    timerTracks[slot].turnOn    = tp.turnOn;
    xSemaphoreGive(trackMutex);
  }
  publishTimerStatus(slot);  // kirim initial state

  // Countdown loop — update + publish tiap detik
  for (uint32_t rem = tp.duration; rem > 0; rem--) {
    vTaskDelay(pdMS_TO_TICKS(1000));
    if (xSemaphoreTake(trackMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
      timerTracks[slot].remaining = rem - 1;
      xSemaphoreGive(trackMutex);
    }
    publishTimerStatus(slot);
  }

  // Eksekusi relay
  controlRelaySrc(tp.relayIndex, tp.turnOn, "timer");

  // Tandai selesai
  if (xSemaphoreTake(trackMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    timerTracks[slot].active    = false;
    timerTracks[slot].remaining = 0;
    xSemaphoreGive(trackMutex);
  }
  publishTimerStatus(slot);

  if (xSemaphoreTake(timerMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (activeTimers > 0) activeTimers--;
    xSemaphoreGive(timerMutex);
  }
  vTaskDelete(NULL);
}

// ============================================================
// SETUP
// ============================================================

void setup() {
  Serial.begin(115200); delay(100);

  scheduleMutex = xSemaphoreCreateMutex();
  i2cMutex      = xSemaphoreCreateMutex();
  mqttMutex     = xSemaphoreCreateMutex();
  timerMutex    = xSemaphoreCreateMutex();
  statsMutex    = xSemaphoreCreateMutex();
  rulesMutex    = xSemaphoreCreateMutex();
  trackMutex    = xSemaphoreCreateMutex();
  nvsMutex      = xSemaphoreCreateMutex();
  sstatMutex    = xSemaphoreCreateMutex();   // [C3]

  if (!scheduleMutex||!i2cMutex||!mqttMutex||!timerMutex||
      !statsMutex||!rulesMutex||!trackMutex||!nvsMutex||!sstatMutex) {
    Serial.println("[FATAL] Gagal buat mutex!"); ESP.restart();
  }

  // [A5] Buka NVS, load history pointer
  prefs.begin("luminous", false);
  histIdx = prefs.getUShort("sh_idx", 0);
  histCnt = prefs.getUShort("sh_cnt", 0);
  Serial.printf("[NVS] History: idx=%d cnt=%d\n", histIdx, histCnt);

  // [A1/C2] Load rules dari NVS
  loadRulesFromNVS();

  // [B4] Load NVS schedules
  loadNvsSchedules();

  // [T4] Load lokasi untuk jadwal matahari
  loadLocation();

  // [S1] Load status kunci saklar
  loadSwitchLocks();

  // Client ID unik dari MAC
  uint8_t mac[6]; WiFi.macAddress(mac);
  snprintf(mqttClientId, sizeof(mqttClientId), "luminous_%02X%02X%02X", mac[3], mac[4], mac[5]);
  Serial.printf("[Config] Client: %s\n", mqttClientId);

  // Hardware init
  for (int i = 0; i < 4; i++) {
    pinMode(RELAY_PINS[i], OUTPUT);
    digitalWrite(RELAY_PINS[i], RELAY_OFF);
  }
  initSwitches();       // [S1] baca posisi awal saklar (tidak mengubah relay)
  dht.begin();
  Wire.begin();
  if (!rtc.begin()) Serial.println("[RTC] DS3231 tidak ditemukan!");
  else if (rtc.lostPower()) { rtc.adjust(DateTime(2024,1,1,0,0,0)); Serial.println("[RTC] Reset!"); }

  // Network
  WiFi.mode(WIFI_STA); WiFi.setAutoReconnect(true); WiFi.persistent(false);
  WiFi.onEvent(onWiFiEvent); WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis()-t0 < 20000) { delay(500); Serial.print("."); }
  if (WiFi.status() == WL_CONNECTED) {
    wifiConnected = true;
    Serial.printf("\n[WiFi] IP: %s\n", WiFi.localIP().toString().c_str());
  }

  // [D5] ArduinoOTA setup
  ArduinoOTA.setHostname("luminous-esp32");
  ArduinoOTA.onStart([]() {
    otaBusy = true;
    Serial.println("[OTA-LAN] Start");
    publishOtaProgress(0, "lan_start", 0);
  });
  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    int pct = (int)(progress * 100 / total);
    if (pct % 10 == 0) publishOtaProgress(pct, "uploading", total);
    Serial.printf("[OTA-LAN] %d%%\n", pct);
  });
  ArduinoOTA.onEnd([]() {
    publishOtaProgress(100, "done", 0);
    Serial.println("[OTA-LAN] Done");
    otaBusy = false;
  });
  ArduinoOTA.onError([](ota_error_t err) {
    Serial.printf("[OTA-LAN] Err[%u]\n", err);
    publishOtaProgress(-1, "error", 0);
    otaBusy = false;
  });
  ArduinoOTA.begin();

  // [D5] HTTP OTA endpoint
  setupOtaEndpoints();
  httpServer.begin();
  Serial.println("[HTTP] Server started port 80");

  mqttClient.begin(MQTT_SERVER, MQTT_PORT, wifiClient);
  mqttClient.setKeepAlive(60);
  mqttClient.onMessage(mqttMessageReceived);
  reconnectMQTT();
  webSocket.begin(); webSocket.onEvent(onWebSocketEvent);

  // WDT
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  const esp_task_wdt_config_t wdt_cfg = {
    .timeout_ms     = (uint32_t)WDT_TIMEOUT_SEC * 1000,
    .idle_core_mask = 0,
    .trigger_panic  = true
  };
  esp_task_wdt_reconfigure(&wdt_cfg);
#else
  esp_task_wdt_init(WDT_TIMEOUT_SEC, true);
#endif
  esp_task_wdt_add(NULL);

  // Tasks — Core0: network | Core1: logic
  xTaskCreatePinnedToCore(taskMQTT,       "MQTT",    6144, NULL, 2, NULL, 0);  // [T5] payload lebih besar
  xTaskCreatePinnedToCore(taskWebSocket,  "WS",      3072, NULL, 1, NULL, 0);
  xTaskCreatePinnedToCore(taskOTA,        "OTA",     3072, NULL, 1, NULL, 0);  // [D5]
  xTaskCreatePinnedToCore(taskHTTP,       "HTTP",    4096, NULL, 1, NULL, 0);  // [D5]
  xTaskCreatePinnedToCore(taskSensor,     "Sensor",  4096, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(taskSchedule,   "Sched",   5120, NULL, 3, NULL, 1);  // [T4] hitung matahari
  xTaskCreatePinnedToCore(taskRTCDisplay, "RTC",     4096, NULL, 1, NULL, 1);  // [T2] publish jam
  xTaskCreatePinnedToCore(taskHealth,     "Health",  3072, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(taskSwitch,     "Switch",  3072, NULL, 2, NULL, 1);  // [S1] saklar manual

  Serial.println("\n=== Luminous v" FW_VERSION " Siap ===");
  Serial.println("Topik MQTT: " TOPIC_PREFIX "/...");
  Serial.println("CMD: relay<N> | timer_on/off | rtc_schedule | set_time | get_time");
  Serial.println("     set_location | get_sun | switch_lock | get_switches");
  Serial.printf("[Switch] Pin %d/%d/%d/%d → GND (pull-up internal)\n",
    SWITCH_PINS[0], SWITCH_PINS[1], SWITCH_PINS[2], SWITCH_PINS[3]);
  Serial.println("     set_threshold | set_rule | del_rule | rules");
  Serial.println("     save_schedule | del_schedule | get_schedules");
  Serial.println("     get_history | clear_history | stats | health | status | reboot");
  Serial.printf("[OTA] http://%s/ota  |  mDNS: luminous-esp32.local\n", WiFi.localIP().toString().c_str());
}

// ============================================================
// WIFI & MQTT
// ============================================================

void onWiFiEvent(WiFiEvent_t event, WiFiEventInfo_t info) {
  if (event == ARDUINO_EVENT_WIFI_STA_GOT_IP) {
    wifiConnected = true;
    Serial.printf("[WiFi] IP: %s\n", WiFi.localIP().toString().c_str());
  } else if (event == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) {
    wifiConnected = false;
    Serial.println("[WiFi] Terputus...");
  }
}

void reconnectMQTT() {
  for (int i = 0; i < 3 && !mqttClient.connected() && wifiConnected; i++) {
    Serial.printf("[MQTT] Connect (%s)...", mqttClientId);
    if (mqttClient.connect(mqttClientId)) {
      Serial.println(" OK");
      mqttClient.subscribe(TOPIC("command"));
      mqttClient.publish(TOPIC("status"), "online");
      // [SYNC-FIX] Tunda 500ms supaya broker siap sebelum publish state
      vTaskDelay(pdMS_TO_TICKS(500));
      publishAllRelayStates();   // [N5] relay state
      vTaskDelay(pdMS_TO_TICKS(200));
      publishDeviceHealth();     // [N1]
      vTaskDelay(pdMS_TO_TICKS(100));
      publishRules();            // [A1/C2] sync rules ke dashboard
      vTaskDelay(pdMS_TO_TICKS(100));
      publishSchedules();        // [B4] sync NVS schedules ke dashboard
      vTaskDelay(pdMS_TO_TICKS(100));
      publishTime();             // [T2] jam DS3231
      publishSun();              // [T4] jam terbit/terbenam
      publishSwitches();         // [S1] status saklar manual
    } else {
      Serial.printf(" Gagal(%d). Tunggu 5s\n", mqttClient.lastError());
      vTaskDelay(pdMS_TO_TICKS(5000));
    }
  }
}

void mqttMessageReceived(String &topic, String &payload) {
  Serial.printf("[MQTT][%s]: %s\n", topic.c_str(), payload.c_str());
  processCommand(payload.c_str());
}

void onWebSocketEvent(uint8_t num, WStype_t type, uint8_t* payload, size_t length) {
  if (type == WStype_TEXT) {
    char buf[256]; size_t n = min(length, sizeof(buf)-1);
    memcpy(buf, payload, n); buf[n] = '\0';
    if (strcmp(buf,"ping")==0) { webSocket.sendTXT(num,"pong"); return; }
    processCommand(buf); webSocket.sendTXT(num,"ok");
  }
}

// ============================================================
// UTILITIES
// ============================================================

bool safeRTCRead(DateTime &out) {
  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    out = rtc.now(); xSemaphoreGive(i2cMutex); return true;
  }
  return false;
}

DateTime getIndonesiaTime() {
  DateTime utc;
  return safeRTCRead(utc)
    ? DateTime(utc.unixtime() + (uint32_t)(GMT_OFFSET_HOURS*3600UL))
    : DateTime(2024,1,1,0,0,0);
}

void displayCurrentTime() {
  DateTime wib = getIndonesiaTime();
  Serial.printf("[Waktu] %s %d %s %04d %02d:%02d:%02d %s | Heap:%u\n",
    getDayOfWeek(wib.dayOfTheWeek()), wib.day(), getMonthName(wib.month()),
    wib.year(), wib.hour(), wib.minute(), wib.second(),
    TIMEZONE_NAME, ESP.getFreeHeap());
}

void setRTCTime(int yr, int mo, int dy, int hh, int mm, int ss) {
  if (yr<2000||yr>2099||mo<1||mo>12||dy<1||dy>31||
      hh<0||hh>23||mm<0||mm>59||ss<0||ss>59) return;
  DateTime wibIn(yr,mo,dy,hh,mm,ss);
  DateTime utcStore(wibIn.unixtime() - (uint32_t)(GMT_OFFSET_HOURS*3600UL));
  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
    rtc.adjust(utcStore); xSemaphoreGive(i2cMutex);
  }
  Serial.printf("[RTC] Set %04d-%02d-%02d %02d:%02d:%02d %s\n",yr,mo,dy,hh,mm,ss,TIMEZONE_NAME);
}

const char* getDayOfWeek(int d) {
  static const char* D[]={"Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"};
  return D[d%7];
}
const char* getMonthName(int m) {
  static const char* M[]={"?","Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"};
  return (m>=1&&m<=12)?M[m]:M[0];
}
RepeatType parseRepeatType(const char* s) {
  if (!s) return RepeatType::NONE;
  if (strcmp(s,"daily")==0)  return RepeatType::DAILY;
  if (strcmp(s,"weekly")==0) return RepeatType::WEEKLY;
  return RepeatType::NONE;
}
const char* repeatTypeStr(RepeatType r) {
  switch(r){case RepeatType::DAILY:return"daily";case RepeatType::WEEKLY:return"weekly";default:return"none";}
}

// ============================================================
// [A5] NVS SENSOR HISTORY
// ============================================================

void saveHistoryPoint(float t, float h) {
  DateTime wib = getIndonesiaTime();
  uint32_t ts  = wib.unixtime();
  char kt[12], kh[12], kts[12];
  snprintf(kt,  sizeof(kt),  "sh_t_%d",  histIdx);
  snprintf(kh,  sizeof(kh),  "sh_h_%d",  histIdx);
  snprintf(kts, sizeof(kts), "sh_ts_%d", histIdx);

  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(300)) == pdTRUE) {
    prefs.putFloat(kt, t);
    prefs.putFloat(kh, h);
    prefs.putUInt(kts, ts);
    histIdx = (histIdx + 1) % HISTORY_POINTS;
    if (histCnt < HISTORY_POINTS) histCnt++;
    prefs.putUShort("sh_idx", histIdx);
    prefs.putUShort("sh_cnt", histCnt);
    xSemaphoreGive(nvsMutex);
  }
  Serial.printf("[Hist] Saved idx=%d cnt=%d t=%.1f h=%.1f\n", histIdx, histCnt, t, h);
}

// Kirim batch 24 titik per MQTT message — hindari payload overflow
void publishHistory(uint16_t nPoints) {
  if (nPoints > histCnt) nPoints = histCnt;
  if (nPoints == 0) {
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("history"), "{\"n\":0,\"data\":[]}");
      xSemaphoreGive(mqttMutex);
    }
    return;
  }

  const uint8_t BATCH = 24;
  // Start index: posisi paling lama di ring buffer
  uint16_t startIdx = (histIdx + HISTORY_POINTS - histCnt) % HISTORY_POINTS;
  // Offset ke titik yang diminta (ambil N titik terbaru)
  uint16_t skipFirst = (nPoints < histCnt) ? (histCnt - nPoints) : 0;
  uint16_t readStart = (startIdx + skipFirst) % HISTORY_POINTS;
  uint16_t sent = 0;

  while (sent < nPoints) {
    uint16_t batchSz = ((nPoints - sent) > BATCH) ? BATCH : (nPoints - sent);
    char buf[1200]; int pos = 0;
    pos += snprintf(buf+pos, sizeof(buf)-pos,
      "{\"n\":%d,\"total\":%d,\"offset\":%d,\"data\":[", batchSz, nPoints, sent);

    for (uint16_t i = 0; i < batchSz; i++) {
      uint16_t ri = (readStart + sent + i) % HISTORY_POINTS;
      char kt[12], kh[12], kts[12];
      snprintf(kt,  sizeof(kt),  "sh_t_%d",  ri);
      snprintf(kh,  sizeof(kh),  "sh_h_%d",  ri);
      snprintf(kts, sizeof(kts), "sh_ts_%d", ri);
      float    tv=0; float hv=0; uint32_t tsv=0;
      if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
        tv  = prefs.getFloat(kt,  0);
        hv  = prefs.getFloat(kh,  0);
        tsv = prefs.getUInt(kts,  0);
        xSemaphoreGive(nvsMutex);
      }
      pos += snprintf(buf+pos, sizeof(buf)-pos,
        "{\"t\":%.1f,\"h\":%.1f,\"ts\":%lu}%s", tv, hv, tsv, (i<batchSz-1)?",":"");
    }
    pos += snprintf(buf+pos, sizeof(buf)-pos, "]}");

    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("history"), buf);
      xSemaphoreGive(mqttMutex);
    }
    sent += batchSz;
    if (sent < nPoints) vTaskDelay(pdMS_TO_TICKS(120));  // beri jeda antar batch
  }
}

// ============================================================
// [A1] AUTOMATION RULES
// ============================================================

void saveRulesToNVS() {
  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(300)) == pdTRUE) {
    for (int i = 0; i < MAX_RULES; i++) {
      char k[16];
      snprintf(k,sizeof(k),"rl_%d_a",i); prefs.putBool(k, rules[i].active);
      snprintf(k,sizeof(k),"rl_%d_s",i); prefs.putUChar(k,(uint8_t)rules[i].sensor);
      snprintf(k,sizeof(k),"rl_%d_c",i); prefs.putUChar(k,(uint8_t)rules[i].cond);
      snprintf(k,sizeof(k),"rl_%d_v",i); prefs.putFloat(k, rules[i].trigVal);
      snprintf(k,sizeof(k),"rl_%d_r",i); prefs.putUChar(k, rules[i].relay);
      snprintf(k,sizeof(k),"rl_%d_x",i); prefs.putBool(k, rules[i].action);
      // [C2] kondisi kedua
      snprintf(k,sizeof(k),"rl_%d_h2",i); prefs.putBool(k, rules[i].hasSecond);
      snprintf(k,sizeof(k),"rl_%d_s2",i); prefs.putUChar(k,(uint8_t)rules[i].sensor2);
      snprintf(k,sizeof(k),"rl_%d_c2",i); prefs.putUChar(k,(uint8_t)rules[i].cond2);
      snprintf(k,sizeof(k),"rl_%d_v2",i); prefs.putFloat(k, rules[i].trigVal2);
    }
    xSemaphoreGive(nvsMutex);
  }
}

void loadRulesFromNVS() {
  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(300)) == pdTRUE) {
    for (int i = 0; i < MAX_RULES; i++) {
      char k[16];
      snprintf(k,sizeof(k),"rl_%d_a",i);  rules[i].active    = prefs.getBool(k, false);
      snprintf(k,sizeof(k),"rl_%d_s",i);  rules[i].sensor    = (RuleSensor)prefs.getUChar(k,0);
      snprintf(k,sizeof(k),"rl_%d_c",i);  rules[i].cond      = (RuleCond)prefs.getUChar(k,0);
      snprintf(k,sizeof(k),"rl_%d_v",i);  rules[i].trigVal   = prefs.getFloat(k, 0.0f);
      snprintf(k,sizeof(k),"rl_%d_r",i);  rules[i].relay     = prefs.getUChar(k, 0);
      snprintf(k,sizeof(k),"rl_%d_x",i);  rules[i].action    = prefs.getBool(k, true);
      // [C2] kondisi kedua
      snprintf(k,sizeof(k),"rl_%d_h2",i); rules[i].hasSecond = prefs.getBool(k, false);
      snprintf(k,sizeof(k),"rl_%d_s2",i); rules[i].sensor2   = (RuleSensor)prefs.getUChar(k,1);
      snprintf(k,sizeof(k),"rl_%d_c2",i); rules[i].cond2     = (RuleCond)prefs.getUChar(k,0);
      snprintf(k,sizeof(k),"rl_%d_v2",i); rules[i].trigVal2  = prefs.getFloat(k, 0.0f);
      rules[i].triggered = false;
    }
    xSemaphoreGive(nvsMutex);
  }
  for (int i=0;i<MAX_RULES;i++) if (rules[i].active)
    Serial.printf("[Rule#%d] %s %s %.1f%s → R%d %s\n", i+1,
      rules[i].sensor==RuleSensor::TEMP?"Temp":"Hum",
      rules[i].cond==RuleCond::ABOVE?">":"<",
      rules[i].trigVal,
      rules[i].hasSecond?" AND(...)":"",
      rules[i].relay+1, rules[i].action?"ON":"OFF");
}

void publishRules() {
  char buf[900]; int pos = 0;
  pos += snprintf(buf+pos, sizeof(buf)-pos, "[");
  for (int i = 0; i < MAX_RULES; i++) {
    // Kondisi pertama
    pos += snprintf(buf+pos, sizeof(buf)-pos,
      "{\"id\":%d,\"active\":%s,\"sensor\":\"%s\","
      "\"cond\":\"%s\",\"val\":%.1f,"
      "\"has2\":%s,\"sensor2\":\"%s\",\"cond2\":\"%s\",\"val2\":%.1f,"
      "\"relay\":%d,\"action\":\"%s\"}%s",
      i+1, rules[i].active?"true":"false",
      rules[i].sensor==RuleSensor::TEMP?"temp":"hum",
      rules[i].cond==RuleCond::ABOVE?"above":"below",
      rules[i].trigVal,
      rules[i].hasSecond?"true":"false",           // [C2]
      rules[i].sensor2==RuleSensor::TEMP?"temp":"hum",
      rules[i].cond2==RuleCond::ABOVE?"above":"below",
      rules[i].trigVal2,
      rules[i].relay+1,
      rules[i].action?"on":"off",
      i<MAX_RULES-1?",":"");
  }
  pos += snprintf(buf+pos, sizeof(buf)-pos, "]");
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC("rules"), buf);
    xSemaphoreGive(mqttMutex);
  }
}

void evaluateRules(float t, float h) {
  const float HYST_T = 0.5f;
  const float HYST_H = 1.0f;
  if (xSemaphoreTake(rulesMutex, pdMS_TO_TICKS(50)) != pdTRUE) return;

  for (int i = 0; i < MAX_RULES; i++) {
    if (!rules[i].active) continue;

    // Evaluasi kondisi 1
    float val1  = (rules[i].sensor == RuleSensor::TEMP) ? t : h;
    float hyst1 = (rules[i].sensor == RuleSensor::TEMP) ? HYST_T : HYST_H;
    bool met1 = (rules[i].cond == RuleCond::ABOVE)
                  ? (val1 >= rules[i].trigVal)
                  : (val1 <= rules[i].trigVal);
    bool reset1 = (rules[i].cond == RuleCond::ABOVE)
                  ? (val1 < rules[i].trigVal - hyst1)
                  : (val1 > rules[i].trigVal + hyst1);

    // [C2] Evaluasi kondisi 2 (jika ada)
    bool met2 = true, reset2 = false;
    if (rules[i].hasSecond) {
      float val2  = (rules[i].sensor2 == RuleSensor::TEMP) ? t : h;
      float hyst2 = (rules[i].sensor2 == RuleSensor::TEMP) ? HYST_T : HYST_H;
      met2 = (rules[i].cond2 == RuleCond::ABOVE)
               ? (val2 >= rules[i].trigVal2)
               : (val2 <= rules[i].trigVal2);
      reset2 = (rules[i].cond2 == RuleCond::ABOVE)
               ? (val2 < rules[i].trigVal2 - hyst2)
               : (val2 > rules[i].trigVal2 + hyst2);
    }

    // AND logic: semua kondisi harus terpenuhi
    bool fire  = met1 && met2 && !rules[i].triggered;
    bool reset = reset1 || reset2;  // salah satu reset → reset rule

    if (fire) {
      rules[i].triggered = true;
      int  rly = rules[i].relay;
      bool act = rules[i].action;
      xSemaphoreGive(rulesMutex);                // release sebelum controlRelay
      controlRelaySrc(rly, act, "rule");
      Serial.printf("[Rule#%d] Fired: val1=%.1f%s → R%d %s\n",
                    i+1, val1, rules[i].hasSecond?"(AND)":"", rly+1, act?"ON":"OFF");
      // Alert JSON
      char ab[160];
      snprintf(ab, sizeof(ab),
        "{\"type\":\"rule_fired\",\"rule\":%d,\"relay\":%d,"
        "\"action\":\"%s\",\"val\":%.1f,\"has2\":%s,\"ts\":%lu}",
        i+1, rly+1, act?"on":"off", val1, rules[i].hasSecond?"true":"false", millis()/1000);
      if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        if (mqttClient.connected()) mqttClient.publish(TOPIC("alert"), ab);
        xSemaphoreGive(mqttMutex);
      }
      if (xSemaphoreTake(rulesMutex, pdMS_TO_TICKS(50)) != pdTRUE) return;
    } else if (reset) {
      rules[i].triggered = false;
    }
  }
  xSemaphoreGive(rulesMutex);
}

// ============================================================
// [B4] NVS SCHEDULE PERSISTENCE
// ============================================================

// Salin slot NVS → entry runtime yang dibaca taskSchedule
void syncRuntimeSchedule(int slot) {
  if (xSemaphoreTake(scheduleMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    ScheduleEntry &e = schedules[slot];
    const NvsScheduleSlot &n = nvsSchedules[slot];
    e.active = n.active; e.relay = n.relay; e.action = n.action;
    e.hour = n.hour; e.minute = n.minute; e.repeat = n.repeat;
    e.days = n.days; e.mode = n.mode; e.offset = n.offset;
    e.triggered = false;
    xSemaphoreGive(scheduleMutex);
  }
}

void saveNvsSchedule(int slot) {
  if (slot<0||slot>=MAX_SCHEDULES_NVS) return;
  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(300)) == pdTRUE) {
    char k[16];
    snprintf(k,sizeof(k),"sc_%d_act",slot); prefs.putBool(k, nvsSchedules[slot].active);
    snprintf(k,sizeof(k),"sc_%d_rel",slot); prefs.putUChar(k, nvsSchedules[slot].relay);
    snprintf(k,sizeof(k),"sc_%d_do",slot);  prefs.putBool(k, nvsSchedules[slot].action);
    snprintf(k,sizeof(k),"sc_%d_hr",slot);  prefs.putUChar(k, nvsSchedules[slot].hour);
    snprintf(k,sizeof(k),"sc_%d_mn",slot);  prefs.putUChar(k, nvsSchedules[slot].minute);
    snprintf(k,sizeof(k),"sc_%d_rp",slot);  prefs.putUChar(k, (uint8_t)nvsSchedules[slot].repeat);
    snprintf(k,sizeof(k),"sc_%d_dy",slot);  prefs.putUChar(k, nvsSchedules[slot].days);    // [T3]
    snprintf(k,sizeof(k),"sc_%d_md",slot);  prefs.putUChar(k, nvsSchedules[slot].mode);    // [T4]
    snprintf(k,sizeof(k),"sc_%d_of",slot);  prefs.putShort(k, nvsSchedules[slot].offset);  // [T4]
    xSemaphoreGive(nvsMutex);
  }
  syncRuntimeSchedule(slot);
  Serial.printf("[Sched#%d] Saved: R%d %s %s %02d:%02d off=%d %s days=0x%02X act=%d\n", slot+1,
    nvsSchedules[slot].relay+1, nvsSchedules[slot].action?"ON":"OFF",
    schedModeStr(nvsSchedules[slot].mode), nvsSchedules[slot].hour, nvsSchedules[slot].minute,
    nvsSchedules[slot].offset, repeatTypeStr(nvsSchedules[slot].repeat), nvsSchedules[slot].days,
    nvsSchedules[slot].active);
}

void loadNvsSchedules() {
  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(300)) == pdTRUE) {
    for (int i=0;i<MAX_SCHEDULES_NVS;i++) {
      char k[16];
      snprintf(k,sizeof(k),"sc_%d_act",i); nvsSchedules[i].active = prefs.getBool(k, false);
      snprintf(k,sizeof(k),"sc_%d_rel",i); nvsSchedules[i].relay  = prefs.getUChar(k, 0);
      snprintf(k,sizeof(k),"sc_%d_do",i);  nvsSchedules[i].action = prefs.getBool(k, false);
      snprintf(k,sizeof(k),"sc_%d_hr",i);  nvsSchedules[i].hour   = prefs.getUChar(k, 0);
      snprintf(k,sizeof(k),"sc_%d_mn",i);  nvsSchedules[i].minute = prefs.getUChar(k, 0);
      snprintf(k,sizeof(k),"sc_%d_rp",i);  nvsSchedules[i].repeat = (RepeatType)prefs.getUChar(k,0);
      // [T3/T4] Key baru — data lama dari v4.0 otomatis dapat default (semua hari, jam tetap)
      snprintf(k,sizeof(k),"sc_%d_dy",i);  nvsSchedules[i].days   = prefs.getUChar(k, ALL_DAYS);
      snprintf(k,sizeof(k),"sc_%d_md",i);  nvsSchedules[i].mode   = prefs.getUChar(k, SM_FIXED);
      snprintf(k,sizeof(k),"sc_%d_of",i);  nvsSchedules[i].offset = prefs.getShort(k, 0);
      if (nvsSchedules[i].relay > 3)            nvsSchedules[i].active = false;   // data rusak
      if (nvsSchedules[i].mode > SM_SUNSET)     nvsSchedules[i].mode = SM_FIXED;
      if ((nvsSchedules[i].days & ALL_DAYS) == 0) nvsSchedules[i].days = ALL_DAYS;
    }
    xSemaphoreGive(nvsMutex);
  }
  for (int i=0;i<MAX_SCHEDULES_NVS;i++) {
    syncRuntimeSchedule(i);
    if (nvsSchedules[i].active)
      Serial.printf("[Sched#%d] Loaded: R%d %s %s %02d:%02d off=%d %s days=0x%02X\n", i+1,
        nvsSchedules[i].relay+1, nvsSchedules[i].action?"ON":"OFF",
        schedModeStr(nvsSchedules[i].mode), nvsSchedules[i].hour, nvsSchedules[i].minute,
        nvsSchedules[i].offset, repeatTypeStr(nvsSchedules[i].repeat), nvsSchedules[i].days);
  }
}

void deleteNvsSchedule(int slot) {
  if (slot<0||slot>=MAX_SCHEDULES_NVS) return;
  nvsSchedules[slot] = NvsScheduleSlot();
  syncRuntimeSchedule(slot);
  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(300)) == pdTRUE) {
    char k[16];
    snprintf(k,sizeof(k),"sc_%d_act",slot); prefs.putBool(k, false);
    xSemaphoreGive(nvsMutex);
  }
  Serial.printf("[Sched#%d] Deleted\n", slot+1);
}

// [T3/T4] Simpan satu slot jadwal (dipakai save_schedule & rtc_schedule)
void storeSchedule(int slot, uint8_t relay, bool action, uint8_t h, uint8_t m,
                   RepeatType r, uint8_t days, uint8_t mode, int16_t offset) {
  if (slot<0||slot>=MAX_SCHEDULES_NVS) return;
  NvsScheduleSlot &n = nvsSchedules[slot];
  n.active = true; n.relay = relay; n.action = action;
  n.hour = h; n.minute = m; n.repeat = r;
  n.days = (days & ALL_DAYS) ? (days & ALL_DAYS) : ALL_DAYS;
  n.mode = (mode <= SM_SUNSET) ? mode : (uint8_t)SM_FIXED;
  n.offset = constrain(offset, -720, 720);
  saveNvsSchedule(slot);
}

// [T4] Menit target (0..1439) sebuah jadwal hari ini, -1 bila tidak bisa dihitung
int scheduleTargetMin(const ScheduleEntry &s) {
  if (s.mode == SM_FIXED) return s.hour * 60 + s.minute;
  int base = (s.mode == SM_SUNRISE) ? sunriseMin : sunsetMin;
  if (base < 0) return -1;
  return ((base + s.offset) % 1440 + 1440) % 1440;
}

void publishSchedules() {
  char buf[900]; int pos = 0;
  pos += snprintf(buf+pos, sizeof(buf)-pos, "{\"n\":%d,\"slots\":[", MAX_SCHEDULES_NVS);
  for (int i=0;i<MAX_SCHEDULES_NVS;i++) {
    const NvsScheduleSlot &n = nvsSchedules[i];
    // Untuk jadwal matahari, hour/minute = jam efektif hari ini (agar dashboard lama tetap terbaca)
    ScheduleEntry tmp; tmp.hour = n.hour; tmp.minute = n.minute; tmp.mode = n.mode; tmp.offset = n.offset;
    int tgt = scheduleTargetMin(tmp);
    int hh = tgt >= 0 ? tgt / 60 : n.hour, mm = tgt >= 0 ? tgt % 60 : n.minute;
    pos += snprintf(buf+pos, sizeof(buf)-pos,
      "{\"id\":%d,\"active\":%s,\"relay\":%d,\"action\":\"%s\","
      "\"hour\":%d,\"minute\":%d,\"repeat\":\"%s\",\"days\":%d,"
      "\"mode\":\"%s\",\"offset\":%d}%s",
      i+1, n.active?"true":"false", n.relay+1, n.action?"on":"off",
      hh, mm, repeatTypeStr(n.repeat), n.days,
      schedModeStr(n.mode), n.offset,
      i<MAX_SCHEDULES_NVS-1?",":"");
  }
  pos += snprintf(buf+pos, sizeof(buf)-pos, "]}");
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC("schedules"), buf);
    xSemaphoreGive(mqttMutex);
  }
}

const char* schedModeStr(uint8_t m) {
  switch (m) { case SM_SUNRISE: return "sunrise"; case SM_SUNSET: return "sunset"; default: return "fixed"; }
}
uint8_t parseSchedMode(const char* s) {
  if (!s) return SM_FIXED;
  if (strcmp(s,"sunrise")==0 || strcmp(s,"1")==0) return SM_SUNRISE;
  if (strcmp(s,"sunset")==0  || strcmp(s,"2")==0) return SM_SUNSET;
  return SM_FIXED;
}

// ============================================================
// [T4] JADWAL MATAHARI — NOAA sunrise equation (zenith 90.833°)
// ============================================================

// Hasil: menit sejak 00:00 waktu lokal (GMT_OFFSET_HOURS), -1 bila matahari tidak terbit/terbenam
int calcSunMin(int y, int m, int d, float lat, float lon, bool rising) {
  const float R = DEG_TO_RAD;
  int N1 = 275 * m / 9;
  int N2 = (m + 9) / 12;
  int N3 = 1 + (y - 4 * (y / 4) + 2) / 3;
  int N  = N1 - (N2 * N3) + d - 30;                       // hari ke-n dalam tahun
  float lngHour = lon / 15.0f;
  float t = N + ((rising ? 6.0f : 18.0f) - lngHour) / 24.0f;
  float M = 0.9856f * t - 3.289f;                          // anomali rata-rata
  float L = M + 1.916f * sinf(M * R) + 0.020f * sinf(2 * M * R) + 282.634f;
  L = fmodf(L + 360.0f, 360.0f);                           // bujur sejati matahari
  float RA = atanf(0.91764f * tanf(L * R)) / R;
  RA = fmodf(RA + 360.0f, 360.0f);
  RA = (RA + (floorf(L / 90.0f) * 90.0f - floorf(RA / 90.0f) * 90.0f)) / 15.0f;
  float sinDec = 0.39782f * sinf(L * R);
  float cosDec = cosf(asinf(sinDec));
  float cosH = (cosf(90.833f * R) - sinDec * sinf(lat * R)) / (cosDec * cosf(lat * R));
  if (cosH > 1.0f || cosH < -1.0f) return -1;
  float H = rising ? 360.0f - acosf(cosH) / R : acosf(cosH) / R;
  H /= 15.0f;
  float T  = H + RA - 0.06571f * t - 6.622f;
  float UT = fmodf(T - lngHour, 24.0f); if (UT < 0) UT += 24.0f;
  float local = fmodf(UT + GMT_OFFSET_HOURS, 24.0f);
  return (int)lroundf(local * 60.0f) % 1440;
}

void recomputeSun(const DateTime &wib) {
  sunriseMin = calcSunMin(wib.year(), wib.month(), wib.day(), locLat, locLon, true);
  sunsetMin  = calcSunMin(wib.year(), wib.month(), wib.day(), locLat, locLon, false);
  sunDay   = wib.day();
  sunDirty = false;
  Serial.printf("[Sun] %04d-%02d-%02d lat=%.4f lon=%.4f terbit %02d:%02d terbenam %02d:%02d\n",
    wib.year(), wib.month(), wib.day(), locLat, locLon,
    sunriseMin/60, sunriseMin%60, sunsetMin/60, sunsetMin%60);
}

void publishSun() {
  char rise[6] = "--:--", set[6] = "--:--";
  if (sunriseMin >= 0) snprintf(rise, sizeof(rise), "%02d:%02d", sunriseMin/60, sunriseMin%60);
  if (sunsetMin  >= 0) snprintf(set,  sizeof(set),  "%02d:%02d", sunsetMin/60,  sunsetMin%60);
  char buf[112];
  snprintf(buf, sizeof(buf), "{\"sunrise\":\"%s\",\"sunset\":\"%s\",\"lat\":%.4f,\"lon\":%.4f}",
           rise, set, locLat, locLon);
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC("sun"), buf);
    xSemaphoreGive(mqttMutex);
  }
}

void loadLocation() {
  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(300)) == pdTRUE) {
    locLat = prefs.getFloat("loc_lat", DEFAULT_LAT);
    locLon = prefs.getFloat("loc_lon", DEFAULT_LON);
    xSemaphoreGive(nvsMutex);
  }
  sunDirty = true;
  Serial.printf("[Sun] Lokasi: %.4f, %.4f\n", locLat, locLon);
}

// [T2] Publish jam DS3231 (waktu dinding WIB)
void publishTime() {
  DateTime wib = getIndonesiaTime();
  bool valid = wib.year() >= 2025;           // RTC reset ke 2024-01-01 saat kehilangan daya
  char buf[144];
  snprintf(buf, sizeof(buf),
    "{\"time\":\"%02d:%02d:%02d\",\"date\":\"%02d/%02d/%04d\",\"epoch\":%lu,"
    "\"dow\":%d,\"valid\":%s,\"tz\":\"%s\"}",
    wib.hour(), wib.minute(), wib.second(), wib.day(), wib.month(), wib.year(),
    (unsigned long)wib.unixtime(), wib.dayOfTheWeek(), valid ? "true" : "false", TIMEZONE_NAME);
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC("time"), buf);
    xSemaphoreGive(mqttMutex);
  }
}

// ============================================================
// [C3] SENSOR STATS — Min/Max/Avg rolling window
// ============================================================

void updateSensorStats(float t, float h) {
  if (xSemaphoreTake(sstatMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    if (t < sensorStat.tempMin) sensorStat.tempMin = t;
    if (t > sensorStat.tempMax) sensorStat.tempMax = t;
    sensorStat.tempSum += t;
    if (h < sensorStat.humMin)  sensorStat.humMin  = h;
    if (h > sensorStat.humMax)  sensorStat.humMax  = h;
    sensorStat.humSum  += h;
    sensorStat.n++;
    xSemaphoreGive(sstatMutex);
  }
}

// ============================================================
// [D5] OTA HTTP ENDPOINT
// ============================================================

void publishOtaProgress(int pct, const char* status, size_t size) {
  char buf[128];
  snprintf(buf, sizeof(buf),
    "{\"pct\":%d,\"status\":\"%s\",\"size\":%u}", pct, status, (unsigned)size);
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC("ota_progress"), buf);
    xSemaphoreGive(mqttMutex);
  }
}

void setupOtaEndpoints() {
  // GET /ota — info halaman OTA (untuk debugging browser)
  httpServer.on("/ota", HTTP_GET, []() {
    String ip = WiFi.localIP().toString();
    httpServer.send(200, "text/html",
      "<html><body><h2>Luminous v" FW_VERSION " OTA</h2>"
      "<p>IP: " + ip + "</p>"
      "<p>POST multipart/form-data ke /ota dengan field <code>firmware</code></p>"
      "</body></html>");
  });

  // POST /ota — upload .bin firmware
  httpServer.on("/ota", HTTP_POST,
    // Handler setelah upload selesai
    []() {
      if (Update.hasError()) {
        httpServer.send(500, "text/plain", "OTA GAGAL: " + String(Update.errorString()));
        publishOtaProgress(-1, "error", 0);
        otaBusy = false;
      } else {
        httpServer.send(200, "text/plain", "OTA Berhasil! ESP32 akan reboot...");
        publishOtaProgress(100, "done", 0);
        delay(1000);
        ESP.restart();
      }
    },
    // Handler per chunk upload
    []() {
      HTTPUpload& upload = httpServer.upload();
      if (upload.status == UPLOAD_FILE_START) {
        otaBusy = true;
        Serial.printf("[OTA-HTTP] Start: %s size=%u\n", upload.filename.c_str(), upload.totalSize);
        publishOtaProgress(0, "uploading", upload.totalSize);
        if (!Update.begin(UPDATE_SIZE_UNKNOWN)) {
          Serial.printf("[OTA-HTTP] Begin error: %s\n", Update.errorString());
          publishOtaProgress(-1, "error", 0);
          otaBusy = false;
        }
      } else if (upload.status == UPLOAD_FILE_WRITE) {
        if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
          Serial.printf("[OTA-HTTP] Write error: %s\n", Update.errorString());
        }
        // Update.progress() = bytes ditulis ke flash; HTTPUpload tidak punya totalBytesRead
        if (upload.totalSize > 0) {
          size_t otaWritten = Update.progress();
          int pct = (int)(otaWritten * 100 / upload.totalSize);
          if (pct % 5 == 0) publishOtaProgress(pct, "uploading", upload.totalSize);
          Serial.printf("[OTA-HTTP] %d%% (%u/%u)\n", pct, otaWritten, upload.totalSize);
        }
      } else if (upload.status == UPLOAD_FILE_END) {
        if (Update.end(true)) {
          Serial.printf("[OTA-HTTP] Done: %u bytes\n", upload.totalSize);
          publishOtaProgress(99, "flashing", upload.totalSize);
        } else {
          Serial.printf("[OTA-HTTP] End error: %s\n", Update.errorString());
          publishOtaProgress(-1, "error", 0);
          otaBusy = false;
        }
      }
    }
  );

  // GET /ota_info — info OTA status via MQTT
  httpServer.on("/ota_info", HTTP_GET, []() {
    char buf[200];
    snprintf(buf, sizeof(buf),
      "{\"ip\":\"%s\",\"version\":\"" FW_VERSION "\",\"heap\":%lu,\"uptime\":%lu}",
      WiFi.localIP().toString().c_str(), ESP.getFreeHeap(), millis()/1000);
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("ota_status"), buf);
      xSemaphoreGive(mqttMutex);
    }
    httpServer.send(200, "application/json", buf);
  });
}

// ============================================================
// RELAY CONTROL + STATS [N3]
// ============================================================

void updateRelayStats(int idx, bool newState) {
  if (idx<0||idx>=4) return;
  if (xSemaphoreTake(statsMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    RelayStats &s = relayStats[idx];
    if  (newState && !s.isOn) { s.lastOnMs = millis(); s.cycleCount++; s.isOn = true; }
    else if (!newState && s.isOn) { s.totalOnMs += (millis()-s.lastOnMs); s.isOn = false; }
    xSemaphoreGive(statsMutex);
  }
}

void controlRelay(int idx, bool turnOn) {
  if (idx<0||idx>=4) return;
  updateRelayStats(idx, turnOn);
  digitalWrite(RELAY_PINS[idx], turnOn ? RELAY_ON : RELAY_OFF);
  Serial.printf("[Relay] R%d → %s\n", idx+1, turnOn?"NYALA":"MATI");
  publishRelayStatus(idx, turnOn);
  publishRelayStats(idx);
}

// [S1] controlRelay + catat sumber perubahan (dashboard menampilkan "via saklar", dst.)
void controlRelaySrc(int idx, bool turnOn, const char* src) {
  if (idx<0||idx>=4) return;
  controlRelay(idx, turnOn);
  publishRelayEvent(idx, turnOn, src);
}

void publishRelayEvent(int idx, bool state, const char* src) {
  char pl[80];
  snprintf(pl, sizeof(pl), "{\"relay\":%d,\"state\":%s,\"src\":\"%s\"}",
           idx+1, state?"true":"false", src?src:"remote");
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC("relay_event"), pl);
    xSemaphoreGive(mqttMutex);
  }
}

// ============================================================
// [S1] SAKLAR MANUAL
// ============================================================
void initSwitches() {
  uint32_t now = millis();
  for (int i=0;i<4;i++) {
    pinMode(SWITCH_PINS[i], INPUT_PULLUP);
  }
  delay(5);                                   // biarkan pull-up stabil
  for (int i=0;i<4;i++) {
    bool raw = digitalRead(SWITCH_PINS[i]) == LOW;
    // Posisi awal saklar dinding TIDAK mengubah relay saat boot — hanya dicatat
    swState[i].stable = swState[i].lastRaw = raw;
    swState[i].changedAt = now;
    swState[i].longFired = raw;               // push button tertahan saat boot → abaikan
  }
}

void loadSwitchLocks() {
  if (xSemaphoreTake(nvsMutex, pdMS_TO_TICKS(300)) == pdTRUE) {
    for (int i=0;i<4;i++) {
      char k[12]; snprintf(k,sizeof(k),"sw_lk_%d",i);
      switchLocked[i] = prefs.getBool(k, false);
    }
    xSemaphoreGive(nvsMutex);
  }
}

static void publishSwitchAlert(int idx) {
  char ab[96];
  snprintf(ab, sizeof(ab), "{\"type\":\"switch_locked\",\"relay\":%d,\"val\":%d,\"ts\":%lu}",
           idx+1, idx+1, (unsigned long)(millis()/1000));
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC("alert"), ab);
    xSemaphoreGive(mqttMutex);
  }
}

// Saklar dioperasikan (toggle berubah posisi / push ditekan) → balik relay
static void onSwitchActuated(int i) {
  if (switchLocked[i]) {
    Serial.printf("[Switch] S%d dikunci — diabaikan\n", i+1);
    publishSwitchAlert(i);
    return;
  }
  bool cur = digitalRead(RELAY_PINS[i]) == RELAY_ON;
  Serial.printf("[Switch] S%d → R%d %s\n", i+1, i+1, cur ? "MATI" : "NYALA");
  controlRelaySrc(i, !cur, "switch");
}

// Push button ditahan lama → matikan semua relay (relay terkunci tetap ikut mati demi keamanan)
static void onSwitchLongPress(int i) {
  if (switchLocked[i]) { publishSwitchAlert(i); return; }
  Serial.printf("[Switch] S%d ditahan → semua relay OFF\n", i+1);
  for (int j=0;j<4;j++)
    if (digitalRead(RELAY_PINS[j]) == RELAY_ON) controlRelaySrc(j, false, "switch_all");
}

// Satu putaran baca + debounce semua saklar (dipisah dari task agar bisa diuji)
void switchPoll(uint32_t now) {
  for (int i=0;i<4;i++) {
    SwitchState &st = swState[i];
    bool raw = digitalRead(SWITCH_PINS[i]) == LOW;
    if (raw != st.lastRaw) { st.lastRaw = raw; st.changedAt = now; }
    if (raw != st.stable && (now - st.changedAt) >= SWITCH_DEBOUNCE_MS) {
      st.stable = raw;
      if (SWITCH_TYPE[i] == SW_TOGGLE) {
        onSwitchActuated(i);                         // setiap posisi berubah
      } else if (raw) {                              // push: aksi saat ditekan
        st.pressedAt = now; st.longFired = false;
        onSwitchActuated(i);
      }
      publishSwitches();                             // posisi terbaru ke dashboard
    }
    if (SWITCH_TYPE[i] == SW_PUSH && st.stable && !st.longFired &&
        (now - st.pressedAt) >= SWITCH_LONGPRESS_MS) {
      st.longFired = true;
      onSwitchLongPress(i);
    }
  }
}

void taskSwitch(void* p) {
  esp_task_wdt_add(NULL);
  for (;;) {
    esp_task_wdt_reset();
    switchPoll(millis());
    vTaskDelay(pdMS_TO_TICKS(SWITCH_POLL_MS));
  }
}

void publishSwitches() {
  char buf[220]; int pos = 0;
  pos += snprintf(buf+pos, sizeof(buf)-pos, "{\"n\":4,\"pins\":[");
  for (int i=0;i<4;i++) pos += snprintf(buf+pos, sizeof(buf)-pos, "%d%s", SWITCH_PINS[i], i<3?",":"");
  pos += snprintf(buf+pos, sizeof(buf)-pos, "],\"type\":[");
  for (int i=0;i<4;i++) pos += snprintf(buf+pos, sizeof(buf)-pos, "\"%s\"%s", SWITCH_TYPE[i]==SW_PUSH?"push":"toggle", i<3?",":"");
  pos += snprintf(buf+pos, sizeof(buf)-pos, "],\"locked\":[");
  for (int i=0;i<4;i++) pos += snprintf(buf+pos, sizeof(buf)-pos, "%s%s", switchLocked[i]?"true":"false", i<3?",":"");
  pos += snprintf(buf+pos, sizeof(buf)-pos, "],\"pos\":[");
  for (int i=0;i<4;i++) pos += snprintf(buf+pos, sizeof(buf)-pos, "%s%s", swState[i].stable?"true":"false", i<3?",":"");
  snprintf(buf+pos, sizeof(buf)-pos, "]}");
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC("switches"), buf);
    xSemaphoreGive(mqttMutex);
  }
}

void publishRelayStatus(int idx, bool state) {
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) {
      char pl[24]; snprintf(pl,sizeof(pl),"relay%d %s",idx+1,state?"true":"false");
      mqttClient.publish(TOPIC("relayStatus"), pl);
    }
    xSemaphoreGive(mqttMutex);
  }
}

void publishAllRelayStates() {
  // Delay awal supaya broker benar-benar siap setelah connect
  for (int i=0;i<4;i++) {
    bool state = (digitalRead(RELAY_PINS[i])==RELAY_ON);
    // Coba publish max 3x jika gagal
    for (int attempt=0; attempt<3; attempt++) {
      if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(150)) == pdTRUE) {
        if (mqttClient.connected()) {
          char pl[24];
          snprintf(pl,sizeof(pl),"relay%d %s",i+1,state?"true":"false");
          bool ok = mqttClient.publish(TOPIC("relayStatus"), pl);
          xSemaphoreGive(mqttMutex);
          if (ok) break;
        } else {
          xSemaphoreGive(mqttMutex);
          break;
        }
      }
      vTaskDelay(pdMS_TO_TICKS(80));
    }
    vTaskDelay(pdMS_TO_TICKS(100)); // jeda antar relay
  }
  Serial.println("[MQTT] All relay states published");
}

void publishAlert(const char* type, float val) {
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) {
      char buf[96];
      snprintf(buf,sizeof(buf),"{\"type\":\"%s\",\"val\":%.1f,\"ts\":%lu}",
               type, val, millis()/1000);
      mqttClient.publish(TOPIC("alert"), buf);
    }
    xSemaphoreGive(mqttMutex);
  }
}

void publishAlertSimple(const char* msg) { publishAlert(msg, 0.0f); }

void publishRelayStats(int idx) {
  if (idx<0||idx>=4) return;
  RelayStats snap;
  if (xSemaphoreTake(statsMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    snap = relayStats[idx];
    if (snap.isOn) snap.totalOnMs += (millis()-snap.lastOnMs);
    xSemaphoreGive(statsMutex);
  }
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) {
      char buf[128];
      snprintf(buf,sizeof(buf),
        "{\"relay\":%d,\"on_ms\":%lu,\"cycles\":%lu,\"is_on\":%s}",
        idx+1, snap.totalOnMs, snap.cycleCount, snap.isOn?"true":"false");
      mqttClient.publish(TOPIC("relay_stats"), buf);
    }
    xSemaphoreGive(mqttMutex);
  }
}

// [A2] Publish status timer dari slot ke esp32/timer_status
void publishTimerStatus(uint8_t slot) {
  TimerTrack snap;
  if (xSemaphoreTake(trackMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    snap = timerTracks[slot]; xSemaphoreGive(trackMutex);
  }
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) {
      char buf[128];
      snprintf(buf,sizeof(buf),
        "{\"relay\":%d,\"action\":\"%s\","
        "\"remaining\":%lu,\"total\":%lu,\"active\":%s}",
        snap.relay+1, snap.turnOn?"on":"off",
        snap.remaining, snap.total,
        snap.active?"true":"false");
      mqttClient.publish(TOPIC("timer_status"), buf);
    }
    xSemaphoreGive(mqttMutex);
  }
}

void publishDeviceHealth() {
  int activeRules = 0;
  for (int i=0;i<MAX_RULES;i++) if (rules[i].active) activeRules++;

  // [C3] snapshot sensor stats
  SensorStats ss;
  if (xSemaphoreTake(sstatMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    ss = sensorStat; xSemaphoreGive(sstatMutex);
  }
  float tAvg = (ss.n > 0) ? (float)(ss.tempSum / ss.n) : 0.0f;
  float hAvg = (ss.n > 0) ? (float)(ss.humSum  / ss.n) : 0.0f;
  float tMin = (ss.n > 0) ? ss.tempMin : 0.0f;
  float tMax = (ss.n > 0) ? ss.tempMax : 0.0f;
  float hMin = (ss.n > 0) ? ss.humMin  : 0.0f;
  float hMax = (ss.n > 0) ? ss.humMax  : 0.0f;

  char buf[512];
  snprintf(buf,sizeof(buf),
    "{\"uptime\":%lu,\"heap\":%lu,\"heap_min\":%lu,\"rssi\":%d,"
    "\"timers\":%d,\"rules\":%d,\"hist_cnt\":%d,"
    "\"wifi\":%s,\"mqtt\":%s,\"temp\":%.1f,\"hum\":%.1f,"
    "\"stat_n\":%lu,\"t_min\":%.1f,\"t_max\":%.1f,\"t_avg\":%.1f,"
    "\"h_min\":%.1f,\"h_max\":%.1f,\"h_avg\":%.1f}",
    millis()/1000, ESP.getFreeHeap(), ESP.getMinFreeHeap(),
    WiFi.isConnected()?WiFi.RSSI():-999,
    activeTimers, activeRules, histCnt,
    wifiConnected?"true":"false", mqttClient.connected()?"true":"false",
    isnan(lastTemp)?0.0f:(float)lastTemp, isnan(lastHum)?0.0f:(float)lastHum,
    ss.n, tMin, tMax, tAvg, hMin, hMax, hAvg);
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (mqttClient.connected()) mqttClient.publish(TOPIC("health"), buf);
    xSemaphoreGive(mqttMutex);
  }
}

void checkSensorThresholds(float t, float h) {
  static bool tHiA=false,tLoA=false,hHiA=false,hLoA=false;
  if (t>thresholds.temp_hi&&!tHiA){publishAlert("temp_hi",t);tHiA=true;}
  else if(t<=thresholds.temp_hi) tHiA=false;
  if (t<thresholds.temp_lo&&!tLoA){publishAlert("temp_lo",t);tLoA=true;}
  else if(t>=thresholds.temp_lo) tLoA=false;
  if (h>thresholds.hum_hi&&!hHiA){publishAlert("hum_hi",h);hHiA=true;}
  else if(h<=thresholds.hum_hi)  hHiA=false;
  if (h<thresholds.hum_lo&&!hLoA){publishAlert("hum_lo",h);hLoA=true;}
  else if(h>=thresholds.hum_lo)  hLoA=false;
}

// ============================================================
// SCHEDULE & TIMER
// ============================================================

int findFreeTimerSlot() {
  int slot = -1;
  if (xSemaphoreTake(trackMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    for (int i=0;i<MAX_TIMERS;i++) if (!timerTracks[i].active) { slot=i; break; }
    xSemaphoreGive(trackMutex);
  }
  return slot;
}

bool startTimer(bool turnOn, uint8_t relayIndex, uint32_t dur) {
  bool allowed = false;
  if (xSemaphoreTake(timerMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (activeTimers < MAX_TIMERS) { activeTimers++; allowed = true; }
    xSemaphoreGive(timerMutex);
  }
  if (!allowed) return false;
  int slot = findFreeTimerSlot();
  if (slot < 0) {
    if (xSemaphoreTake(timerMutex,pdMS_TO_TICKS(50))==pdTRUE){activeTimers--;xSemaphoreGive(timerMutex);}
    return false;
  }
  TimerParams* p = (TimerParams*)malloc(sizeof(TimerParams));
  if (!p) {
    if (xSemaphoreTake(timerMutex,pdMS_TO_TICKS(50))==pdTRUE){activeTimers--;xSemaphoreGive(timerMutex);}
    return false;
  }
  p->relayIndex = relayIndex; p->duration = dur;
  p->turnOn = turnOn; p->trackSlot = (uint8_t)slot;
  char name[20]; snprintf(name,sizeof(name),"T%d_%s",relayIndex+1,turnOn?"ON":"OF");
  if (xTaskCreate(timerTask,name,3072,p,1,NULL) != pdPASS) {
    free(p);
    if (xSemaphoreTake(timerMutex,pdMS_TO_TICKS(50))==pdTRUE){activeTimers--;xSemaphoreGive(timerMutex);}
    return false;
  }
  Serial.printf("[Timer] R%d %s in %lus (slot%d)\n", relayIndex+1, turnOn?"ON":"OFF", dur, slot);
  return true;
}

// ============================================================
// COMMAND PROCESSOR
// ============================================================

void processCommand(const char* raw) {
  char buf[256]; strncpy(buf,raw,sizeof(buf)-1); buf[sizeof(buf)-1]='\0';
  int n=strlen(buf);
  while(n>0&&(buf[n-1]=='\n'||buf[n-1]=='\r'||buf[n-1]==' ')) buf[--n]='\0';
  if (!n) return;
  Serial.printf("[CMD] %s\n", buf);

  // ping
  if (strcmp(buf,"ping")==0) {
    char pong[128];
    snprintf(pong,sizeof(pong),"{\"uptime\":%lu,\"heap\":%lu,\"rssi\":%d}",
      millis()/1000, ESP.getFreeHeap(), WiFi.isConnected()?WiFi.RSSI():-999);
    if (xSemaphoreTake(mqttMutex,pdMS_TO_TICKS(100))==pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("pong"),pong);
      xSemaphoreGive(mqttMutex);
    }
    return;
  }

  // set_time:YYYY:MM:DD:HH:mm:SS
  if (strncmp(buf,"set_time:",9)==0) {
    int yr,mo,dy,hh,mm,ss;
    if (sscanf(buf+9,"%d:%d:%d:%d:%d:%d",&yr,&mo,&dy,&hh,&mm,&ss)==6) {
      setRTCTime(yr,mo,dy,hh,mm,ss);
      sunDirty = true;        // [T4] tanggal bisa berubah → hitung ulang matahari
      publishTime();          // [T2] konfirmasi ke dashboard
    }
    return;
  }

  // [T2] get_time
  if (strcmp(buf,"get_time")==0) { publishTime(); return; }

  // [S1] get_switches
  if (strcmp(buf,"get_switches")==0) { publishSwitches(); return; }

  // [S1] switch_lock:<1-4|all>:<on|off>
  if (strncmp(buf,"switch_lock:",12)==0) {
    char tmp[32]; strncpy(tmp,buf+12,sizeof(tmp)-1); tmp[sizeof(tmp)-1]='\0';
    char *who=strtok(tmp,":"), *val=strtok(NULL,":");
    if (!who||!val) return;
    bool lock = strcmp(val,"on")==0 || strcmp(val,"1")==0 || strcmp(val,"true")==0;
    int from=0, to=3;
    if (strcmp(who,"all")!=0) { int n=atoi(who); if (n<1||n>4) return; from=to=n-1; }
    if (xSemaphoreTake(nvsMutex,pdMS_TO_TICKS(300))==pdTRUE) {
      for (int i=from;i<=to;i++) {
        switchLocked[i]=lock;
        char k[12]; snprintf(k,sizeof(k),"sw_lk_%d",i); prefs.putBool(k,lock);
      }
      xSemaphoreGive(nvsMutex);
    }
    Serial.printf("[Switch] %s %s\n", who, lock?"DIKUNCI":"DIBUKA");
    publishSwitches();
    return;
  }

  // [T4] get_sun
  if (strcmp(buf,"get_sun")==0) { publishSun(); return; }

  // [T4] set_location:<lat>:<lon>
  if (strncmp(buf,"set_location:",13)==0) {
    char tmp[64]; strncpy(tmp,buf+13,sizeof(tmp)-1); tmp[sizeof(tmp)-1]='\0';
    char *sLat=strtok(tmp,":"), *sLon=strtok(NULL,":");
    if (!sLat||!sLon) return;
    float la=atof(sLat), lo=atof(sLon);
    if (la<-90||la>90||lo<-180||lo>180) return;
    locLat=la; locLon=lo;
    if (xSemaphoreTake(nvsMutex,pdMS_TO_TICKS(300))==pdTRUE) {
      prefs.putFloat("loc_lat",la); prefs.putFloat("loc_lon",lo);
      xSemaphoreGive(nvsMutex);
    }
    sunDirty = true;          // taskSchedule menghitung ulang & publish sun + schedules
    char ack[96];
    snprintf(ack,sizeof(ack),"{\"type\":\"location_set\",\"lat\":%.4f,\"lon\":%.4f}",la,lo);
    if (xSemaphoreTake(mqttMutex,pdMS_TO_TICKS(100))==pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("config_ack"),ack);
      xSemaphoreGive(mqttMutex);
    }
    return;
  }

  // set_threshold:key:val
  if (strncmp(buf,"set_threshold:",14)==0) {
    char tmp[128]; strncpy(tmp,buf+14,sizeof(tmp)-1);
    char* key=strtok(tmp,":"); char* val=strtok(NULL,":");
    if (!key||!val) return;
    float v=atof(val);
    if      (strcmp(key,"temp_hi")==0) thresholds.temp_hi=v;
    else if (strcmp(key,"temp_lo")==0) thresholds.temp_lo=v;
    else if (strcmp(key,"hum_hi")==0)  thresholds.hum_hi=v;
    else if (strcmp(key,"hum_lo")==0)  thresholds.hum_lo=v;
    char ack[96];
    snprintf(ack,sizeof(ack),"{\"type\":\"threshold_set\",\"key\":\"%s\",\"val\":%.1f}",key,v);
    if (xSemaphoreTake(mqttMutex,pdMS_TO_TICKS(100))==pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("config_ack"),ack);
      xSemaphoreGive(mqttMutex);
    }
    return;
  }

  // [A1/C2] set_rule — backward-compat + dual-kondisi AND
  // Format single: set_rule:<id>:<sensor>:<cond>:<val>:<relay>:<action>
  // Format AND:    set_rule:<id>:<sensor>:<cond>:<val>:<relay>:<action>:<sensor2>:<cond2>:<val2>
  if (strncmp(buf,"set_rule:",9)==0) {
    char tmp[160]; strncpy(tmp,buf+9,sizeof(tmp)-1);
    char *sid=strtok(tmp,":"),*sens=strtok(NULL,":"),
         *cond=strtok(NULL,":"),*val=strtok(NULL,":"),
         *rel=strtok(NULL,":"),*act=strtok(NULL,":");
    // Opsional kondisi 2 [C2]
    char *sens2=strtok(NULL,":"),*cond2=strtok(NULL,":"),*val2=strtok(NULL,":");
    if (!sid||!sens||!cond||!val||!rel||!act) return;
    int id=atoi(sid)-1; if (id<0||id>=MAX_RULES) return;
    int relay=atoi(rel)-1; if (relay<0||relay>3) return;
    if (xSemaphoreTake(rulesMutex,pdMS_TO_TICKS(100))==pdTRUE) {
      rules[id].active    = true;
      rules[id].sensor    = (strcmp(sens,"temp")==0)?RuleSensor::TEMP:RuleSensor::HUM;
      rules[id].cond      = (strcmp(cond,"above")==0)?RuleCond::ABOVE:RuleCond::BELOW;
      rules[id].trigVal   = atof(val);
      rules[id].relay     = (uint8_t)relay;
      rules[id].action    = (strcmp(act,"on")==0);
      rules[id].triggered = false;
      // [C2] kondisi kedua
      if (sens2 && cond2 && val2) {
        rules[id].hasSecond = true;
        rules[id].sensor2   = (strcmp(sens2,"temp")==0)?RuleSensor::TEMP:RuleSensor::HUM;
        rules[id].cond2     = (strcmp(cond2,"above")==0)?RuleCond::ABOVE:RuleCond::BELOW;
        rules[id].trigVal2  = atof(val2);
      } else {
        rules[id].hasSecond = false;
        rules[id].trigVal2  = 0.0f;
      }
      xSemaphoreGive(rulesMutex);
    }
    saveRulesToNVS();
    publishRules();
    char ack[96];
    snprintf(ack,sizeof(ack),"{\"type\":\"rule_set\",\"id\":%d,\"has2\":%s}",
             id+1, rules[id].hasSecond?"true":"false");
    if (xSemaphoreTake(mqttMutex,pdMS_TO_TICKS(100))==pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("config_ack"),ack);
      xSemaphoreGive(mqttMutex);
    }
    return;
  }

  // [A1] del_rule:<1-4>
  if (strncmp(buf,"del_rule:",9)==0) {
    int id=atoi(buf+9)-1; if (id<0||id>=MAX_RULES) return;
    if (xSemaphoreTake(rulesMutex,pdMS_TO_TICKS(100))==pdTRUE) {
      rules[id]=AutoRule(); xSemaphoreGive(rulesMutex);
    }
    saveRulesToNVS(); publishRules();
    return;
  }

  // [A1] rules — publish semua rule
  if (strcmp(buf,"rules")==0) { publishRules(); return; }

  // [A5] get_history:<n>
  if (strncmp(buf,"get_history:",12)==0) {
    int pts=atoi(buf+12);
    if (pts<=0||pts>(int)histCnt) pts=histCnt;
    publishHistory((uint16_t)pts);
    return;
  }

  // [A5] clear_history
  if (strcmp(buf,"clear_history")==0) {
    if (xSemaphoreTake(nvsMutex,pdMS_TO_TICKS(500))==pdTRUE) {
      for (uint16_t i=0;i<HISTORY_POINTS;i++) {
        char k[12];
        snprintf(k,sizeof(k),"sh_t_%d",i);  prefs.remove(k);
        snprintf(k,sizeof(k),"sh_h_%d",i);  prefs.remove(k);
        snprintf(k,sizeof(k),"sh_ts_%d",i); prefs.remove(k);
      }
      histIdx=0; histCnt=0;
      prefs.putUShort("sh_idx",0); prefs.putUShort("sh_cnt",0);
      xSemaphoreGive(nvsMutex);
    }
    // [C3] Reset sensor stats saat clear_history
    if (xSemaphoreTake(sstatMutex,pdMS_TO_TICKS(50))==pdTRUE) {
      sensorStat = SensorStats(); xSemaphoreGive(sstatMutex);
    }
    Serial.println("[Hist] Cleared + stats reset");
    return;
  }

  // [B4/T3/T4] save_schedule:<slot>:<relay>:<on|off>:<HH>:<MM>:<repeat>[:<days>[:<mode>[:<offset>]]]
  //   days   = bitmask 0..127 (bit0=Minggu), dipakai bila repeat=weekly
  //   mode   = fixed | sunrise | sunset ; offset = menit (-720..720) relatif matahari
  if (strncmp(buf,"save_schedule:",14)==0) {
    char tmp[128]; strncpy(tmp,buf+14,sizeof(tmp)-1); tmp[sizeof(tmp)-1]='\0';
    char *slt=strtok(tmp,":"),*rel=strtok(NULL,":"),*act=strtok(NULL,":"),
         *hr=strtok(NULL,":"),*mn=strtok(NULL,":"),*rep=strtok(NULL,":"),
         *dys=strtok(NULL,":"),*mde=strtok(NULL,":"),*ofs=strtok(NULL,":");
    if (!slt||!rel||!act||!hr||!mn) return;
    int slot=atoi(slt)-1; if (slot<0||slot>=MAX_SCHEDULES_NVS) return;
    int relay=atoi(rel)-1; if (relay<0||relay>3) return;
    int hour=atoi(hr),minute=atoi(mn);
    if (hour<0||hour>23||minute<0||minute>59) return;
    RepeatType rt = parseRepeatType(rep);
    uint8_t days = dys ? (uint8_t)(atoi(dys) & ALL_DAYS) : 0;
    if (rt==RepeatType::WEEKLY && days==0) {           // weekly tanpa hari → hari ini saja
      days = (uint8_t)(1 << getIndonesiaTime().dayOfTheWeek());
    }
    storeSchedule(slot, (uint8_t)relay, strcmp(act,"on")==0, (uint8_t)hour, (uint8_t)minute,
                  rt, days, parseSchedMode(mde), ofs ? (int16_t)atoi(ofs) : 0);
    publishSchedules();
    char ack[80];
    snprintf(ack,sizeof(ack),"{\"type\":\"schedule_set\",\"slot\":%d}",slot+1);
    if (xSemaphoreTake(mqttMutex,pdMS_TO_TICKS(100))==pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("config_ack"),ack);
      xSemaphoreGive(mqttMutex);
    }
    return;
  }

  // [B4] del_schedule:<slot>
  if (strncmp(buf,"del_schedule:",13)==0) {
    int slot=atoi(buf+13)-1;
    if (slot<0||slot>=MAX_SCHEDULES_NVS) return;
    deleteNvsSchedule(slot);
    publishSchedules();
    return;
  }

  // [B4] get_schedules
  if (strcmp(buf,"get_schedules")==0) { publishSchedules(); return; }

  // [D5] ota_info
  if (strcmp(buf,"ota_info")==0) {
    char obuf[160];
    snprintf(obuf,sizeof(obuf),
      "{\"ip\":\"%s\",\"port\":80,\"path\":\"/ota\",\"version\":\"" FW_VERSION "\",\"busy\":%s}",
      WiFi.localIP().toString().c_str(), otaBusy?"true":"false");
    if (xSemaphoreTake(mqttMutex,pdMS_TO_TICKS(100))==pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("ota_status"),obuf);
      xSemaphoreGive(mqttMutex);
    }
    return;
  }

  // rtc_schedule:on|off:relay:HH:MM[:repeat]
  if (strncmp(buf,"rtc_schedule:",13)==0) {
    char tmp[256]; strcpy(tmp,buf+13);
    char *act=strtok(tmp,":"),*rel=strtok(NULL,":"),
         *hr=strtok(NULL,":"),*mn=strtok(NULL,":"),*rep=strtok(NULL,":");
    if (!act||!rel||!hr||!mn) return;
    int relay=atoi(rel),hour=atoi(hr),minute=atoi(mn);
    if (relay<1||relay>4||hour<0||hour>23||minute<0||minute>59) return;
    RepeatType repeat=parseRepeatType(rep);
    // [T3] Perintah lama ini kini juga disimpan ke slot NVS (slot kosong pertama,
    //      atau slot pertama jika semua penuh) agar tidak hilang saat restart.
    int slot=-1;
    for (int i=0;i<MAX_SCHEDULES_NVS;i++) if (!nvsSchedules[i].active){slot=i;break;}
    if (slot<0) slot=0;
    uint8_t days = (repeat==RepeatType::WEEKLY) ? (uint8_t)(1 << getIndonesiaTime().dayOfTheWeek()) : ALL_DAYS;
    storeSchedule(slot,(uint8_t)(relay-1),strcmp(act,"on")==0,(uint8_t)hour,(uint8_t)minute,repeat,days,SM_FIXED,0);
    publishSchedules();
    return;
  }

  // relay<N> true|false
  if (strncmp(buf,"relay",5)==0 && n>=8) {
    char* sp=strchr(buf,' '); if (!sp) return;
    *sp='\0'; int rn=atoi(buf+5); char* st=sp+1; while(*st==' ')st++;
    if (rn<1||rn>4) return;
    controlRelaySrc(rn-1, strcmp(st,"true")==0||strcmp(st,"1")==0, "remote");
    return;
  }

  // timer_on / timer_off
  bool tiOn=(strncmp(buf,"timer_on ",9)==0), tiOff=(strncmp(buf,"timer_off ",10)==0);
  if (tiOn||tiOff) {
    char tmp[200]; strcpy(tmp,buf+(tiOn?9:10));
    char *rStr=strtok(tmp," "),*dStr=strtok(NULL," ");
    if (!rStr||!dStr) return;
    int rn=(strncmp(rStr,"relay",5)==0)?atoi(rStr+5):atoi(rStr);
    int dur=atoi(dStr);
    if (rn<1||rn>4||dur<=0) return;
    if (!startTimer(tiOn,(uint8_t)(rn-1),(uint32_t)dur)) publishAlertSimple("timer_limit");
    return;
  }

  if (strcmp(buf,"stats")==0)  { for(int i=0;i<4;i++) publishRelayStats(i); return; }
  if (strcmp(buf,"health")==0) { publishDeviceHealth(); return; }

  // [SYNC-FIX] "sync" — publish semua relay state + sensor ke MQTT (untuk dashboard reconnect)
  if (strcmp(buf,"sync")==0) {
    publishAllRelayStates();
    publishDeviceHealth();
    publishRules();
    publishSchedules();     // [T3]
    publishTime();          // [T2]
    publishSun();           // [T4]
    publishSwitches();      // [S1]
    char ack[48];
    snprintf(ack,sizeof(ack),"{\"type\":\"sync_ok\",\"ts\":%lu}",millis()/1000);
    if (xSemaphoreTake(mqttMutex,pdMS_TO_TICKS(100))==pdTRUE) {
      if (mqttClient.connected()) mqttClient.publish(TOPIC("sync_ack"),ack);
      xSemaphoreGive(mqttMutex);
    }
    Serial.println("[SYNC] Published all relay states to MQTT");
    return;
  }

  if (strcmp(buf,"status")==0) {
    DateTime wib=getIndonesiaTime();
    Serial.printf("=== Luminous v" FW_VERSION " | %02d:%02d:%02d %s ===\n",
      wib.hour(),wib.minute(),wib.second(),TIMEZONE_NAME);
    Serial.printf("WiFi:%s RSSI:%d Heap:%u Uptime:%lus\n",
      WiFi.isConnected()?"OK":"ERR",WiFi.RSSI(),ESP.getFreeHeap(),millis()/1000);
    Serial.printf("MQTT:%s Timers:%d/%d History:%d pts\n",
      mqttClient.connected()?"OK":"ERR",activeTimers,MAX_TIMERS,histCnt);
    Serial.printf("OTA IP: %s port 80\n", WiFi.localIP().toString().c_str());
    for (int i=0;i<4;i++) {
      bool s=(digitalRead(RELAY_PINS[i])==RELAY_ON);
      RelayStats snap;
      if(xSemaphoreTake(statsMutex,pdMS_TO_TICKS(50))==pdTRUE){
        snap=relayStats[i]; if(snap.isOn)snap.totalOnMs+=(millis()-snap.lastOnMs);
        xSemaphoreGive(statsMutex);
      }
      Serial.printf("  R%d:%s ON:%lums Cycles:%lu\n",i+1,s?"ON":"OFF",snap.totalOnMs,snap.cycleCount);
    }
    for (int i=0;i<MAX_RULES;i++) if (rules[i].active)
      Serial.printf("  Rule#%d: %s %s %.1f%s → R%d %s%s\n",i+1,
        rules[i].sensor==RuleSensor::TEMP?"Temp":"Hum",
        rules[i].cond==RuleCond::ABOVE?">":"<",rules[i].trigVal,
        rules[i].hasSecond?" AND(...)":"",
        rules[i].relay+1,rules[i].action?"ON":"OFF",
        rules[i].triggered?" [ON]":"");
    for (int i=0;i<MAX_SCHEDULES_NVS;i++) if (nvsSchedules[i].active)
      Serial.printf("  Sched#%d: R%d %s %s %02d:%02d off=%d %s days=0x%02X\n", i+1,
        nvsSchedules[i].relay+1, nvsSchedules[i].action?"ON":"OFF",
        schedModeStr(nvsSchedules[i].mode), nvsSchedules[i].hour, nvsSchedules[i].minute,
        nvsSchedules[i].offset, repeatTypeStr(nvsSchedules[i].repeat), nvsSchedules[i].days);
    for (int i=0;i<4;i++)
      Serial.printf("  Switch%d: GPIO%d %s posisi=%s %s\n", i+1, SWITCH_PINS[i],
        SWITCH_TYPE[i]==SW_PUSH?"push":"toggle", swState[i].stable?"ON":"OFF",
        switchLocked[i]?"[TERKUNCI]":"");
    Serial.printf("  Sun: terbit %02d:%02d terbenam %02d:%02d (%.4f, %.4f)\n",
      sunriseMin/60, sunriseMin%60, sunsetMin/60, sunsetMin%60, locLat, locLon);
    SensorStats ss;
    if(xSemaphoreTake(sstatMutex,pdMS_TO_TICKS(50))==pdTRUE){ss=sensorStat;xSemaphoreGive(sstatMutex);}
    if (ss.n>0) Serial.printf("  Stats(n=%lu): T min=%.1f max=%.1f avg=%.1f | H min=%.1f max=%.1f avg=%.1f\n",
      ss.n, ss.tempMin, ss.tempMax, (float)(ss.tempSum/ss.n),
      ss.humMin,  ss.humMax,  (float)(ss.humSum/ss.n));
    return;
  }

  if (strcmp(buf,"reboot")==0) {
    prefs.end();
    Serial.println("[CMD] Reboot..."); vTaskDelay(pdMS_TO_TICKS(500)); ESP.restart();
  }
}

// ============================================================
// LOOP
// ============================================================

static char serialBuf[256];
static int  serialPos = 0;

void loop() {
  esp_task_wdt_reset();
  while (Serial.available()) {
    char c=(char)Serial.read();
    if (c=='\n'||c=='\r') {
      if (serialPos>0) { serialBuf[serialPos]='\0'; processCommand(serialBuf); serialPos=0; }
    } else if (serialPos<(int)sizeof(serialBuf)-1) serialBuf[serialPos++]=c;
  }
  delay(10);
}
